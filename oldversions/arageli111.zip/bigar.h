//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia

#include "arageli.h"

#ifndef BIGAR_H_
#define BIGAR_H_

extern size_t do_big_int_to_bdn(digit* a, digit* b, size_t n, digit bdn_radix);
extern size_t do_bdn_to_big_int(digit* a, digit* b, size_t n, digit bdn_radix);
extern size_t do_add(digit * p1, digit * p2, size_t m, size_t n);
extern int do_sub(digit * p1, digit * p2, size_t m, size_t n);
extern size_t do_optimize(digit * a, size_t n);
extern size_t do_mult(digit *u, digit *v, digit *w, size_t m, size_t n);
extern size_t do_mult_by_digit(digit * a, digit * p, size_t n, size_t d);
extern size_t do_divide_by_digit(digit * a, digit * p, size_t n, digit d);
extern size_t do_divide(digit * u, digit * v, digit * q, size_t m, size_t n);

typedef unsigned long doubledigit;
typedef unsigned long extendeddigit;
typedef unsigned int bit;
const unsigned long BASE = 0x10000l;

#endif

