#define Arageli_version "1.1.1"


/*
 Arageli 1.1.1 by N.Yu.Zolotykh, 2000, 2002
 */

/**

\mainpage

\author <a href="http://www.uic.nnov.ru/~zny"> N.Yu.Zolotykh </a>,
<a href="mailto:relf@unn.ac.ru"> Max Alekseyev </a>,
E.A.Agafonov

\date 2000, 2002

This is a documentation for library
<a href="http://www.uic.nnov.ru/~zny/arageli/arageli.html"> Arageli 1.1.1 </a>
written by <a href="http://www.uic.nnov.ru/~zny"> N.Yu.Zolotykh </a>.
Version of bigarith module for Win32 is written by
<a href="mailto:relf@unn.ac.ru"> Max Alekseyev </a>.
Some parts of bigarith module (C++ without assembler code) are written
by E.A.Agafonov.

Arageli is a C++ library for computations in <b>AR</b>ithmetic,
<b>A</b>lgebra, <b>GE</b>ometry,
<b>L</b>inear and <b>I</b>nteger linear programming.
Current version contains an implementation of arbitary precision
arithmetics on integer numbers and implementation of rational numbers.
Some time-critical parts are written in assembler. You can use this assembler
code or C++ code instead.

The library has been tested in the following environments:
	- DOS 5.0 using Borland C++ 3.1. Optionally you can use built-in assembler
	- Win 95, 98, NT using Borland C++ 5.5 and Turbo Assembler 4.1 (optionally)
	- Win 95, 98, NT using Watcom C32 11 and Turbo Assembler 4.1 (optionally)
	- Win 95, 98, NT using Microsoft Visual C++ 6.0

Copyright (C) 2000, 2002   Nikolai Yu. Zolotykh

This software is free. You can use, copy, and distribute this software and its
documentation for any purpose with or without fee, provided that the above
copyright notice appear in all copies and that both that copyright notice and
this permission notice appear in supporting documentation.

This software is provided "as is" without warranty.

Any comments and suggestions are welcome.

<h1> Installation </h1>

If you have Borland make utility simply type:

<code>
make -ffilenname all
</code>

where filename is used as make file.
The following make files are available:

        - mbc31.mak     for Borland C++ 3.1
	- mbc31asm.mak  for Borland C++ 3.1 with built-in assembler
	- mbc55.mak     for Borland C++ 5.5
	- mbc55asm.mak  for Borland C++ 5.5 and Turbo Assembler 4.1
	- mwatcom.mak   for Watcom C32 11
	- mwatcomasm.mak	for Watcom C32 11 and Turbo Assembler 4.1
	- mvc.mak	for Microsoft Visual C++ 6.0


*/

#include "for.h"

#ifdef __WATCOMC__
#define no_default_arguments no_default_arguments
#endif

