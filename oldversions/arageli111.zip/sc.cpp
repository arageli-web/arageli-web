// simple big rational calculator
// Nikolai Yu. Zolotykh, 2000
// University of Nizhni Novgorod, Russia

/**
    \example
    Simple big rational calculator.
 */

// only for mem control:
#if defined(__BORLANDC__) && !defined(__WIN32__)
#  include <alloc.h>
#endif

#include<iostream.h>
#include<ctype.h>
#include<string.h>
#include"arageli.h"
#include"powerest.h"
#include"bigarith.h"
#include"rational.h"

typedef big_int prim_number;
//typedef long prim_number;
typedef rational<prim_number> main_number;
//typedef prim_number main_number;
//typedef double main_number;
//typedef double prim_number;

const int MAX_LEN = 100;        // the maximum lenght of identificator

enum lexem_type
{
  ABSENT,                       // for old_lexem (when old lexem is absent);
  NUMBER,                       // a number value
  END,                          // the end of input
  PRINT,                        // ;
  PLUS,                         // +
  MINUS,                        // -
  MUL,                          // *
  DIV,                          // DIV or div          reserved word
  MOD,                          // MOD or mod          reserved word
  INT,                          // INT or int          reserved word
  FRAC,                         // FRAC or frac        reserved word
  RATIONAL,                     // /
  FACTORIAL,                    // !
  POWER,                        // ^
  PREV_RESULT,                  // % result of previous expression
  IDENTIFIER,                   // string: consists of letters, numbers,
                                // symbol `_' and begins from a letter or `_'
                                // except reserved words
  LP,                           // (
  RP                            // )
};

enum error_type
{
  OK = 0,                       // OK  h a s  to be  z e r o  (false)
  MUST_BE_RP,
  MUST_BE_LP,
  MUST_BE_NUMBER_OR_EXPRESSION,
  MUST_BE_PRINT,
  IDENTIFIER_IS_TOO_LONG,
  INVALID_LEXEM
};

class lexem
{
public:
  lexem(const lexem& other_lexem)
    :type(other_lexem.type), number(other_lexem.number)
  {
    if(other_lexem.string)
    {
      string = new char [strlen(other_lexem.string) + 1];
      strcpy(string, other_lexem.string);
    } else string = NULL;
  };
  lexem(lexem_type init_type = END):type(init_type), string(NULL) {};
  lexem(lexem_type init_type, const main_number& init_number)
    :type(init_type), number(init_number), string(NULL) {};

  lexem(lexem_type init_type, const char* init_string)
    :type(init_type)
  {
    if(init_string)
    {
      string = new char [strlen(init_string) + 1];
      strcpy(string, init_string);
    } else string=NULL;
  };
  ~lexem(){dispose();};

  lexem & operator=(const lexem& other_lexem)
  {
    dispose();
    type = other_lexem.type;
    number = other_lexem.number;
    if(other_lexem.string)
    {
      string = new char [strlen(other_lexem.string) + 1];
      strcpy(string, other_lexem.string);
    } else string=NULL;
    return *this;
  };

  lexem_type type;

  // union:
  main_number number;
  char *string;

  void dump()
  {
    cout << "type = " << (int)type << ", number = " << number
         << ", string =  " << string << "\n";
  };

  void dispose()
  {
    if (string) delete [] string;
  }

};

class sc
{
public:
  sc(void): old_lexem(ABSENT), prev_result(0) {};
  void run(void);
  lexem get_token(void);

private:
  main_number prev_result;

  class error_handler
  {
  public:
    error_handler(void):error_value(OK) {};
    void operator() (error_type err)
    {
      if (!error_value || !err)
	error_value = err;
    };
    error_type operator() (void)
    {
      return error_value;
    };

  private:
      error_type error_value;
} error;

  lexem old_lexem;

  void put_back(lexem l);

  main_number simple_expression(void);
  main_number term(void);
  main_number factor(void);
  main_number secondary(void);
  main_number primary(void);
};

lexem sc::get_token(void)
{
  if (old_lexem.type != ABSENT)
  {
    lexem tmp_lexem = old_lexem;
    old_lexem.type = ABSENT;
    return tmp_lexem;
  }

  old_lexem.type = ABSENT;

  char ch;

  do
  {
    if (!cin.get(ch))
      return lexem(END);
  }
  while (isspace(ch));

  switch (ch)
  {
    case '+':
      return lexem(PLUS);
    case '-':
      return lexem(MINUS);
    case '*':
      return lexem(MUL);
    case '/':
      return lexem(RATIONAL);
    case '^':
      return lexem(POWER);
    case '!':
      return lexem(FACTORIAL);
    case '(':
      return lexem(LP);
    case ')':
      return lexem(RP);
    case ';':
      return lexem(PRINT);
    case '%':
      return lexem(PREV_RESULT);
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
    {
      cin.putback(ch);
      prim_number number_value;
      cin >> number_value;
      return lexem(NUMBER, number_value);
    }
    default:
      if (isalpha(ch) || ch == '_')
      {
        char str[MAX_LEN + 1];
        size_t count = 0;
        str[count++] = ch;
        while (cin.get(ch) && (isalnum(ch) || ch == '_'))
        {
          if (count == MAX_LEN)
          {
            error(IDENTIFIER_IS_TOO_LONG);
            break;
          }
          str[count++] = ch;
        }
        cin.putback(ch);
        str[count] = 0;

        if (strcmp(str, "DIV") == 0 || strcmp(str, "div") == 0)
          return lexem(DIV);
        else if (strcmp(str, "MOD") == 0 || strcmp(str, "mod") == 0)
          return lexem(MOD);
        else if (strcmp(str, "INT") == 0 || strcmp(str, "int") == 0)
          return lexem(INT);
        else if (strcmp(str, "FRAC") == 0 || strcmp(str, "frac") == 0)
          return lexem(FRAC);
        else
          return lexem(IDENTIFIER, str);
      }
      else
      {
        error(INVALID_LEXEM);
        return lexem(PRINT);
      }
  }
}

void sc::put_back(lexem l)
{
  old_lexem = l;
}

main_number sc::simple_expression(void)
{
  main_number left = 0;
  lexem sign = get_token();
  put_back(sign);
  if (sign.type != PLUS && sign.type != MINUS)
    left = term();

  while (1)
  {
    lexem sign = get_token();
    switch (sign.type)
    {
      case PLUS:
        left = left + term();
        break;
      case MINUS:
        left = left - term();
        break;
      default:
        put_back(sign);
        return left;
    }
  }
}

main_number sc::term(void)
{
  main_number left = factor();

  while (1)
  {
    lexem sign = get_token();
    switch (sign.type)
    {
      case MUL:
        left = left * factor();
        break;
      case DIV:
        left = ifloor(left) / ifloor(factor());
        break;
      case MOD:
        left = ifloor(left) % ifloor(factor());
        break;
      case RATIONAL:
        left = left / factor();
        break;
      default:
        put_back(sign);
        return left;
    }
  }
}


main_number sc::factor(void)
{
  main_number left = secondary();

  lexem sign = get_token();

  switch (sign.type)
  {
    case POWER:
    {
      main_number right = secondary();
      return power(ifloor(left), ifloor(right));
     // return power(left, right);
    }
    default:
      put_back(sign);
      return left;
  }
}

main_number sc::secondary(void)
{
  main_number result = primary();

  lexem sign = get_token();

  switch (sign.type)
  {
    case FACTORIAL:
      return factorial(ifloor(result));
      //return factorial(result);
    default:
      put_back(sign);
      return result;
  }
}

main_number sc::primary(void)
{
  lexem new_lexem = get_token();

  switch (new_lexem.type)
  {
    case NUMBER:
      return new_lexem.number;
    case PREV_RESULT:
      return prev_result;
    case INT:
    case FRAC:
    {
      main_number e = simple_expression();
      switch (new_lexem.type)
      {
        case INT:
          return floor(e);
        case FRAC:
          return frac(e);
      }
    }

    /*
    case INT:
    case FRAC:
    {
      lexem lp = get_token();
      if (lp.type != LP)
      {
        error(MUST_BE_LP);
        put_back(lp);
      }
      main_number e = simple_expression();
      lexem rp = get_token();
      if (rp.type != RP)
      {
        error(MUST_BE_RP);
        put_back(rp);
      }
      switch (new_lexem.type)
      {
        case INT:
          return floor(e);
        case FRAC:
          return e - floor(e);
      }
    }
    */

    case LP:
    {
      main_number e = simple_expression();
      lexem rp = get_token();
      if (rp.type != RP)
      {
        error(MUST_BE_RP);
        put_back(rp);
      }
      return e;
    }
    default:
      error(MUST_BE_NUMBER_OR_EXPRESSION);
      put_back(new_lexem);
      return 0;
  }
}

void sc::run(void)
{

  while (1)
  {
    lexem new_lexem = get_token();
    if (new_lexem.type == END)
      break;
    put_back(new_lexem);

    prev_result = simple_expression();

    new_lexem = get_token();
    if (new_lexem.type != PRINT)
    {
      //put_back(new_lexem);
      error(MUST_BE_PRINT);
    }

    if (error())
    {
      switch (error())
      {
        case MUST_BE_RP:
          cerr << "must be right parenthesis" << '\n';
          break;
        case MUST_BE_LP:
          cerr << "must be left parenthesis" << '\n';
          break;
        case MUST_BE_NUMBER_OR_EXPRESSION:
          cerr << "must be number or left parenthesis" << '\n';
          break;
        case MUST_BE_PRINT:
          cerr << "must be semicolon" << '\n';
          break;
        case INVALID_LEXEM:
          cerr << "invalid lexem" << '\n';
          break;
        case IDENTIFIER_IS_TOO_LONG:
          cerr << "identifier is too long" << '\n';
          break;
      }
      error(OK);
    }
    else
    {
      if (new_lexem.type == PRINT)
        cout << prev_result << "\n";
    }
  }
}

void print_title()
{
  cout << "***********************************************\n";
  cout << "sc: simple big rational calculator, version 1.1\n";
  cout << "Nikolai Yu. Zolotykh, 2000, 2001 \n";
  cout << "This is a part of Arageli " << Arageli_version << '\n';
  cout << "For help enter sc.exe --help " <<'\n';
}



void print_help()
{
  print_title();

  cout << "All arithmetical operations (+,-,*,/), integer division (div)\n"
       << "and residue (mod), square rooting (sqr),\n"
       << "integer/fractal part (int/frac), factorial (!), power (^)\n"
       << "are supported. % is the result of the last expression. Examples:\n";
  cout << "  -2/3+1/6+6/5;                        \n";
  cout << "  25 div 4;                            \n";
  cout << "  25 mod 4;                            \n";
  cout << "  int(10/3);                           \n";
  cout << "  frac(10/3);                          \n";
  cout << "  100!;                                \n";
  cout << "  100^100;                             \n";
  cout << "  ((((1+2)*3-4)/5-6)*7+8)/9-10;        \n";
  cout << "  32!/10!^3/2;                         \n";
  cout << "  32!; %/31!;                          \n";
  cout << "Usage:\n";
  cout << "  sc options\n";
  cout << "Options:\n";
  cout << " -s:\t supress title message\n";
  cout << " -v or --version:\t prints version\n";
  cout << " -? or -h or --help:\t prints this message\n";
}

void main(int argc, char *argv[])
{

#if defined(__BORLANDC__) && !defined(__WIN32__)
  long memavail = coreleft();
#endif

{
  // default values:
  int supress_title_message = 0;

  // arguments parsing:
  for(int i = 1; i < argc; i++)
  {
    if(!strcmp(argv[i], "-s"))
    {
      supress_title_message = 1;
    }
    else if(!strcmp(argv[i], "-h") || !strcmp(argv[i], "-?")
      || !strcmp(argv[i], "--help"))
    {
      print_help();
      return;
    }
    else if(!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version"))
    {
      cout << "Sc from Arageli " << Arageli_version << '\n';
      return;
    }
    else
    {
      cout << "Unknown argument: " << argv[i] << '\n';
      cout << "For help type sc -h \n";
      return;
    }
  }

  if (!supress_title_message)
    print_title();

  sc calculator;
  calculator.run();
}

#if defined(__BORLANDC__) && !defined(__WIN32__)
memavail = coreleft() - memavail;
cout << " mem = " << memavail << " must be zero" << "\n" ;
#endif
}