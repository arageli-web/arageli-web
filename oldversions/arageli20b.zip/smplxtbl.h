//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia
//*******************************************************************
// SmplxTbl.h
//*******************************************************************

#include<iostream.h>
#include<conio.h>
#include"matrices.h"
#include"math.h"

#if defined(__BORLANDC__) && !defined(__WIN32__)
#include<values.h>
#endif

#ifndef SMPLXTBLS_H_
#define SMPLXTBLS_H_

/** \file
    Simplex methods and others.

    Simplex table implementation with simplex method and Gomory's algorithms.
    */

/** \example go1.cpp
    The first Gomory method. Double float arithmetics */

/** \example go1big.cpp
    The first Gomory method. Big Rational arithmetics */

/** \example go2.cpp
    The second Gomory method. Double float arithmetics */

/** \example go2big.cpp
    The second Gomory method. Big Rational arithmetics */

/** Simplex table implementation.
    Supports simplex-method for linear programming in the column mode,
    first and second Gomory cut planning method for integer
    linear programming. **/

template <class T> class simplex_table: public matrix<T>
{
public:

  /// Constructor
  simplex_table();

  /// Returns the number of the last row. I.e. get_m()-1.
  index get_rows();
  /// Returns the number of the last column. I.e. get_n()-1.
  index get_cols();
  /// In the primal simplex method: returns a pivoting column.
  index find_pivot_col();
  /// In the primal simplex method: given a pivoting column j returns a pivoting row.
  index find_pivot_row(index j);
  /// In the dual simplex method: returns a pivoting row.
  index find_pivot_row();
  /// In the dual simplex method: given a pivoting row i returns a pivoting column.
  index find_pivot_col(index i);
  /// In the first Gomory method: finds generating row.
  index find_generating_row();
  /// In the second Gomory method for mixed linear programming: finds generating row.
  index find_generating_row_mip();
  /// Returns 1 if the table is primal feasible.
  int is_primal_feasible();
  /// Returns 1 if the table is dual feasible.
  int is_dual_feasible();
  /// Runs a primal simplex method in the column mode
  int primal_simplex_col();
  /// Runs a dual simplex method in the column mode
  int dual_simplex_col();
  /// The first Gomory method
  int gomory1();
  /// The second Gomory method
  int gomory2();
  /// One pivoting operation
  void pivoting_col(index pivot_row, index pivot_col);

private:

  int old_cut_plane_deleting;
  int k;
  index is_non_bas_var(index j);
  index init_rows;
  vector<index> non_bas_var;

};

//*************************************************************************

int is_integer(const double a)
{
  const double delta = 0.00000005;
  if(fabs(floor(a + 0.5) - a) < delta) return 1;
  return 0;
}

//*************************************************************************

template <class T> simplex_table<T>::
  simplex_table():
    matrix<T>(),
    non_bas_var(),
    old_cut_plane_deleting(0)
{
  cin >> k;
  cin >> *this;
  non_bas_var.resize(get_cols() + 1);
  init_rows = get_rows();
  for(index j = 1; j <= get_cols(); j++)
    non_bas_var[j] = j;
}

//*************************************************************************

template <class T> inline index simplex_table<T>::
  get_rows()
{
  return get_m() - 1;
}

//*************************************************************************

template <class T> inline index simplex_table<T>::
  get_cols()
{
  return get_n() - 1;
};

//*************************************************************************

template <class T> index simplex_table<T>::
  find_pivot_row()
{
  for(index i = 1; i <= get_rows(); i++)
  {
    if(at(i, 0) < T(0)) return i;
  }
  return 0;
}

//*************************************************************************

template <class T> index simplex_table<T>::
  find_pivot_col(index pivot_row)
{
  index j_max = 0;
  T max;

  index j;

  for(j = 1; j <= get_cols(); j++)
  {
    if(at(pivot_row, j) < T(0))
    {
      max = at(0, j) / at(pivot_row, j);
      j_max = j;
      break;
    }
  }

  if (!j_max)
    return 0;

  for(j = j_max + 1; j <= get_cols(); j++)
  {
    if((at(pivot_row, j) < T(0)) && (at(0, j) / at(pivot_row, j) > max) )
    {
      max = at(0, j) / at(pivot_row, j);
      j_max = j;
    }
  }

  return j_max;
}

//*************************************************************************

template <class T> index simplex_table<T>::
  find_pivot_col()
{
  for(index j = 1; j <= get_cols(); j++)
  {
    if(at(0, j) < T(0)) return j;
  }
  return 0;
}

//*************************************************************************

template <class T> index simplex_table<T>::
  find_pivot_row(index pivot_col)
{
  index i_min = 0;
  T min;

  index i;
  for(i = 1; i <= get_rows(); i++)
  {
    if(at(i, pivot_col) > T(0))
    {
      min = at(i, 0) / at(i, pivot_col);
      i_min = i;
      break;
    }
  }

  if (!i_min)
    return 0;

  for(i = i_min + 1; i <= get_rows(); i++)
  {
    if((at(i, pivot_col) > T(0)) && (at(i, 0) / at(i, pivot_col) < min) )
    {
      min = at(i, 0) / at(i, pivot_col);
      i_min = i;
    }
  }

  return i_min;
}

//*************************************************************************

template <class T> int simplex_table<T>::
  is_primal_feasible()
{
  return !find_pivot_row();
}

//*************************************************************************

template <class T> int simplex_table<T>::
  is_dual_feasible()
{
  return !find_pivot_col();
}

//*************************************************************************

template <class T> void simplex_table<T>::
  pivoting_col(index pivot_row, index pivot_col)
{
  T pivot_item = -at(pivot_row, pivot_col);

  div_col(pivot_col, pivot_item);

  non_bas_var[pivot_col] = pivot_row;

  for(index j = 0; j <= get_cols(); j++)
    if(j != pivot_col)
      add_col(j, pivot_col, at(pivot_row, j));
}

//*************************************************************************

template <class T> int simplex_table<T>::
  primal_simplex_col()
{
  index pivot_col;
  while(pivot_col = find_pivot_col())
  {
    index pivot_row;
    if(pivot_row = find_pivot_row(pivot_col))
      pivoting_col(pivot_row, pivot_col);
    else
      return 0;
  }
  return 1;
}

//*************************************************************************

template <class T> int simplex_table<T>::
  dual_simplex_col()
{
  index pivot_row;
  while(pivot_row = find_pivot_row())
  {
    index pivot_col = find_pivot_col(pivot_row);
    if(pivot_col)
      pivoting_col(pivot_row, pivot_col);
    else
      return 0;
  }
  return 1;
}

//*************************************************************************

template <class T> index simplex_table<T>::
  is_non_bas_var(index j)
{
  for (index i = 1; i <= get_cols(); i++)
    if (non_bas_var[i] == j)
      return i;
  return 0;
}

//*************************************************************************

template <class T> index simplex_table<T>::
  find_generating_row()
{
   for(index i = 0; i <= get_rows(); i++)
   {
     if (!is_integer(at(i, 0))) return i;
   }
   return -1;
}

//*************************************************************************

template <class T> index simplex_table<T>::
  find_generating_row_mip()
{
   for(index i = 1; i <= k; i++)
   {
     if (!is_integer(at(i, 0))) return i;
   }
   return -1;
}

//*************************************************************************

template <class T> int simplex_table<T>::
  gomory1()
{
  index generating_row;

  while((generating_row = find_generating_row()) != -1)
  {

    // old cut plain deleting

    if (old_cut_plane_deleting)
    {
      index i = init_rows + 1;
      while(i <= get_rows())
      {
	if (is_non_bas_var(i))
	  i++;
	else
	{
	  del_row(i);
	  for(index j = 1; j <= get_cols(); j++)
	    if (non_bas_var[j] > i)
	      non_bas_var[j]--;
	}
      }
    }

    // cut constructing

    ins_row(get_rows() + 1);

    operator()(get_rows(), 0) =
      floor(at(generating_row, 0)) - at(generating_row, 0);
      // integer part

    for (index j = 1; j <= get_cols(); j++)
    {
      operator()(get_rows(), j) =
	floor(at(generating_row, j)) - at(generating_row, j);
    }

    cout << "\n after cutting: \n" << *this;

    // simplex method...

    if(!dual_simplex_col())
    {
      cout << "\n problem has no feasible solution \n" << *this;
      return 0;
    }

    cout << "\n after simplex method: \n" << *this;
  }

  cout << "problem is solved" << "\n" << "result matrix:" << *this;
  return 1;
}

//*************************************************************************

template <class T> int simplex_table<T>::
  gomory2()
{
  index generating_row;

  while((generating_row = find_generating_row_mip()) != -1)
  {

    // old cut plain deleting

    if (old_cut_plane_deleting)
    {
      index i = init_rows + 1;
      while(i <= get_rows())
      {
	if (is_non_bas_var(i))
	  i++;
	else
	{
	  del_row(i);
	  for(index j = 1; j <= get_cols(); j++)
	    if (non_bas_var[j] > i)
	      non_bas_var[j]--;
	}
      }
    }

    // cut constructing

    ins_row(get_rows() + 1);

    T f0 = at(generating_row, 0) - floor(at(generating_row, 0));
    operator()(get_rows(), 0) = 0-f0;

    for (index j = 1; j <= get_cols(); j++)
    {
      T f = at(generating_row, j) - floor(at(generating_row, j));
      if (non_bas_var[j] <= k)
      {
	if (f <= f0)
	  operator()(get_rows(), j) = 0-f;
	else
	  operator()(get_rows(), j) = f0 / (f0 - 1) * (1 - f);
      }
      else
      {
	if (at(generating_row, j) >= 0)
	  operator()(get_rows(), j) = 0-at(generating_row, j);
	else
	  operator()(get_rows(), j) = f0 / (1 - f0) * at(generating_row, j);
      }
    }

    cout << "\n after cutting: \n" << *this;

    // simplex method...

    if(!dual_simplex_col())
    {
      cout << "\n problem has no feasible solution \n" << *this;
      return 0;
    }

    cout << "\n after simplex method: \n" << *this;
  }

  cout << "problem is solved" << "\n" << "result matrix:" << *this;
  return 1;
}

#endif


