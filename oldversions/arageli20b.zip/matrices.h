//N.Yu.Zolotykh 1999, 2000
//University of Nizhni Novgorod, Russia

#include<iostream.h>
#include<stdlib.h>
#include<stdio.h>
#include<strstrea.h>
#include<string.h>
#include"arageli.h"

#ifndef MATRICES_H_
#define MATRICES_H_


/**
   \file
   Vectors and matrices implementation.
   This module containes description of two following classes:

   - vector,
   - matrix.

   These classes support all linear
   algebraic operations with appropriate mathematical objects.

   The number of entries in a vector is bounded above by the constant n_max_size.
   The number of columns in a matrix is bounded above by the constant n_max_size.
   The number of rows in a matrix is bounded above by the constant m_max_size.
   Indices of enties in a vector/matrix begin from 0.
   The type subscript is specially defined for vector/matrix indices.

   For error controlling there is a variable matrix_status
   which containes the code of a last error.
*/

/** \name Constants for matrix_status */
//@{
const int st_ok     =  1;                    ///< Ok
const int st_out_of_memory  = -1;            ///< Out of memory
const int st_out_of_range = -2;              ///< Out of range
const int st_inconsistent_sizes = -3;        ///< Inconsistent sizes of matrices
const int st_input_error  = -4;              ///< Input error
const int st_output_error   = -5;            ///< Output error
const int st_incorrect_index  = -6;          ///< Incorrect index
const int st_matrix_must_be_square = -7;     ///< Matrix must be square
const int st_matrix_is_singular = -8;        ///< Matrix is singular
//@}

/**
    The code of the last error.
    If an error has occured an error message writes to std err
 */
int matrix_status = st_ok;


///  The type for index representation
typedef int index; // index >= -1

/**
    The maximum number of column in a matrix,
    the maximum number of enties in a vector
 */
index const n_max_size = 10000;

/// The maximum number of rows in a matrix
index const m_max_size = 10000;


#if defined(__BORLANDC__) && defined(__WIN32__) //bc 5.5
   template <class T> class vector;
   template <class T> class matrix;
   template <class T> ostream & operator << (ostream & s, const vector<T> & x);
   template <class T> istream & operator >> (istream & s, vector<T> & x);
   template <class T> vector<T> operator +  (const vector<T> & a, const vector<T> & b);
   template <class T> vector<T> operator -  (const vector<T> & a, const vector<T> & b);
   template <class T> vector<T> operator * (const T alpha, const vector<T> & a);
   template <class T> T operator * (const vector<T> & a, const vector<T> & b);
   template <class T> int operator == (const vector<T> & a, const vector<T> & b);
   template <class T> int operator != (const vector<T> & a, const vector<T> & b);
   template <class T> void pretty(ostr & s, const vector<T>& A);
   template <class T> ostream & operator << (ostream & s, const matrix<T> & x);
   template <class T> istream & operator >> (istream & s, matrix<T> & x); // ?
   template <class T> matrix<T> operator + (const matrix<T> &, const matrix<T> &);
   template <class T> matrix<T> operator * (const matrix<T> &, const matrix<T> &);
   template <class T> matrix<T> operator * (T alpha, const matrix<T> & a);
   template <class T> matrix<T> operator * (const matrix<T> & a, const vector<T> & v);
   template <class T> matrix<T> operator * ( const vector<T> & v, const matrix<T> & a);
   template <class T> matrix<T> transpose (const matrix<T> & a);
   template <class T> int operator == (const matrix<T> & a, const matrix<T> & b);
   template <class T> int operator != (const matrix<T> & a, const matrix<T> & b);
   template <class T> matrix<T> diag(const vector<T>& d);
   template <class T> matrix<T> diag(T a, index m, index n);
   template <class T> matrix<T> diag(T a, index m);
   template <class T> matrix<T> eye (T a, index m, index n);
   template <class T> matrix<T> eye (T a, index m);
   template <class T> matrix<T> fill(T a, index m, index n);
   template <class T> matrix<T> fill(T a, index m);
   template <class T> matrix<T> zero(T a, index m, index n);
   template <class T> matrix<T> zero(T a, index m);
   template <class T> void pretty(ostr & s, const matrix<T>& A);
   template <class T> void print2(ostr & s, const matrix<T>& A, const matrix<T>& B);
   template <class T> void print3(ostr & s, const matrix<T>& A, const matrix<T>& B, const matrix<T>& C);
#endif
   
   
/***************************/
/*                         */
/*     class vector<>      */
/*                         */
/***************************/

/**
   Implementation of a vector with entries of type T
 */
template <class T> class vector
{
public:

  /// Constructor
  /**
      v is initialized to the vector of undefined entries of size n_init,
      n_delta_init is the increasing step
  */
  vector (index n_init = 0, index n_delta_init = 2);

  /// Constructor
  /**
      v is initialized to the vector of size n_init with enties stored in a,
      n_delta_init is the increasing step
  */
  vector (index n_init, T* a, index n_delta_init = 2);

  /// Constructor
  vector (const vector<T> &x);

  /// Assignment
  vector<T> & operator = (const vector<T>  &x);

  /// Destructor
  ~vector(void);

  /// Returns the number of entries
  index get_n (void) const {return n;};

  /// Returns the j-th entry of v
  inline T & operator[](index j);

  /// Returns the j-th entry of v. Only for reading
  inline T at (index j) const;

  /// Returns the j-th entry of v. Only for reading. Without bounds checking
  inline T access(index j) const;

  /// Resize vector
  /**
      Transforms a vector to a vector of size new_n.
      New entries are undefined
    */
  void resize (index new_n = 0);

  /// Inserts item in the position j
  void ins_item (index j, T item = 0);

  /** Joins item to the end of a vector.
      x.ins_item(x.get_n(), item) makes the same
  */
  void join (T item);

  /// Returns 1 if item is in a vector
  int member(T item) const;

  /// Returns (the first) index of item or -1 if item is not in a vector
  index index_of_item(T item) const;

  /// Deletes item from the vector
  void del_item (index j);

  /// Deletes item from the vector and returns its value
  T take_item (index j);

  /// Swap items
  void swap_items (index j1, index j2);

  /// Combined assignment-addition operator
  vector<T> & operator += (const vector<T> & x);

  /// Combined assignment-subtraction operator
  vector<T> & operator -= (const vector<T> & x);

#if !defined(__BORLANDC__) || !defined(__WIN32__) //!bc 5.5/
  /** Output stream operator.
      First, writes the number of entries.
      Then writes entries */
  friend ostream & operator << (ostream & s, const vector<T> & x);

  /** Input stream operator.
      First, writes the number of entries.
      Then writes entries */
  friend istream & operator >> (istream & s, vector<T> & x);
    // ��祬�-�, �᫨ ᤥ���� ��� �㭪��-��㣠 ���筮� �㭪樥�,
    // ������� ���� cin >> x �� ���ਭ�������

  /// Addition
  friend vector<T> operator +  (const vector<T> & a, const vector<T> & b);

  /// Subtraction
  friend vector<T> operator -  (const vector<T> & a, const vector<T> & b);

  /// Component multiplication with number alpha
  friend vector<T> operator * (const T alpha, const vector<T> & a);

  /// Inner product
  friend T operator * (const vector<T> & a, const vector<T> & b);

  /// Test for equality
  friend int operator == (const vector<T> & a, const vector<T> & b);

  /// Test for inequality
  friend int operator != (const vector<T> & a, const vector<T> & b);
    // ��祬�-�, �᫨ ᤥ���� �� ����樨-����� ����묨 �����ﬨ,
    // ������� ���� a == b * c �� ���ਭ�������

  /// Outputs a vector using latex notation
  friend void pretty(ostr & s, const vector<T>& A);
#else // bc 5.5
  friend ostream & operator << <T> (ostream & s, const vector<T> & x);
  friend istream & operator >> <T> (istream & s, vector<T> & x);
  friend vector<T> operator +  <T> (const vector<T> & a, const vector<T> & b);
  friend vector<T> operator -  <T> (const vector<T> & a, const vector<T> & b);
  friend vector<T> operator *  <T>(const T alpha, const vector<T> & a);
  friend T operator * <T> (const vector<T> & a, const vector<T> & b);
  friend int operator == <T> (const vector<T> & a, const vector<T> & b);
  friend int operator != <T> (const vector<T> & a, const vector<T> & b);
  friend void pretty<T>(ostr & s, const vector<T>& A);
#endif

private:

  index n, n_limit, n_delta;
  T *data;
  void dispose_all (void);
  inline int index_correct (index j) const;
};


/***************************/
/*                         */
/*      class matrix<>     */
/*                         */
/***************************/

/// Implementation of a matrix with entries of type T
template <class T>
  class matrix
{
public:

  /** Constructor.
      Creates a matrix with m_init rows and n_init columns,
      initial entries are undefined.
      All indices begin with 0
      m_delta_init, n_delta_init are increasing steps
  */
  matrix (index m_init = 0, index n_init = 0, index m_delta_init = 2,
	  index n_delta_init = 2);

  /// Constructor
  /**
      Creates a matrix with m_init rows and n_init columns
      and initial entries from A (in the row order).
  */
  matrix (index m_init, index n_init, T* A, index m_delta_init = 2,
	  index n_delta_init = 2);


  /// Creates a copy of a matrix
  matrix (const matrix<T>  &x);

  /// Assignement
  matrix<T>  &operator = (const matrix<T>  &x);

  /// Destructor
  ~matrix (void);

  /// Returns the number of rows
  inline index get_m (void) const {return m;};
  /// Returns the number of columns
  inline index get_n (void) const {return n;};

  /// Returns the entry (i,j)
  /** Two-dimensional subscript operator to get/set
      individual matrix elements. */
  inline T & operator ()(index i, index j);
  /// Returns the entry (i,j)
  /** Two-dimensional subscript operator to get
      individual matrix elements. */
  inline T at (index i, index j) const;

  /// Returns the entry (i,j)
  /** Two-dimensional subscript operator to get
      individual matrix elements.
      Without bounds checking */
  T access(index i, index j) const;

  /// Resizes matrix
  /**
      Construct new new_m-by-new_n matrix.
      New entries are undefined
    */
  void resize(index new_m = 0, index new_n = 0);

  /// Returns the j-th row
  vector<T> row (index j) const;
  /// Returns the matrix composed from the rows with numbers indices
  matrix<T> rows (vector<index> indices) const;
  /// Inserts i-th row
  void ins_row (index i);
  /// Inserts a row x
  void ins_row (index i, vector<T>  x);
  /// Joins a row x to the bottom of a matrix,
  /** ins_row(get_m(), x) makes the same */
  void join_row (vector<T>  x);
  /// Deletes i-th row
  void del_row (index i);
  /// Deletes rows with numbers indices
  void del_rows (vector<index> indices);
  /// Deletes i-th row and return it
  vector<T> take_row (index i);
  /// Deletes rows and returns it
  /** Returns the matrix composed from the rows with numbers indices
      deleting they from the matrix */
  matrix<T> take_rows (vector<index> indices);
  /// Adds to the i1-row the i2-row multiplied with alpha
  void add_row (index i1, index i2, T alpha);
  /// Add two rows
  /** Calculates a new row as a linear combination of i1-th and i2-th rows
         with coefficients alpha1 and alpha2,
         then joins a new row to the bottom of a matrix */
  void add_rows (index i1, T alpha1, index i2, T alpha2);
  /// Multiplies the i-th row with scalar alpha
  void mult_row (index i, T alpha);
  /// Divides the i-th row with scalar alpha
  void div_row (index i, T alpha);
  /// Swaps i1-th and i2-th rows
  void swap_rows (index i1, index i2);

  /// Returns the j-th column
  vector<T> col (index j) const;
  /// Returns a matrix composed from columns with numbers indices
  matrix<T> cols (vector<index> indices) const;
  /// Inserts new column
  void ins_col (index j);
  /// Inserts new column x
  void ins_col (index j, vector<T>  x);
  /// Joins column x to the right side of a matrix,
  /** ins_col(get_n(), x) makes the same */
  void join_col (vector<T>  x);
  /// Deletes j-th column
  void del_col (index j);
  /// Deletes columns
  void del_cols (vector<index> indices);
  /// Returns j-th column deleting it from the matrix
  vector<T> take_col (index j);
  /// Returns columns deleting them from the matrix
  matrix<T> take_cols (vector<index> indices);
  /// Adds to the j1-column the j2-column multiplied with alpha
  void add_col (index j1, index j2, T alpha);
  /// Adds two columns
  /** Calculates a new column as a linear combination
      of j1-th and j2-th columns
      with coefficients alpha1 and alpha2,
      then joins a new column to the right side of a matrix */
  void add_cols (index j1, T alpha1, index j2, T alpha2);
  /// Multiplies the j-th column with scalar alpha
  void mult_col (index j, T alpha);
  /// Divides the j-th column with scalar alpha
  void div_col (index j, T alpha);
  /// Swaps j1-th and j2-th columns
  void swap_cols (index j1, index j2);

  /// Returns a submatrix compose from rows r and columns c
  matrix<T> sumbatrix(vector<index> r, vector<index> c);

  /// Unary plus
  matrix operator + () {return *this;}
  /// Unary minus
  matrix operator - ();

#if !defined(__BORLANDC__) || !defined(__WIN32__) //!bc 5.5/
  /// Output stream operator
  /** First, writes the number of rows and the number of columns.
      Then writes entries */
  friend ostream & operator << (ostream & s, const matrix & x);
  /// Input stream operator
  /** First, reads the number of rows and the number of columns.
      Then reads entries */
  friend istream & operator >> (istream & s, matrix & x); // ?
    // ��祬�-�, �᫨ ᤥ���� ��� �㭪��-��㣠 ���筮� �㭪樥�,
    // ������� ���� cin >> x �� ���ਭ�������

  /// Addition
  friend matrix<T> operator +(const matrix<T> &, const matrix<T> &);
  /// Matrix multiplication
  friend matrix<T> operator *(const matrix<T> &, const matrix<T> &);
  /// Multiplies matrix with scalar alpha
  friend matrix<T> operator *(T alpha, const matrix<T> & a);
  /// Multiplies matrix with vector (interpreted as a column)
  friend matrix<T> operator *(const matrix<T> & a, const vector<T> & v);
  /// Multiplies vector (interpreted as a row) with matrix
  friend matrix<T> operator *( const vector<T> & v, const matrix<T> & a);
  /// Transposition
  friend matrix<T> transpose (const matrix<T> & a);
  /// Test for equality
  friend int operator == (const matrix<T> & a, const matrix<T> & b);
  /// Test for inequality
  friend int operator != (const matrix<T> & a, const matrix<T> & b);
    // ��祬�-�, �᫨ ᤥ���� �� ����樨-����� ����묨 �����ﬨ,
    // ������� ���� a == b * c �� ���ਭ�������

  /// Returns a square diagonal matrix with entries d on the diagonal
  friend matrix<T> diag(const vector<T>& d);
  /// Returns an (m, n)-matrix with entry a on the diagonal
  friend matrix<T> diag(T a, index m, index n);
  /// Returns a square (m, m)-matrix with entry a on the diagonal
  friend matrix<T> diag(T a, index m);
  /// Returns an identity (m, n)-matrix
  friend matrix<T> eye (T a, index m, index n);
  /// Returns an identity (n, n)-matrix
  friend matrix<T> eye (T a, index m);
  /// Returns an (m, n)-matrix filled with scalar a
  friend matrix<T> fill(T a, index m, index n);
  /// Returns a (m, m)-matrix filled with scalar a
  friend matrix<T> fill(T a, index m);
  /// Returns a zero (m, n)-matrix
  friend matrix<T> zero(T a, index m, index n);
  /// Returns a zero (m)-matrix
  friend matrix<T> zero(T a, index m);
  /// Outputs a matrix using latex notation
  friend void pretty(ostr & s, const matrix<T>& A);

  friend
    void print2(ostr & s,
      const matrix<T>& A, const matrix<T>& B);
  friend
    void print3(ostr & s,
      const matrix<T>& A, const matrix<T>& B, const matrix<T>& C);
#else //bc5.5
   friend ostream & operator <<<T>(ostream & s, const matrix & x);
   friend istream & operator >><T> (istream & s, matrix & x); // ?
   friend matrix<T> operator + <T>(const matrix<T> &, const matrix<T> &);
   friend matrix<T> operator * <T>(const matrix<T> &, const matrix<T> &);
   friend matrix<T> operator * <T>(T alpha, const matrix<T> & a);
   friend matrix<T> operator * <T>(const matrix<T> & a, const vector<T> & v);
   friend matrix<T> operator * <T>( const vector<T> & v, const matrix<T> & a);
   friend matrix<T> transpose<T> (const matrix<T> & a);
   friend int operator == <T>(const matrix<T> & a, const matrix<T> & b);
   friend int operator != <T>(const matrix<T> & a, const matrix<T> & b);
   friend matrix<T> diag<T>(const vector<T>& d);
   friend matrix<T> diag<T>(T a, index m, index n);
   friend matrix<T> diag<T>(T a, index m);
   friend matrix<T> eye <T>(T a, index m, index n);
   friend matrix<T> eye <T>(T a, index m);
   friend matrix<T> fill<T>(T a, index m, index n);
   friend matrix<T> fill<T>(T a, index m);
   friend matrix<T> zero<T>(T a, index m, index n);
   friend matrix<T> zero<T>(T a, index m);
   friend void pretty<T>(ostr & s, const matrix<T>& A);
   friend void print2<T>(ostr & s,
  		const matrix<T>& A, const matrix<T>& B);
   friend void print3<T>(ostr & s,
  		const matrix<T>& A, const matrix<T>& B, const matrix<T>& C);
#endif

private:

  index m, n, m_limit, n_limit, m_delta, n_delta;
  T **data;
  void dispose_all (void);
  void ins_this_row (index i, T * p);
  inline int indices_correct (index i, index j) const;
  int max_format() const;
};

/** Prints matrices in the form:

        A B
*/
template <class T>
  void print2(ostr & s,
  const matrix<T>& A, const matrix<T>& B);


/** Prints matrices in the form:

        A
      B C
*/
template <class T>
  void print3(ostr & s,
  const matrix<T>& A, const matrix<T>& B, const matrix<T>& C);


/// Returns a grid-vector
/** Returns a vector
      (begin, begin + step, begin + 2 * step, ...)
      the last component is less than or equal to end
      \relates vector */
template <class T> void mesh_grid(vector<T>& v, T begin, T end, T step);



/***************************/
/*                         */
/*     implementation      */
/*                         */
/***************************/


void matrix_error (int new_status, char *message)
{
  if (matrix_status == st_ok)
    matrix_status = new_status;
  cerr << "matrix error: " << message << "\n";
}

void matrix_fatal_error (int new_status, char *message)
{
  if (matrix_status == st_ok)
    matrix_status = new_status;
  cerr << "matrix fatal error: " << message << "\n";
  exit(1);
}

inline int sizes_correct (index n_size)
{
  return (n_size >= 0) && (n_size <= n_max_size);
}

inline int sizes_correct (index m_size, index n_size)
{
  return (m_size >= 0) && (n_size >= 0) && (m_size <= m_max_size) &&
  (n_size <= n_max_size);
}

/***************************/
/*                         */
/*     class vector<>      */
/*                         */
/***************************/

template <class T>
  vector<T>::vector(index n_init, index n_delta_init)
{
  n = n_limit = 0;
  n_delta = n_delta_init;
  data = NULL;

  resize (n_init);
}

template <class T>
  vector<T>::vector (index n_init, T* a, index n_delta_init)

{
  n = n_limit = 0;
  n_delta = n_delta_init;
  data = NULL;

  resize (n_init);
  if (matrix_status != st_ok)
    return;

  for (index i = 0; i < get_n(); i++)
    data[i] = a[i];
}


template <class T>
  vector<T>::vector(const vector<T> &x)
{
  n = n_limit = 0;
  n_delta = x.n_delta;
  data = NULL;
  resize (x.get_n());
  if (matrix_status == st_ok)
    for (index j = 0; j < n; j++)
      data[j] = x.data[j];
}

template <class T>
  vector<T>  &vector<T>::operator = (const vector<T>  &x)
{
  if (this == &x)
    return *this;
  dispose_all ();
  resize (x.get_n());
  if (matrix_status != st_ok)
  {
    matrix_error(st_out_of_memory, "vector::operator = : can't assign matrix");
    return *this;
  }
  for (index j = 0; j < n; j++)
    data[j] = x.data[j];
  return *this;
}

template <class T>
  void vector<T> :: dispose_all ()
{
  delete [] data;
  data = NULL;
  n = n_limit = 0;
}

template <class T>
  vector<T> :: ~vector ()
{
  dispose_all ();
}

template <class T>
  T & vector<T> :: operator[](index j)
{
  if (!index_correct (j))
    matrix_fatal_error (st_incorrect_index,
      "vector::operator[]: incorrect index");
  return data[j];
}

template <class T>
  T vector<T>::at(index j) const
{
  if (!index_correct (j))
  {
    matrix_error (st_incorrect_index,
      "vector::at: incorrect index");
    return T(0);
  }
  return data[j];
}

template <class T>
  void vector<T>::resize (index new_n)
{
  if (!sizes_correct (new_n + n_delta))
  {
    matrix_error (st_out_of_range,
      "vector::can't resize vector:\n incorrect sizes");
    return;
  }
  T *new_data = new T[new_n + n_delta];
  if (!new_data)
  {
    matrix_error (st_out_of_memory, "vector::can't resize vector: out of memory");
    return;
  }
  dispose_all ();
  data = new_data;
  n = new_n;
  n_limit = new_n + n_delta;
  return;
}

template <class T>
ostream & operator << (ostream & s, const vector<T>  &x)
{
    s << x.get_n() << '\n';
  for (index j = 0; j < x.get_n(); j++)
    s << x.data[j] << '\t';
  s << '\n';
  if (s.fail ())
    matrix_error (st_output_error, "vector::output error");
  return s;
}

template <class T>
  istream & operator >> (istream & s, vector<T>  &x)
{
  index new_n=0;
  s >> new_n;
  x.resize (new_n);
  if (matrix_status == st_ok)
    for (index j = 0; j < x.get_n(); j++)
      s >> x[j];
  if (s.fail ())
    matrix_error (st_input_error, "vector::operator >> : input error");
  return s;
}

template <class T>
  void vector<T> :: ins_item (index j, T item)
{
  if (!index_correct(j) && j != n)
  {
    matrix_error(st_out_of_range, "vector::ins_item: incorrect index");
    return;
  }
  if (n < n_limit)
  {
    for (index jj = n; jj > j; jj--)
      data[jj] = data[jj - 1];
    n++;
    data[j] = item;
    return;
  }
  if (!sizes_correct (n + 1))
  {
    matrix_error (st_out_of_range, "vector::ins_item: too many items");
    return;
  }
  T *new_data = new T[n_limit + n_delta];
  if (!new_data)
  {
    matrix_error (st_out_of_memory,
      "vector::can't insert new item: out of memory \n vector is not correct");
    return;
  }
  index jj;
  for (jj = 0; jj < j; jj++)
    new_data[jj] = data[jj];
  new_data[jj] = item;
  for (jj = j; jj < n; jj++)
    new_data[jj + 1] = data[jj];
  delete [] data;
  data = new_data;
  n++;
  n_limit += n_delta;
  return;
}

template <class T>
  void vector<T>::join (T item)
{
  ins_item(get_n(), item);
}

template <class T>
  int vector<T>::member (T item) const
{
  if (index_of_item(item) == -1)
    return 0;
  else
    return 1;
}

template <class T>
  index vector<T>::index_of_item(T item) const
{
  for (index j = 0; j < n; j++)
    if (data[j] == item)
      return j;
  return -1;
}

template <class T>
  void vector<T> :: del_item (index j)
{
  if (!index_correct(j))
  {
    matrix_error(st_out_of_range, "vector::del_item: incorrect index");
    return;
  }
  for (index jj = j + 1; jj < n; jj++)
    data[jj - 1] = data[jj];
  n--;
}

template <class T>
  T vector<T> :: take_item (index j)
{
  T buf;
    if (!index_correct(j))
  {
    matrix_fatal_error(st_out_of_range, "vector::take_item: out of range");
    return buf;
  }
  buf = data[j];
  for (index jj = j + 1; jj < n; jj++)
    data[jj - 1] = data[jj];
  n--;
  return buf;
}

template <class T>
  void vector<T> :: swap_items (index j1, index j2)
{
  if (!index_correct(j1) || !index_correct(j2))
  {
    matrix_fatal_error(st_out_of_range, "vector::swap_items: out of range");
    return;
  }
  T buf;
  buf = data[j1];
  data[j1] = data[j2];
  data[j2] = buf;
}

template <class T>
  vector<T> operator + (const vector<T>  &a, const vector<T>  &b)
{
    if (a.get_n() != b.get_n())
  {
    matrix_error (st_inconsistent_sizes,
		  "vector::operator+ : different sizes of summand vectors");
    return a;
  }
  vector<T>  sum;
  sum.resize (a.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index j = 0; j < a.get_n(); j++)
    sum[j] = a.data[j] + b.data[j];
  return sum;
}

template <class T>
  vector<T> operator - (const vector<T>  &a, const vector<T>  &b)
{
    if (a.get_n() != b.get_n())
  {
    matrix_error (st_inconsistent_sizes,
		  "vector::operator- :different sizes of vectors");
    return a;
  }
  vector<T>  dif;
  dif.resize (a.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index j = 0; j < a.get_n(); j++)
    dif[j] = a.data[j] - b.data[j];
  return dif;
}

template <class T>
vector<T> & vector<T>::operator += (const vector<T> & x)
{
  if (n != x.get_n())
  {
    matrix_error (st_inconsistent_sizes,
		  "vector::operator+= :different sizes of vectors");
    return *this;
  }

  for (index j = 0; j < n; j++)
    data[j] = data[j] + x.data[j];

  return *this;
}

template <class T>
  vector<T> & vector<T>::operator -= (const vector<T> & x)
{
  if (n != x.get_n())
  {
    matrix_error (st_inconsistent_sizes,
		  "vector::operator-= :different sizes of vectors");
    return *this;
  }

  for (index j = 0; j < n; j++)
    data[j] = data[j] - x.data[j];

  return *this;
}

template <class T>
  vector<T> operator * (T alpha, const vector<T> & a)
{
  vector<T>  result;
  result.resize (a.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index j = 0; j < a.get_n(); j++)
    result[j] = alpha * a.data[j];
  return result;
}

template <class T>
  T operator * (const vector<T> & a, const vector<T> & b)
{
  T prod = 0;
  for (index j = 0; j < a.get_n(); j++)
    prod = prod + a.data[j] * b.data[j];
  return prod;
}

template <class T>
  int operator == (const vector<T>  &a, const vector<T>  &b)
{
if (a.get_n() != b.get_n())
  return 0;
for (index j = 0; j < a.get_n(); j++)
  if (a.data[j] != b.data[j])
    return 0;
return 1;
}

template <class T>
  int  operator != (const vector<T>  &a, const vector<T>  &b)
{
  return !(a == b);
}

template <class T>
  int vector<T>::index_correct (index j) const
{
  return ((j >= 0) && (j < n));
}

template <class T>
  T vector<T>::access (index j) const
{
  return data[j];
}

/***************************/
/*                         */
/*     class matrix<>      */
/*                         */
/***************************/

template <class T>
  matrix<T>::matrix (index m_init,	index n_init,
  index m_delta_init, index n_delta_init)
{
  m = n = m_limit = n_limit = 0;
  m_delta = m_delta_init;
  n_delta = n_delta_init;
  data = NULL;

  resize (m_init, n_init);
}

template <class T>
  matrix<T>::matrix (index m_init, index n_init, T* A,
  index m_delta_init, index n_delta_init)
{
  m = n = m_limit = n_limit = 0;
  m_delta = m_delta_init;
  n_delta = n_delta_init;
  data = NULL;

  resize (m_init, n_init);
  if (matrix_status != st_ok)
    return;

  for (index i = 0; i < m; i++)
    for (index j = 0; j < n; j++)
      data[i][j] = A[i*n + j];
}


template <class T>
  matrix<T> ::matrix (const matrix<T>  &x)
{
  n = n_limit = m = m_limit = 0;
  n_delta = x.n_delta;
  m_delta = x.m_delta;
  data = NULL;
  resize (x.get_m(), x.get_n());
  if (matrix_status != st_ok)
    return;
  for (index i = 0; i < m; i++)
    for (index j = 0; j < n; j++)
      data[i][j] = x.access(i, j);
}

template <class T>
  matrix<T> & matrix<T> :: operator = (const matrix<T>  &x)
{
  if (this == &x)
    return *this;
  dispose_all ();
  resize (x.get_m(), x.get_n());
  if (matrix_status != st_ok)
  {
    matrix_error(st_out_of_range, "matrix::operator= :can't assign matrix");
    return *this;
  }
  for (index i = 0; i < m; i++)
    for (index j = 0; j < n; j++)
      data[i][j] = x.access(i, j);
  return *this;
}

template <class T>
  void matrix<T> ::dispose_all ()
{
  if (!data)
    return;
  for (index i = 0; i < m; i++)
    delete [] data[i];
  delete [] data;
  data = NULL;
  m = n = m_limit = n_limit = 0;
}

template <class T>
  matrix<T> ::~matrix ()
{
  dispose_all ();
}

template <class T>
  T & matrix<T>::operator ()(index i, index j)
{
  if (!indices_correct (i, j))
    matrix_fatal_error (st_incorrect_index, "matrix::operator() :incorrect indices");
  return data[i][j];
}

template <class T>
  T matrix<T>::at(index i, index j) const
{
  if (!indices_correct (i, j))
  {
    matrix_error (st_incorrect_index, "matrix::at: incorrect indices");
    return T(0);
  }
  return data[i][j];
}

template <class T>
  void matrix<T>::resize (index new_m, index new_n)
{

  if (!sizes_correct(new_m + m_delta, new_n + n_delta))
  {
    matrix_error (st_out_of_range, "can't resize matrix:\n incorrect sizes");
    return;
  }
  T **new_data = new T *[new_m + m_delta];
  if (!new_data)
  {
    matrix_error (st_out_of_memory, "can't resize matrix: out of memory");
    return;
  }
  dispose_all ();
  data = new_data;
  /* now we are inserting rows */
  index m_count;
  for (m_count = 0; m_count < new_m; m_count++)
  {
    T *p = new T[new_n + n_delta];
    if (!p)
    {
      matrix_error (st_out_of_memory,
		    "can't correctly resize matrix: out of memory");
      break;
    }
    data[m_count] = p;
  }
  n = new_n;
  n_limit = new_n + n_delta;
  m = m_count;
  m_limit = new_m + m_delta;
}

template <class T> int matrix<T>::max_format() const
{
  int format = 0;
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
    {
      ostrstream s;
#ifdef __WATCOMC__
#  pragma warn -665
      (ostream)s << at(i, j) << ends; // I guess Watcom C bug
#  pragma warn +665
#else
      s << at(i, j) << ends;
#endif
      char *str = s.str();
      if (strlen(str) > format)
        format = strlen(str);
      delete [] str;
    }
  return format;
}


template <class T>
ostream & operator << (ostream & s, const matrix<T> &x)
{
  s << x.get_m() << ' ' << x.get_n() << '\n';
  for (index i = 0; i < x.get_m(); i++)
  {
    for (index j = 0; j < x.get_n(); j++)
      s << x.access(i, j) << '\t';
    s << '\n';
  }
  if (s.fail ())
    matrix_error (st_output_error, "matrix::output error");
  return s;
}

template <class T>
istream & operator >> (istream & s, matrix<T>& x)
{
  index new_m = 0, new_n = 0;
  s >> new_m >> new_n;
  x.resize (new_m, new_n);
  if (matrix_status == st_ok)
    for (index i = 0; i < x.get_m(); i++)
      for (index j = 0; j < x.get_n(); j++)
	s >> x (i, j);
  if (s.fail ())
    matrix_error (st_input_error, "matrix::operator >> : input error");
  return s;
}

template <class T>
  vector<T> matrix<T>::row (index i) const
{
  vector<T>  x;
  if (!indices_correct (i, -1))
  {
    matrix_error (st_incorrect_index, "matrix::row: incorrect index");
    return x;
  }
  x.resize(n);
  if (matrix_status == st_ok)
    for (index j = 0; j < n; j++)
      x[j] = data[i][j];
  return x;
}

template <class T>
  matrix<T> matrix<T>::rows (vector<index> indices) const
{
  matrix<T> result(indices.get_n(), n);
  if (matrix_status == st_ok)
    for (index i = 0; i < indices.get_n(); i++)
      for (index j = 0; j < n; j++)
	result(i, j) = at(indices[i], j);
  return result;
}

template <class T>
  void matrix<T> ::ins_row (index i)
{
  if (!sizes_correct (m + 1, n))
  {
    matrix_error (st_out_of_range, "matrix::ins_row: matrix is too big");
    return;
  }
  T *p = new T[n_limit];
  //storage for a  new row
    if (!p)
    {
      matrix_error (st_out_of_memory, "can't insert new row: out of memory");
      return;
    }
  ins_this_row (i, p);
  if (matrix_status != st_ok)
  {
    delete [] p;
    return;
  }
  return;
}

template <class T>
  void matrix<T> :: ins_row (index i, vector<T>  x)
{
  if (n != x.get_n ())
  {
    matrix_error (st_inconsistent_sizes,
		  "matrix::ins_row: can't insert row: sizes are inconsistent");
    return;
  }
  ins_row(i);
  if (matrix_status != st_ok)
    return;
  else
  {
    for (index j = 0; j < n; j++)
      data[i][j] = x[j];
    return;
  }
}

template <class T>
  void matrix<T> :: join_row (vector<T>  x)
{
  ins_row(m, x);
}

template <class T>
  void matrix<T>::ins_this_row (index i, T * p)
{
  if (!indices_correct (i, -1) && i != m)
  {
    matrix_error (st_incorrect_index, "matrix::ins_this_row: incorrect index");
    return;
  }
  if (m < m_limit)
  {
    memmove (&(data[i + 1]), &(data[i]), sizeof (T *) * (m - i));
    m++;
    data[i] = p;
  }
  else
  {
    index new_m = m_limit + m_delta;
    T **new_data = new T *[new_m];
    if (!new_data)
    {
      matrix_error (st_out_of_memory, "can't insert new row: out of memory");
      return;
    }
    memmove (new_data, data, sizeof (T *) * i);
    memmove (&(new_data[i + 1]), &(data[i]), sizeof (T *) * (m - i));
    delete [] data;
    data = new_data;
    m++;
    m_limit += m_delta;
    data[i] = p;
  }
  return;
}

template <class T>
  void matrix<T> :: del_row (index i)
{
  take_row(i);
}

template <class T>
  vector<T> matrix<T> :: take_row (index i)
{
  vector<T>  x;
    x = row (i);
  if (matrix_status != st_ok)
    return x;
  if (data)
    delete [] data[i];
  memmove (&(data[i]), &(data[i + 1]), sizeof (T *) * (m - i - 1));
  m--;
  return x;
}

template <class T>
  void matrix<T>::del_rows (vector<index> indices)
{
  // first we dispose rows
  for (index i = 0; i < indices.get_n(); i++)
  {
    if (!indices_correct (indices[i], -1))
    {
      matrix_error (st_incorrect_index, "matrix::del_rows: incorrect index");
      continue;
    }
    delete [] data[indices[i]];
    data[indices[i]] = NULL;
  }

  // second we del null rows
  index new_i = 0;
  for (index i = 0; i < m; i++)
  {
    if (!indices_correct (i, -1))
      continue;
    if (data[i])
    {
      data[new_i] = data[i];
      new_i++;
    }
  }
  m = new_i;

}

template <class T>
  matrix<T> matrix<T>::take_rows (vector<index> indices)
{
  matrix<T> result(0, n);
  if (matrix_status != st_ok)
    return result;

  for (index i = 0; i < indices.get_n(); i++)
  {
    if (!indices_correct (indices[i], -1))
    {
      matrix_error (st_incorrect_index, "matrix::take_rows: incorrect index");
      continue;
    }
    if (data[indices[i]])
    {
      T* current_row = data[indices[i]];
      result.ins_this_row(i, current_row);
      data[indices[i]] = NULL;
    }
    else
    {
      // the row indices[i] has been just taken !
      index old_copy = indices.index_of_item(indices[i]);
      result.join_row(result.row(old_copy));
    }
  }

  // delete null rows
  index new_i = 0;
  for (index i = 0; i < m; i++)
  {
    if (data[i])
    {
      data[new_i] = data[i];
      new_i++;
    }
  }
  m = new_i;

  return result;
}



template <class T>
  void matrix<T> :: add_row (index i1, index i2, T alpha)
{
  if (indices_correct (i1, -1) && indices_correct (i2, -1))
    for (index j = 0; j < n; j++)
      data[i1][j] = data[i1][j] + data[i2][j] * alpha;
  else
    matrix_error (st_incorrect_index, "matrix::can't add rows: incorrect indices");
}

template <class T>
 void matrix<T> ::add_rows (index i1, T alpha1, index i2, T alpha2)
{
  if (!indices_correct (i1, -1) || !indices_correct (i2, -1))
  {
    matrix_error (st_incorrect_index, "matrix::can't add rows: incorrect indices");
    return;
  }
  ins_row(m);
  if (matrix_status == st_ok)
  {
    for (index j = 0; j < n; j++)
      data[m - 1][j] =
	data[i1][j] * alpha1 + data[i2][j] * alpha2;
    return;
  }
  else
    return;
}

template <class T>
  void matrix<T> ::mult_row (index i, T alpha)
{
  if (indices_correct (i, -1))
    for (index j = 0; j < n; j++)
      data[i][j] = data[i][j] * alpha;
  else
    matrix_error (st_incorrect_index, "matrix::can't mult row: incorrect index");
}

template <class T>
  void matrix<T> ::div_row (index i, T alpha)
{
  if (indices_correct (i, -1))
    for (index j = 0; j < n; j++)
      data[i][j] = data[i][j] / alpha;
  else
    matrix_error (st_incorrect_index, "matrix::can't div row: incorrect index");
}

template <class T>
  void matrix<T> ::swap_rows (index i1, index i2)
{
  if (!indices_correct (i1, -1) || !indices_correct (i2, -1))
  {
    matrix_error (st_incorrect_index, "matrix::can't swap rows: incorrect indices");
    return;
  }
  T * buf = data[i1];
  data[i1] = data[i2];
  data[i2] = buf;
}

template <class T>
  vector<T> matrix<T>::col(index j) const
{
  vector<T>  x;
  if (!indices_correct (-1, j))
  {
    matrix_error (st_incorrect_index, "matrix::col: incorrect index");
    return x;
  }
  x.resize (m);
  if (matrix_status == st_ok)
    for (index i = 0; i < m; i++)
      x[i] = data[i][j];
  return x;
}

template <class T>
  matrix<T> matrix<T>::cols (vector<index> indices) const
{
  matrix<T> result(m, indices.get_n());
  if (matrix_status == st_ok)
    for (index j = 0; j < indices.get_n(); j++)
      for (index i = 0; i < m; i++)
	result.data[i][j] = at(i, indices[j]);
  return result;
}

template <class T>
 void matrix<T> ::ins_col (index j)
{
  if (!indices_correct(-1, j) && j !=n)
  {
    matrix_error (st_incorrect_index, "matrix::can't ins col: incorrect index");
    return;
  }
  if (n < n_limit)
  {
    for (index ii = 0; ii < m; ii++)
      for (index jj = n; jj > j; jj--)
	data[ii][jj] = data[ii][jj - 1];
    n++;
    return;
  }

  if (!sizes_correct (m, n + 1))
  {
    matrix_error (st_out_of_range, "matrix::ins_col: too many columns");
    return;
  }

  for (index i = 0; i < m; i++)
  {
    T *p = new T[n_limit + n_delta];
    if (!p)
    {
      matrix_error (st_out_of_memory,
	 "matrix::can't insert new column: out of memory \n matrix is not correct");
      return;
    }
    index jj;
    for (jj = 0; jj < j; jj++)
      p[jj] = data[i][jj];
    for (jj = j; jj < n; jj++)
      p[jj + 1] = data[i][jj];
    delete [] data[i];
    data[i] = p;
  }
  n++;
  n_limit += n_delta;

  return;
}

template <class T>
 void matrix<T> ::ins_col (index j, vector<T>  x)
{
  if (m != x.get_n ())
  {
    matrix_error (st_inconsistent_sizes,
      "matrix::can't insert column: sizes are inconsistent");
    return;
  }
  ins_col (j);
  if (matrix_status != st_ok)
    return;
  else
  {
    for (index i = 0; i < m; i++)
      data[i][j] = x[i];
    return;
  }
}

template <class T>
 void matrix<T> :: join_col (vector<T>  x)
{
  ins_col(n, x);
}

template <class T>
  void matrix<T>::del_col (index j)
{
  take_col(j);
}

template <class T>
  vector<T> matrix<T>::take_col (index j)
{
  vector<T> x;
  x = col (j);
  if (matrix_status != st_ok)
    return x;
  for (index i = 0; i < m; i++)
    for (index jj = j + 1; jj < n; jj++)
      data[i][jj - 1] = data[i][jj];
  n--;
  return x;
}

template <class T>
  void matrix<T>::del_cols (vector<index> indices)
{
  vector<int> disposed_cols(n);

  if (matrix_status != st_ok)
    return;


  // first we remember cols to delete
  for (index j = 0; j < n; j++)
    disposed_cols[j] = 0;
  for (index j = 0; j < indices.get_n(); j++)
    disposed_cols[indices[j]] = 1;

  // second we delete cols
  index new_j = 0;
  for (index j = 0; j < n; j++)
  {
    if (disposed_cols[j])
    {
      for (index i = 0; i < m; i++)
	data[i][new_j] = data[i][j];
      new_j++;
    }
  }
  n = new_j;
}

template <class T>
  matrix<T> matrix<T>::take_cols (vector<index> indices)
{
  matrix<T> result = cols(indices);
  del_cols(indices);
  return result;
}


template <class T>
  void matrix<T> ::add_col (index j1, index j2, T alpha)
{
  if (!indices_correct (-1, j1) || !indices_correct (-1, j2))
  {
    matrix_error (st_incorrect_index, "matrix::can't add cols: incorrect indices");
    return;
  }
  for (index i = 0; i < m; i++)
    data[i][j1] = data[i][j1] + data[i][j2] * alpha;
}

template <class T>
 void matrix<T> ::add_cols (index j1, T alpha1, index j2, T alpha2)
{
  if (!indices_correct (-1, j1) || !indices_correct (-1, j2))
  {
    matrix_error (st_incorrect_index,
		  "matrix::can't add columns: incorrect indices");
    return;
  }
  ins_col (n);
  if (matrix_status == st_ok)
  {
    for (index i = 0; i < m; i++)
      data[i][n - 1] =
	data[i][j1] * alpha1 + data[i][j2] * alpha2;
    return;
  }
  else
    return;
}

template <class T>
  void matrix<T> ::mult_col (index j, T alpha)
{
  if (!indices_correct (-1, j))
  {
    matrix_error (st_incorrect_index, "matrix::can't mult col: incorrect indices");
    return;
  }
  for (index i = 0; i < m; i++)
    data[i][j] = data[i][j] * alpha;
}

template <class T>
  void matrix<T> ::div_col (index j, T alpha)
{
  if (!indices_correct (-1, j))
  {
    matrix_error (st_incorrect_index, "matrix::can't div col: incorrect indices");
    return;
  }
    for (index i = 0; i < m; i++)
    data[i][j] = data[i][j] / alpha;
}

template <class T>
  void matrix<T> ::swap_cols (index j1, index j2)
{
  if (!indices_correct (-1, j1) || !indices_correct (-1, j2))
  {
    matrix_error (st_incorrect_index,
		  "matrix::can't swap columns: incorrect indices");
    return;
  }
  T buf;
  for (index i = 0; i < m; i++)
  {
    buf = data[i][j1];
    data[i][j1] = data[i][j2];
    data[i][j2] = buf;
  }
}

template <class T>
  matrix<T> matrix<T>::sumbatrix(vector<index> r, vector<index> c)
{
  matrix<T> result(r.get_n(), c.get_n());
  if (matrix_status != st_ok)
    return result;
  for (index i = 0; i < r.get_n(); i++)
    if (!indices_correct(r[i], -1))
    {
      matrix_fatal_error (st_incorrect_index, "matrix::submatrix: incorrect index");
      return result;
    }
  for (index j = 0; j < c.get_n(); j++)
    if (!indices_correct(c[j], -1))
    {
      matrix_fatal_error (st_incorrect_index, "matrix::submatrix: incorrect index");
      return result;
    }
  for (index i = 0; i < r.get_n(); i++)
    for (index j = 0; j < c.get_n(); j++)
      result.data[i][j] = data[r[i]][c[j]];
  return result;
}

template <class T>
  matrix<T>  matrix<T> ::operator - ()
{
  matrix<T>  x (m, n);
  for (index i = 0; i < m; i++)
    for (index j = 0; j < n; j++)
#ifdef __BORLANDC__
      x (i, j) = 0-data[i][j];
#else
      x (i, j) = -data[i][j];
#endif
  return x;
}

template <class T>
  matrix<T> operator + (const matrix<T>  &a, const matrix<T>  &b)
{
    if ((a.get_n() != b.get_n()) || (a.get_m() != b.get_m()))
  {
    matrix_error (st_inconsistent_sizes,
		  "matrix::operator+ : different sizes of summand matrices");
    return a;
  }
  matrix<T>  sum;
  sum.resize (a.get_m(), a.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index i = 0; i < a.get_m(); i++)
    for (index j = 0; j < a.get_n(); j++)
      sum (i, j) = a.access(i, j) + b.access(i, j);
  return sum;
}

template <class T>
  matrix<T> operator * (const matrix<T>  &a, const matrix<T>  &b)
{
    if (a.get_n() != b.get_m())
  {
    matrix_error (st_inconsistent_sizes,
      "operator * : inconsistent sizes of prodotted matrices");
    return a;
  }
  matrix<T>  result;
  result.resize (a.get_m(), b.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index i = 0; i < result.get_m(); i++)
    for (index j = 0; j < result.get_n(); j++)
    {
      result (i, j) = 0;
      for (index k = 0; k < a.get_n(); k++)
	result (i, j) = result(i, j) + a.access(i, k) * b.access(k, j);
    }
  return result;
}


/*
template <class T>
  matrix<T> operator *(const matrix<T> & a, const vector<T> & v)
{
    if (a.get_n() != v.get_n())
  {
    matrix_error (st_inconsistent_sizes,
      "operator * : inconsistent sizes of prodotted matrices");
    return a;
  }
  matrix<T> result;
  result.resize (a.get_m(), v.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index i = 0; i < result.get_m(); i++)
    for (index j = 0; j < result.get_n(); j++)
    {
      result (i, j) = 0;
      for (index k = 0; k < a.get_n(); k++)
	result (i, j) = result(i, j) + a.data[i][k] * b.data[k][j];
    }
  return result;
}
*/

//friend matrix<T> operator *(const vector<T> & v, const matrix<T> & a)


template <class T>
  matrix<T> operator * (T alpha, const matrix<T>  &a)
{
  matrix<T>  result;
  result.resize (a.get_m(), a.get_n());
  if (matrix_status != st_ok)
    return a;
  for (index i = 0; i < a.get_m(); i++)
    for (index j = 0; j < a.get_n(); j++)
      result (i, j) = alpha * a.data[i][j];
  return result;
}

template <class T>
  matrix<T> transpose (const matrix<T>  &a)
{
  matrix<T>  result;
  result.resize (a.get_n(), a.get_m());
  if (matrix_status != st_ok)
    return a;
  for (index i = 0; i < a.get_n(); i++)
    for (index j = 0; j < a.get_m(); j++)
      result (i, j) = a.data[j][i];
  return result;
}

template <class T>
  int  operator == (const matrix<T>  &a, const matrix<T>  &b)
{
    if ((a.get_n() != b.get_n()) || (a.get_m() != b.get_m()))
    return 0;
  for (index i = 0; i < a.get_m(); i++)
    for (index j = 0; j < a.get_n(); j++)
      if (a.data[i][j] != b.data[i][j])
	return 0;
  return 1;
}

template <class T>
  int  operator != (const matrix<T>  &a, const matrix<T>  &b)
{
  return !(a == b);
}

template <class T>
  int matrix<T> :: indices_correct (index i, index j) const
{
  return (
       i == -1 && j >= 0 && j < n
    || j == -1 && i >= 0 && i < m
    || i >= 0 && i < m && j >= 0 && j < n);
}

template <class T>
  T matrix<T> :: access (index i, index j) const
{
  return data[i][j];
}

template <class T>
  matrix<T> diag(const vector<T>& d)
{
  index n = d.get_n();
  matrix<T> D(n, n);
  if (matrix_status != st_ok)
    return D;
  for (index i = 0; i < n; i++)
    for (index j = 0; j < n; j++)
      if (i != j)
	D.data[i][j] = 0;
      else
	D.data[i][j] = d.at(i);
  return D;
}

template <class T>
  matrix<T> diag(T a, index m, index n)
{
  matrix<T> D(m, n);
  if (matrix_status != st_ok)
    return D;
  for (index i = 0; i < m; i++)
    for (index j = 0; j < n; j++)
      if (i != j)
	D.data[i][j] = T(0);
      else
	D.data[i][j] = a;
  return D;
}

template <class T>
  matrix<T> diag(T a, index m)
{
  return diag(a, m, m);
}

template <class T>
  matrix<T> eye (T a, index m, index n)
{
  return diag(T(1), m, n);
}

template <class T>
  matrix<T> eye(T a, index m)
{
  return diag(T(1), m);
}

template <class T>
  matrix<T> fill(T a, index m, index n)
{
  matrix<T> D(m, n);
  if (matrix_status != st_ok)
    return D;
  for (index i = 0; i < m; i++)
    for (index j = 0; j < n; j++)
      D.data[i][j] = a;
  return D;
}

template <class T>
  matrix<T> fill(T a, index m)
{
  return fill(a, m, m);
}

template <class T>
  matrix<T> zero(T a, index m, index n)
{
  return fill(T(0), m, n);
}

template <class T>
  matrix<T> zero(T a, index m)
{
  return fill(T(0), m);
}

template <class T>
  void mesh_grid(vector<T>& v, T begin, T end, T step)
{
  index size = (end - begin)/step + 1;
  v.resize(size);
  for (index j = 0; j < size; j++)
  {
    v[j] = begin;
    begin = begin + step;
  }
}

template <class T>
  void pretty(ostr & s, const vector<T>& v)
{
  s << "\\left(";
  for (index j = 0; j < v.get_n(); j++)
  {
    if (j > 0)
      s << ", & ";
    s << v.at(j);
  }
  s << "\\right) ^{\rm T} \n";
}

template <class T>
  void pretty(ostr & s, const matrix<T>& A)
{
  s << "\\left(\n\\begin{array}{";
  for (index j = 0; j < A.get_n(); j++)
    s << "r";
  s << "} \n";
  for (index i = 0; i < A.get_m(); i++)
  {
    for (index j = 0; j < A.get_n(); j++)
    {
      if (j > 0)
        s << "\t & ";
      s << A.at(i, j);
    }
    s << " \\\\ \n";
  }
  s << "\\end{array}\n\\right) \n";
}


/** Prints matrices in the form:

      A B
*/
template <class T>
  void print2(ostr & s,
  const matrix<T>& A, const matrix<T>& B)
{
  int format = A.max_format();
  if (format < B.max_format())
    format = B.max_format();

  s << " �";
  for (int j = 0; j < (format + 1) * A.get_n(); j++)
    s << "�";
  s << "��";
  for (int j = 0; j < (format + 1) * B.get_n(); j++)
    s << "�";
  s <<  "Ŀ\n";

  for (int i = 0; i < A.get_m(); i++)
  {
    s << " �";
    for (int j = 0; j < A.get_n(); j++)
    {
      s << " ";
      s.width(format);
      s << A.at(i, j);
    }
    s << " �";
    for (int j = 0; j < B.get_n(); j++)
    {
      s << " ";
      s.width(format);
      s << B.at(i, j);
    }
    s << " �\n";
  };

  s << " �";
  for (int j = 0; j < (format + 1) * A.get_n(); j++)
    s << "�";
  s << "��";
  for (int j = 0; j < (format + 1) * B.get_n(); j++)
    s << "�";
  s << "��\n";

};

/** Prints matrices in the form:

        A
      B C
*/
template <class T>
  void print3(ostr & s,
  const matrix<T>& A, const matrix<T>& B, const matrix<T>& C)
{
  int format = A.max_format();
  if (format < B.max_format())
    format = B.max_format();
  if (format < C.max_format())
    format = C.max_format();

  s << "  ";
  for (int j = 0; j < (format + 1) * B.get_n(); j++)
    s << " ";
  s << " �";
  for (int j = 0; j < (format + 1) * A.get_n(); j++)
    s << "�";
  s << "Ŀ\n";

  for (int i = 0; i < A.get_m(); i++)
  {
    s << "  ";
    for (int j = 0; j < (format + 1) * B.get_n(); j++)
      s << " ";
    s << " �";
    for (int j = 0; j < A.get_n(); j++)
    {
      s.width(format);
      s << A.at(i, j) << " ";
    }
    s << " �\n";
  };

  s << " �";
  for (int j = 0; j < (format + 1) * B.get_n(); j++)
    s << "�";
  s << "��";
  for (int j = 0; j < (format + 1) * A.get_n(); j++)
    s << "�";
  s <<  "Ĵ\n";

  for (int i = 0; i < B.get_m(); i++)
  {
    s << " �";
    for (int j = 0; j < B.get_n(); j++)
    {
      s.width(format);
      s << B.at(i, j) << " ";
    }
    s << " �";
    for (int j = 0; j < C.get_n(); j++)
    {
      s.width(format);
      s << C.at(i, j) << " ";
    }
    s << " �\n";
  };

  s << " �";
  for (int j = 0; j < (format + 1) * B.get_n(); j++)
    s << "�";
  s << "��";
  for (int j = 0; j < (format + 1) * A.get_n(); j++)
    s << "�";
  s << "��\n";

};


#endif

