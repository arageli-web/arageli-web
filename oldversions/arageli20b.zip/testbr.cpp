//********************************************************************
// testbr.cpp           Big rational arithmetics test
//
//N.Yu.Zolotykh 1999, 2000
//University of Nizhni Novgorod, Russia
//********************************************************************

 /** \file
    A demo program for bigarith and rational modules. */

//#define USE_ASM

#include<iostream.h>
#include "rational.h"
#include "bigarith.h"
#include "powerest.h"

#if defined(__BORLANDC__) && !defined(__WIN32__)
#  include <alloc.h>
#endif


typedef rational<big_int> number;

void main()
{

#if defined(__BORLANDC__) && !defined(__WIN32__)
  long memavail = coreleft();
#endif

{
  number a, b;

  cout << "for exit enter b=0 \n";

  while (1)
  {
    cout << "a..";
    cin >> a;
    cout << "b..";
    cin >> b;

    if (b == (number)0)
      break;

    number sum = a + b;
    number sub = a - b;
    number mul = a * b;
    number quo = a / b;

    cout << "a+b     = " << sum << "\n"
      << "a-b     = " << sub << "\n"
      << "a*b     = " << mul << "\n"
      << "a/b     = " << quo << "\n";

    int error_count = 0;
    if (sum - b != a)
    {
      error_count++;
      cout << "error in addition \n";
    }
    if (sub + b != a)
    {
      error_count++;
      cout << "error in subtraction \n";
    }
    if (a != b * quo)
    {
      error_count++;
      cout << "error in division \n";
    }
    if (!error_count)
      cout << "ok\n";
  }

}

#if defined(__BORLANDC__) && !defined(__WIN32__)
memavail = coreleft() - memavail;
cout << " mem = " << memavail << " must be zero" << "\n" ;
#endif

}
