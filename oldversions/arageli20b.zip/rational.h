//********************************************************************
// Rational.h
//
//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia
//********************************************************************


#ifndef RATIONAL_H_
#define RATIONAL_H_

#include<iostream.h>
#include<stdlib.h>
#include<strstrea.h>
#include<string.h>
#include<ctype.h>
#include"gcd.h"


/**
    \file
    Rational numbers.
    The module containes implementation for a rational number
 */

#if defined(__BORLANDC__) && defined(__WIN32__) //bc 5.5/
template <class T> class rational;
template <class T> istream & operator >> (istream & s, rational<T> & x);
template <class T> ostream & operator << (ostream & s, const rational<T> & x);
template <class T> int cmp(const rational<T> & a, const rational<T> & b);
template <class T> int operator == (const rational<T> & a, const rational<T> & b);
template <class T> int operator != (const rational<T> & a, const rational<T> & b);
template <class T> int operator >  (const rational<T> & a, const rational<T> & b);
template <class T> int operator >= (const rational<T> & a, const rational<T> & b);
template <class T> int operator <  (const rational<T> & a, const rational<T> & b);
template <class T> int operator <= (const rational<T> & a, const rational<T> & b);
template <class T> int is_integer(const rational<T> & a);
template <class T> rational<T> ceil(const rational<T> & a);
template <class T> rational<T> floor(const rational<T> & a);
template <class T> rational<T> frac(const rational<T> & a);
template <class T> T iceil(const rational<T> & a);
template <class T> T ifloor(const rational<T> & a);
template <class T> rational<T> operator + (const rational<T> & a);
template <class T> rational<T> operator - (const rational<T> & a);
template <class T> rational<T> operator + (const rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator - (const rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator * (const rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator / (const rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator += (rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator -= (rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator *= (rational<T> & b, const rational<T> & c);
template <class T> rational<T> operator /= (rational<T> & b, const rational<T> & c);
#endif

/** Implementation of a Rational Number.
    An instance of this type is a rational number where the numerator
    and the denominator are both of type T. */

template <class T>
class rational
{
public:

  /**
     \example testbr.cpp A demo program for bigarith and rational modules.
   */
  /**
     \example testbigr.cpp A test program for bigarith and rational modules.
   */
  /**
     \example testbrio.cpp
     A test program for bigarith and rational input-output routines.
   */
  /**
     \example sc.cpp
     A simple big rational calculator.
   */

  rational(); ///< Creates an instance of type rational
  rational(char* str);  ///< Converts s to a rational number
  rational(const rational<T>& b); ///< Makes a copy of a number
  rational(int w);  ///<  Creates an instance and initializes it with the value of w
  rational(T w);  ///<  Creates an instance and initializes it with the value of w
  rational(T u, T v); ///<  Creates an instance and initializes it with the value of u/w

  rational<T> & operator = (const rational<T>& b);  ///< Assignment

  /** Sign of a number.
      Returns
        -  0  if x = 0,
        -  -1 if x < 0,
        -  1  if x > 0.
   */
  int sign() const;

  //void to_string(char* s) const;  ///< Converts a rational to a string

#if !defined(__BORLANDC__) || !defined(__WIN32__) //!bc 5.5/
  /// Writes a rational number
  friend ostream & operator <<  (ostream & s, const rational<T> & x);
  /// Reads a rational number
  friend istream & operator >> (istream & s, rational<T> & x);

  /** Compares two rationals.
      Returns
        -  0  if a = b,
        -  -1 if a < b,
        -  1  if a > b.
   */
  friend int cmp (const rational<T> & a, const rational<T> & b);
  /// Test for equality
  friend int operator == (const rational<T> & a, const rational<T> & b);
  /// Test for inequality
  friend int operator != (const rational<T> & a, const rational<T> & b);
  /// Test for greater
  friend int operator > (const rational<T> & a, const rational<T> & b);
  /// Test for greater than or equal to
  friend int operator >= (const rational<T> & a, const rational<T> & b);
  /// Test for less
  friend int operator <  (const rational<T> & a, const rational<T> & b);
  /// Test for less than or equal to
  friend int operator <= (const rational<T> & a, const rational<T> & b);
  /// Returns 1 if a is integer
  friend int is_integer (const rational<T> & a);
  /// Returns the next bigger integer
  friend rational<T> ceil (const rational<T> & a);
  /// Returns the next smaller integer
  friend rational<T> floor (const rational<T> & a);
  /// Returns the fractal part of the number
  friend rational<T> frac(const rational<T> & a);
  /// Returns the next bigger integer
  friend T iceil (const rational<T> & a);
  /// Returns the next smaller integer
  friend T ifloor (const rational<T> & a);
  friend rational<T> operator + (const rational<T> & a); ///< Unary plus
  friend rational<T> operator - (const rational<T> & a); ///< Unary minus
  /// Binary plus
  friend rational<T> operator + (const rational<T> & b, const rational<T> & c);
  /// Binary minus
  friend rational<T> operator - (const rational<T> & b, const rational<T> & c);
  /// Multiplication
  friend rational<T> operator * (const rational<T> & b, const rational<T> & c);
  /// Divizion
  friend rational<T> operator / (const rational<T> & b, const rational<T> & c);
  /// Combined assignment-addition operator
  friend rational<T> operator += (rational<T> & b, const rational<T> & c);
  /// Combined assignment-subtraction operator
  friend rational<T> operator -= (rational<T> & b, const rational<T> & c);
  /// Combined assignment-multiplication operator
  friend rational<T> operator *= (rational<T> & b, const rational<T> & c);
  /// Combined assignment-division operator
  friend rational<T> operator /= (rational<T> & b, const rational<T> & c);
#else // bc 5.5
  friend ostream & operator <<<T>  (ostream & s, const rational<T> & x);
  friend istream & operator >><T> (istream & s, rational<T> & x);
  friend int cmp<T> (const rational<T> & a, const rational<T> & b);
  friend int operator ==<T> (const rational<T> & a, const rational<T> & b);
  friend int operator !=<T> (const rational<T> & a, const rational<T> & b);
  friend int operator > <T>(const rational<T> & a, const rational<T> & b);
  friend int operator >=<T> (const rational<T> & a, const rational<T> & b);
  friend int operator < <T> (const rational<T> & a, const rational<T> & b);
  friend int operator <=<T> (const rational<T> & a, const rational<T> & b);
  friend int is_integer<T> (const rational<T> & a);
  friend rational<T> ceil<T> (const rational<T> & a);
  friend rational<T> floor<T> (const rational<T> & a);
  friend rational<T> frac<T> (const rational<T> & a);
  friend T iceil<T> (const rational<T> & a);
  friend T ifloor<T> (const rational<T> & a);
  friend rational<T> operator +<T> (const rational<T> & a); ///< Unary plus
  friend rational<T> operator -<T> (const rational<T> & a); ///< Unary minus
  friend rational<T> operator +<T> (const rational<T> & b, const rational<T> & c);
  friend rational<T> operator -<T> (const rational<T> & b, const rational<T> & c);
  friend rational<T> operator *<T> (const rational<T> & b, const rational<T> & c);
  friend rational<T> operator /<T> (const rational<T> & b, const rational<T> & c);
  friend rational<T> operator +=<T> (rational<T> & b, const rational<T> & c);
  friend rational<T> operator -=<T> (rational<T> & b, const rational<T> & c);
  friend rational<T> operator *=<T> (rational<T> & b, const rational<T> & c);
  friend rational<T> operator /=<T> (rational<T> & b, const rational<T> & c);
#endif

#if !defined(__BORLANDC__) || !defined(__WIN32__) //!bc 5.5/
private:
#endif

  // the following types are used inside the big_arith unit and implement
  // the storage for a Rational Number

  T p; // numerator
  T q; // denominator

  void optimize();

};

void rational_warning(const char* s)
{
  cerr << "Rationals Warning: " << s << "\n";
}

void rational_error(const char* s)
{
  cerr << "Rationals Error: " << s << "\n";
}

void rational_fatal_error(const char* s)
{
  cerr << "Rationals Fatal Error: \n " << s << "\n";
  exit(1);
}

template <class T> rational<T>::
  rational()
{
  p = 0;
  q = 1;
}

template <class T> rational<T>::
  rational(char* str)
{
  rational<T> a;
#ifdef __WATCOMC__
#  pragma warn -665
  (istream)(istrstream) str >> a;  // I guess Watcom C bug
#  pragma warn +665
#else
  (istrstream) str >> a;
#endif
  *this = a;
}

template <class T> rational<T>::
  rational(const rational<T> & b)
{
  p = b.p;
  q = b.q;
}

template <class T> rational<T>::
  rational(int w)
{
  p = w;
  q = 1;
}

template <class T> rational<T>::
  rational(T w)
{
  p = w;
  q = 1;
}


template <class T> rational<T>::
  rational(T u, T v)
{
  p = u;
  q = v;
  optimize();
}

template <class T> rational<T> & rational<T>::
  operator = (const rational<T> & b)
{
  p = b.p;
  q = b.q;
  return *this;
}


template <class T>
  ostream & operator << (ostream & s, const rational<T> & x)
{
  if (x.q == 1)
    return s << x.p;

  ostrstream tmp_stream;
#ifdef __WATCOMC__
#  pragma warn -665
  (ostream)tmp_stream << x.p << "/" << x.q << ends;
#  pragma warn +665
#else
  tmp_stream << x.p << "/" << x.q << ends;
#endif
  char *str = tmp_stream.str();
  s << str;
  delete [] str;
  return s;
}

template <class T>
  istream & operator >> (istream & s, rational<T>& x)
{
  T p, q;
  s >> p;
  char ch;
  s.get(ch);
  if (ch != '/')
  {
    s.putback(ch);
    x = p;
  }
  else
  {
    s >> q;
    x = (rational<T>) p / (rational<T>) q;
  }
  return s;
}

template <class T> int
  is_integer(const rational<T> & a)
{
	if (a.q == 1)
	  return 1;
	return 0;
}

template <class T> rational<T>
  operator + (const rational<T> & b, const rational<T> & c)
{
  rational<T> a;
  a.p = b.p * c.q + c.p * b.q;
  a.q = b.q * c.q;
  a.optimize();
  return a;
}

template <class T> rational<T>
  operator - (const rational<T> & b, const rational<T> & c)
{
  rational<T> a;
  a.p = b.p * c.q - c.p * b.q;
  a.q = b.q * c.q;
  a.optimize();
  return a;
}

template <class T> rational<T>
  operator * (const rational<T> & b, const rational<T> & c)
{
  rational<T> a;
  T first_gcd  = gcd(b.p, c.q);
  T second_gcd = gcd(c.p, b.q);
  a.p = (b.p/first_gcd) * (c.p/second_gcd);
  a.q = (b.q/second_gcd) * (c.q/first_gcd);
  a.optimize();
  return a;
}

template <class T> rational<T>
  operator / (const rational<T> & b, const rational<T> & c)
{
  rational<T> a;
  T first_gcd  = gcd(b.p, c.p);
  T second_gcd = gcd(c.q, b.q);
  a.p = (b.p/first_gcd) * (c.q/second_gcd);
  a.q = (b.q/second_gcd) * (c.p/first_gcd);
  a.optimize();
  return a;
}

template <class T> rational<T>
  operator += (rational<T> & b, const rational<T> & c)
{
  return b = b + c;
}

template <class T> rational<T>
  operator -= (rational<T> & b, const rational<T> & c)
{
  return b = b - c;
}

template <class T> rational<T>
  operator *= (rational<T> & b, const rational<T> & c)
{
  return b = b * c;
}

template <class T> rational<T>
  operator /= (rational<T> & b, const rational<T> & c)
{
  return b = b / c;
}

template <class T> int rational<T>::sign() const
{
  if (p ==T(0)) return 0;
  if (((p > T(0)) && (q > T(0))) || ((p < T(0)) && (q < T(0)))) return 1;
  return -1;
}

template <class T>
  int cmp(const rational<T> & a, const rational<T> & b)
{
  return (a - b).sign();
}

template <class T> int
  operator < (const rational<T> & a, const rational<T> & b)
{
  return cmp(a, b) == -1;
}

template <class T>
  int operator == (const rational<T> & a, const rational<T> & b)
{
  return  cmp(a, b) == 0;
}

template <class T>
int operator != (const rational<T> & a, const rational<T> & b)
{
  return  cmp(a, b) != 0;
}

template <class T>
int operator >  (const rational<T> & a, const rational<T> & b)
{
  return  cmp(a, b) == 1;
}

template <class T>
int operator >= (const rational<T> & a, const rational<T> & b)
{
  return  cmp(a, b) != -1;
}

template <class T>
int operator <= (const rational<T> & a, const rational<T> & b)
{
  return  cmp(a, b) != 1;
}

template <class T>
rational<T> operator + (const rational<T> & a) // unary plus
{
  return a;
}

template <class T>
rational<T> operator - (const rational<T> & b) // unary minus
{
  rational<T> a = b;
  a.p = -a.p;
  return a;
}

template <class T> void rational<T>::
  optimize()
{
  if (q < 0)
  {
    p = -p;
    q = -q;
  }
  T d = gcd(p, q);
  p = p / d;
  q = q / d;
}

template <class T>
  rational<T> floor(const rational<T> & a)
{
  return ifloor(a);
}

template <class T>
  T ifloor(const rational<T> & a)
{
  T result = a.p / a.q;
  if (a.p % a.q == 0)
    return result;
  if (a.p >= 0)
    return result;
  return result - 1;
}

template <class T>
  rational<T> ceil(const rational<T> & a)
{
  return iceil(a);
}

template <class T>
  T iceil(const rational<T> & a)
{
  T result = a.p / a.q;
  if (a.p % a.q == 0)
    return result;
  if (a.p < 0)
    return result;
  return result + 1;
}

template <class T>
  rational<T> frac(const rational<T> & a)
{
  return a - floor(a);
}



#endif // RATIONAL_H_
