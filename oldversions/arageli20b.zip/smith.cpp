//********************************************************************
// 
//
//
//
//N.Yu.Zolotykh 2000
//University of Nizhni Novgorod, Russia
//********************************************************************

/**
    \file
    Smith's normal diagonal form
 */


#include <time.h>
#include <string.h>
#include "arageli.h"
#include "matrices.h"
#include "gauss.h"
#include "bigarith.h"

typedef big_int T;
typedef matrix<T> MT;

void print_help()
{
  cout << "***           S M I T H            ***\n";
  cout << "***   Nikolai Yu. Zolotykh, 2000   ***\n";
  cout << "This is a part of Arageli " << Arageli_version << '\n';
  cout << "Smith's normal diagonal form\n";
  cout << "Usage:\n";
  cout << "  smith options <input >output\n";
  cout << "Options:\n";
  cout << " -a or -A:\t outputs A (input matrix)\n";
  cout << " -b or -B:\t outputs B = P A Q (Smith's matrix) (default)\n";
  cout << " -p or -P:\t outputs P (unimodular)\n";
  cout << " -q or -Q:\t outputs Q (unimodular)\n";
  cout << " -t or --time:\t outputs time\n";
  cout << " -r or --rank:\t outputs rank of A = rank of B\n";
  cout << " -d or --det:\t outputs determinant of basis minor of B\n";
  cout << " -l or --all:\t prints all above\n";
  cout << " -m or --movie:\t prints intermidiate tables and comments\n";
  cout << " -s:\t not suppresses special outputs\n";
  cout << " -v or --version:\t prints version\n";
  cout << " -? or -h or --help:\t prints this message\n";
  cout << "Examples:\n";
  cout << " smith --all --movie <a.in >a.out\n";
  cout << " smith <a.in >a.out\n";
}

void main(int argc, char *argv[])
{

  // default values:
  int output_a = 0;
  int output_b = 0;
  int output_p = 0;
  int output_q = 0;
  int output_r = 0;
  int output_d = 0;
  int output_time = 0;
  int not_suppress_special_output = 0;
  int movie = 0;

  // arguments parsing:
  for(int i = 1; i < argc; i++)
  {
    if(strcmp(argv[i], "-a") == 0 || strcmp(argv[i], "-A") == 0)
      output_a = 1;
    else if(strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "-B") == 0)
      output_b = 1;
    else if(strcmp(argv[i], "-p") == 0 || strcmp(argv[i], "-P") == 0)
      output_p = 1;
    else if(strcmp(argv[i], "-q") == 0 || strcmp(argv[i], "-Q") == 0)
      output_q = 1;
    else if(strcmp(argv[i], "-r") == 0 || strcmp(argv[i], "--rank") == 0)
      output_r = 1;
    else if(strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "--det") == 0)
      output_d = 1;
    else if(strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--time") == 0)
      output_time = 1;
    else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "-?") == 0
      || strcmp(argv[i], "--help") == 0)
    {
      print_help();
      return;
    }
    else if(strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--version") == 0)
    {
      cout << "Smith from Arageli " << Arageli_version << '\n';
      return;
    }
    else if(strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "--all") == 0)
    {
      output_a = 1;
      output_b = 1;
      output_p = 1;
      output_q = 1;
      output_r = 1;
      output_d = 1;
      output_time = 1;
    }
    else if(strcmp(argv[i], "-m") == 0 || strcmp(argv[i], "--movie") == 0)
      movie = 1;
    else if (strcmp(argv[i], "-s") == 0)
      not_suppress_special_output = 1;
    else
    {
      cout << "Unknown argument: " << argv[i] << '\n';
      cout << "For help type smith -h \n";
      return;
    }
  }

  if (!output_a && !output_b && !output_p && !output_q
    && !output_r && !output_d && !output_time)
    output_b = 1;	// default

  // input

  MT A;
  cin >> A;

  // call the main subroutine:

  MT B, P, Q;
  T det;
  index rank;

  time_t begin_time = time(NULL);
  smith(A, B, P, Q, rank, det, movie, cout);
  time_t end_time = time(NULL);

  // output:

  if(output_a + output_b + output_p + output_q + output_r + output_d
    + output_time == 1 && !not_suppress_special_output)
  {
    if (output_a) cout << A;
    if (output_b) cout << B;
    if (output_p) cout << P;
    if (output_q) cout << Q;
    if (output_r) cout << rank << '\n';
    if (output_d) cout << det << '\n';
    if (output_time) cout << end_time - begin_time << '\n';
  }
  else
  {
    if (output_a) cout << "!a:\n" << A;
    if (output_b) cout << "!b:\n" << B;
    if (output_p) cout << "!p:\n" << P;
    if (output_q) cout << "!q:\n" << Q;
    if (output_r) cout << "!rank =\n" << rank << '\n';
    if (output_d) cout << "!det =\n" << det << '\n';
    if (output_time) cout << "!Time (seconds) =\n" << end_time - begin_time
      << '\n';
  }

}


