//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia

#include "matrices.h"
#include "gcd.h"

#ifndef MOTZKIN_H_
#define MOTZKIN_H_

/**
    \file
    Motzkin-Burger algorithm for double-description of a polyhedal cone.
 */

/**
    \example skeleton.cpp
 */

/**
  \name Constants for selecting modifications of Motzkin algorithm
 */

//@{
const int mm_no_modification  = 0;  ///< Runs plain algorithm
const int mm_min_modification = 1;  ///< Selects minimum elements
const int mm_max_modification = 2;  ///< Selects maximum elements
const int mm_no_movie         = 0;  ///< Shows all operations
const int mm_movie            = 1;  ///< Does not show all operations
//@}

/**
  Finds extreme rays f and basis e of a cone ax >= 0
  returns also an incidence matrix q = f * transpose(a)
*/

#ifdef no_default_arguments
template <class int_item>
  void skeleton(matrix<int_item> & a, matrix<int_item> & f,
    matrix<int_item> & q, matrix<int_item> & e,
    int modification,
    int movie,
    ostr& movie_stream);
#else
template <class int_item>
  void skeleton(matrix<int_item> & a, matrix<int_item> & f,
    matrix<int_item> & q, matrix<int_item> & e,
    int modification = mm_no_modification,
    int movie = mm_no_movie,
    ostr& movie_stream = cout);
#endif

/*--------------------------------------------------------------------------
 I m p l e m e n t a t i o n
----------------------------------------------------------------------------*/

template <class int_item>
  class motzkin_burger_algorithm
{
public:
  motzkin_burger_algorithm(matrix<int_item>&a, matrix<int_item>&f,
    matrix<int_item>&q, matrix<int_item>&e,
    int modification, int movie, ostr& movie_stream)
    : a(a), f(f), q(q), e(e),
    modification(modification), movie(movie), movie_stream(movie_stream){};
  void run();

private:
  matrix<int_item> & a;
  matrix<int_item> & f;
  matrix<int_item> & q;
  matrix<int_item> & e;
  int modification;
  int movie;
  ostr & movie_stream;

  void gauss();

  int reroof(index row);
  int balance(index j_plus, index j_minus);
  index min_modification();
  index max_modification();
  index fun(index j);

  void movie_print3();

  vector<index>common_zero;
  index n, m, r, current_ost, current_column;
};

#ifdef no_default_arguments
template <class int_item>
  void skeleton(matrix<int_item> & a, matrix<int_item> & f,
    matrix<int_item> & q, matrix<int_item> & e,
    int modification,
    int movie,
    ostr& movie_stream)
#else
template <class int_item>
  void skeleton(matrix<int_item> & a, matrix<int_item> & f,
    matrix<int_item> & q, matrix<int_item> & e,
    int modification,
    int movie,
    ostr& movie_stream)
#endif
{
  motzkin_burger_algorithm<int_item>
    alg(a, f, q, e, modification, movie, movie_stream);
  alg.run();
}

/***************************/
/*                         */
/*          gauss          */
/*                         */
/***************************/

/*��������묨 �८�ࠧ�����ﬨ ��� ��ப��� ������ a
  � ����⠭����� �� �⮫�殢 �ਢ���� �� � ��������쭮�� ���� q:
    f * transpose(a) = q.*/

template <class int_item>
  void motzkin_burger_algorithm<int_item>::gauss()
{
  index i, j;
  index m = a.get_m();
  index n = a.get_n();

  f.resize(n, n);
  e.resize(0, n);
  // error handling?

  /* f = identity */
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      f(i, j) = 0;
  for (i = 0; i < n; i++)
    f(i, i) = 1;

  q = transpose(a);

  if (movie)
  {
    movie_stream << "1. Gaussian algorithm\n"
                 << "   ******************\n";
    movie_print3();
  }

  /* main loop */
  i = 0;
  while (i < q.get_m())
  {
    /* find non-zero entry in the i-th row beginning from i-th entry */
    if (movie)
    {
      movie_stream << "Current row: " << i << endl
        << "Find non-zero entry in the " << i
        << "-th row beginning from " << i << "-th entry\n";
    }
    j = i;
    while (j < m)
    {
      if (q(i, j) != 0) break;
      j++;
    }
    if (j >= m)
    {
      /* it's a zero row */
      q.del_row(i);
      e.ins_row(e.get_m(), f.take_row(i));
      if (movie)
      {
        movie_stream << "Zero row \n"
          << "Matrix is not of full rank \n";
        movie_print3();
      }
      continue; // main loop
    }

    if (i != j)
    {
      q.swap_cols(i, j);
      a.swap_rows(i, j);

      if (movie)
      {
        movie_stream << "Swap " << i << "-th and " << j << "-th columns:\n";
        movie_print3();
      }
    }

    if (q(i, i) < 0)
    {
      q.mult_row(i, -1);
      f.mult_row(i, -1);
    }

    /* � i-�� �⮫�� ��ࠧ㥬 �� �㫨 */
    int_item b = q(i, i);
    index ii;
    for (ii = 0; ii < q.get_m(); ii++)
      if (ii != i)
      {
	int_item b_ii = q(ii, i);
  int_item alpha = gcd(b, b_ii);
	int_item b_i = b / alpha;
	b_ii = -b_ii / alpha;
	q.mult_row(ii, b_i);
	q.add_row(ii, i, b_ii);
	f.mult_row(ii, b_i);
	f.add_row(ii, i, b_ii);

  alpha = gcd(gcd(q.row(ii)), gcd(f.row(ii)));
	q.div_row(ii, alpha);
	f.div_row(ii, alpha);
      }
    if (movie)
    {
      movie_stream << "Gaussian elimination in the " << i << "-th column: \n";
      movie_print3();
    }
    i++; //next row
  }
}


/***************************/
/*                         */
/*           fun           */
/*                         */
/***************************/

template <class int_item>
  index motzkin_burger_algorithm<int_item>::fun(index j)
{
  //must be indexindex ! !!!!!
  index plus = 0;
  index minus = 0;
  //the number of positive and negative entries in the j - th column

    for(index i = 0; i<current_ost; i++)
  {
    if(q(i, j)>0)
      plus++;
    if(q(i, j)<0)
      minus++;
  }
  return plus * minus;
}

/***************************/
/*                         */
/*    min_modification     */
/*                         */
/***************************/

template <class int_item>
  index motzkin_burger_algorithm<int_item>::min_modification()
{
  index min_column, jj, min_fun, cur_fun;

  /* the column with minimal product of the number of positive
     and the number of negative entries */

  min_column = current_column;
  min_fun = fun(min_column);
  for(jj = current_column + 1; jj < m; jj++)
  {
    cur_fun = fun(jj);
    if(cur_fun < min_fun)
    {
      min_column = jj;
      min_fun = cur_fun;
    }
  }
  return min_column;
}

/***************************/
/*                         */
/*    max_modification     */
/*                         */
/***************************/

template <class int_item>
  index motzkin_burger_algorithm<int_item>::max_modification()
{
  index max_column, jj, max_fun, cur_fun;

  /* the column with maximal product of the number of positive
     and the number of negative entries */

  max_column = current_column;
  max_fun = fun(max_column);
  for(jj = current_column + 1; jj < m; jj++)
  {
    cur_fun = fun(jj);
    if(cur_fun > max_fun)
    {
      max_column = jj;
      max_fun = cur_fun;
    }
  }
  return max_column;
}


/***************************/
/*                         */
/*         reroof          */
/*                         */
/***************************/

template <class int_item>
  int motzkin_burger_algorithm<int_item>::reroof(index row)
{
  for(index i = 0; i < common_zero.get_n(); i++)
  {
    index j = common_zero[i];
    if(q(row, j) != 0)
      return 0;
  }
  return 1;
}

/***************************/
/*                         */
/*         balance         */
/*                         */
/***************************/

template <class int_item>
  int motzkin_burger_algorithm<int_item>::balance(index j_plus, index j_minus)
{
  //fist we construct the set CommonZero
  for(index j = 0; j < current_column; j++)
    if(q(j_plus, j) == 0 && q(j_minus, j) == 0)
      common_zero.join(j);

  if(common_zero.get_n()< r - 2)
    //��������㫥�
      return 0;

  // ��४�뢠� � �﫨�㫨
  for(index row = 0; row < current_ost; row++)
    if((row != j_plus) &&(row != j_minus))
      if(reroof(row))
	return 0;

  return 1;
}

/***************************/
/*                         */
/*       movie_print3      */
/*                         */
/***************************/

template <class int_item>
  inline void motzkin_burger_algorithm<int_item>::movie_print3()
{
  print3(movie_stream, transpose(a), f, q);
  movie_stream << endl;
}

/***************************/
/*                         */
/*           run           */
/*                         */
/***************************/

template <class int_item>
  void motzkin_burger_algorithm<int_item>::run()
     /*
       find extreme rays f and basis e of a cone ax>= 0
       returns also an incidence matrix q = f * transpose(a)
     */

{
  gauss();

  if (movie)
  {
    movie_stream << "2. Motzkin algorithm\n"
                 << "   *****************\n";
    movie_print3();
  }

  n = a.get_n();
  m = a.get_m();
  r = n - e.get_m();
  current_column = r;
  while(current_column < a.get_m())
  {
    vector<index> j_minus, j_plus;

    //for each inequality from a, beginning from(r + 1) th
      /* show_algorithm_state("current_column = ", current_column); */
    current_ost = q.get_m();
    //taking a new inequality depends upon modification
    index new_column;
    switch(modification)
    {
      case mm_no_modification:
        new_column = current_column;
        break;
      case mm_min_modification:
        new_column = min_modification();
        break;
      case mm_max_modification:
        new_column = max_modification();
        break;
    }

    if (movie)
    {
      movie_stream << "Current column: " << current_column << endl;
      movie_stream << "New column: " << new_column << endl;
    }

    if(current_column != new_column)
    {
      q.swap_cols(current_column, new_column);
      a.swap_rows(current_column, new_column);

      if (movie)
      {
        movie_stream << "We swap columns: \n";
        movie_print3();
      }
    }

    //now we are constructing the sets j_plus, j_minus
    for(index ii = 0; ii < current_ost; ii++)
    {
      if(q(ii, current_column) < 0)
	j_minus.join(ii);
      else if(q(ii, current_column) > 0)
	j_plus.join(ii);
    }
    if(j_minus.get_n() == current_ost)
    {
      //there is no solution except 0
      if (movie)
        movie_stream << "No solution exept zero\n";
      f.resize(0, n);
      e.resize(0, n);
      q.resize(0, m);
      return;
    }
    if(j_minus.get_n() == 0)
    {
      //this is a � �ࠢ���⢮-᫥��⢨�
      if (movie)
        movie_stream << "This inequality is a corollary\n";
      a.del_row(current_column);
      q.del_col(current_column);
      m--;
      continue;
      //new inequality
    }

    if (movie)
      movie_stream << "Balanced rows: ";

    index jj_m;
    for(jj_m = 0; jj_m < j_minus.get_n(); jj_m++)
    {
      index j_m = j_minus[jj_m];
      for(index jj_p = 0; jj_p < j_plus.get_n(); jj_p++)
      {
	index j_p = j_plus[jj_p];
	common_zero.resize(0);
	if(balance(j_p, j_m))
	{
          if (movie)
            movie_stream << "(" << j_p << ", " << j_m << ") ";
	  int_item b_minus = q(j_m, current_column);
	  int_item b_plus = q(j_p, current_column);
    int_item delta = gcd(b_minus, b_plus);
	  int_item alpha_plus = -b_minus / delta;
	  int_item alpha_minus = b_plus / delta;
	  f.add_rows(j_p, alpha_plus, j_m, alpha_minus);
	  q.add_rows(j_p, alpha_plus, j_m, alpha_minus);
    delta = gcd(gcd(f.row(f.get_m() - 1)), gcd(q.row(q.get_m() - 1)));
	  f.div_row(f.get_m()-1, delta);
	  q.div_row(q.get_m()-1, delta);
	}
      } //Iterate J_plus
    } //Iterate J_minus

    if (movie)
    {
      movie_stream << endl;
      movie_print3();
      movie_stream << "Delete negative rows:\n";
    }

    f.del_rows(j_minus);
    q.del_rows(j_minus);

    if (movie) movie_print3();

    current_column++;
  }
}

#endif
