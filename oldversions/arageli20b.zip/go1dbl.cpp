//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia
#include<iostream.h>
#include"bigarith.h"
#include"rational.h"
#include"smplxtbl.h"
#include"matrices.h"

#if defined(__BORLANDC__) && !defined(__WIN32__)
#  include <alloc.h>
#endif

int main()
{
#if defined(__BORLANDC__) && !defined(__WIN32__)
  long memavail = coreleft();
#endif
{
  simplex_table<double> a;

  if (a.is_primal_feasible())
    a.primal_simplex_col();
  else if (a.is_dual_feasible())
    a.dual_simplex_col();
  else
  {
    cout << "table is not dual or primal feasible";
    return 1;
  }

  a.gomory1();

  //cout << a;

}
#if defined(__BORLANDC__) && !defined(__WIN32__)
memavail = coreleft() - memavail;
cout << " mem = " << memavail << "must be 0";
#endif

return 0;
}
