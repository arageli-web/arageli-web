//N.Yu.Zolotykh 1999, 2000
//University of Nizhni Novgorod, Russia

#include"matrices.h"
#include"gcd.h"
#include"powerest.h"

#ifndef GAUSS_H_
#define GAUSS_H_

/**
    \file
    Some algorithms of linear algebra.
    Bellow field_item is the type implementing an item of any field,
    int_item is the type implementing an integer number.
 */

/**
     Produces the reduced row echelon form B of a matrix A.
     Returns B, Q, basis, det:
     - Q is such that B = Q * A;
     - r = basis.get_n() is the rank of A;
     - B.sumbatrix(mesh_grid(1,r), basis) is the r-by-r identity matrix;
     - det is the value of the max size left upper corner minor of A.
     If movie = 1 all intermidiate tables and comments
     are printed into movie_stream
 */

#ifdef no_default_arguments
template <class field_item>
  void rref(const matrix<field_item>& A,
    matrix<field_item>& B, matrix<field_item>& Q,
    vector<index>& basis, field_item& det,
    int movie, ostr& movie_stream);
#else
template <class field_item>
  void rref(const matrix<field_item>& A,
    matrix<field_item>& B, matrix<field_item>& Q,
    vector<index>& basis, field_item& det,
    int movie = 0, ostr& movie_stream = cout);
#endif

/**
     Returns inversion of matrix A
     Precondition: A must be square
 */

template <class field_item>
  matrix<field_item> inv(const matrix<field_item>& A);

/**
     Returns determinant of A.
     Precondition: A must be square
 */

template <class field_item>
  field_item det(const matrix<field_item>& A);


/**
     Produces the reduced row echelon form B of an integer matrix A.
     Returns B, Q, basis, det:
     - Q is such that B = Q * A;
     - r = basis.get_n() is the rank of A;
     - B.sumbatrix(mesh_grid(1,r), basis) is the r-by-r non-singular
       diagonal matrix;
     - det is the value of the max size left upper corner minor of A.
 */

#ifdef no_default_arguments
template <class int_item>
  void rref_int(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& Q,
    vector<index>& basis, int_item& det,
    int movie, ostr& movie_stream);
#else
template <class int_item>
  void rref_int(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& Q,
    vector<index>& basis, int_item& det,
    int movie = 0, ostr& movie_stream = cout);
#endif



/**
     Returns determinant of A
 */

template <class int_item>
  int_item det_int(const matrix<int_item>& A);



/**
     Produces normal diagonal form B of integer matrix A.
     Returns B, P, Q, rank, det:
     - P, Q are unimodular such that B = P * A * Q;
     - rank is a rank of A;
     - det is the basis minor of A
     If movie = 1 all intermidiate tables and comments
     are printed into movie_stream
 */

#ifdef no_default_arguments
template <class int_item>
  void smith(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& P,
    matrix<int_item>& Q, index& rank, int_item& det,
    int movie, ostr& movie_stream);
#else
template <class int_item>
  void smith(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& P,
    matrix<int_item>& Q, index& rank, int_item& det,
    int movie = 0, ostr& movie_stream = cout);
#endif

// I M P L E M E N T A T I O N


#ifdef no_default_arguments
template <class field_item>
  void rref(const matrix<field_item>& A,
    matrix<field_item>& B, matrix<field_item>& Q,
    vector<index>& basis, field_item& det,
    int movie, ostr& movie_stream)
#else
template <class field_item>
  void rref(const matrix<field_item>& A,
    matrix<field_item>& B, matrix<field_item>& Q,
    vector<index>& basis, field_item& det,
    int movie, ostr& movie_stream)
#endif


{
  det = 1;
  index m = A.get_m();
  index n = A.get_n();
  Q = eye(field_item(1), m);
  B = A;
  basis.resize(0);

  if (movie)
  {
    movie_stream << "Reduced row echelon form\n";
    print2(movie_stream, B, Q);
  }

  for (index i = 0, j = 0; i < m && j < n; j++)
  {
    // main loop:
    // for any cols j of B
    field_item max = 0;
    index i_max = i;

    // find the biggest (in absolute value) entry in the column j
    if (movie)
      movie_stream
        << "Find the biggest (in absolute value) entry in the column "
        << j << endl;
    for (index ii = i; ii < m; ii++)
    {
      if (absolute_value(B(ii, j)) > max)
      {
	    max = absolute_value(B(ii, j));
	    i_max = ii;
      }
    }
    if (max == field_item(0))
    {
      // of main loop: column j is negligible
      if (movie)
        movie_stream << "Column " << j << " is negligible\n";
      det = 0;
      continue;
    }

    if (movie)
      movie_stream << "Pivot item: (" << i_max << ", " << j << ")\n";

    if (i != i_max)
    {
      B.swap_rows(i, i_max);
      Q.swap_rows(i, i_max);
      det = -det;
      if (movie)
      {
        movie_stream << "Swap rows: " << i << ", " << i_max << endl;
        print2(movie_stream, B, Q);
      }
    }

    field_item pivot = B(i, j);
    B.div_row(i, pivot);
    Q.div_row(i, pivot);
    det = det * pivot;

    for (index ii = 0; ii < m; ii++)  // eliminate in column j
      if (ii != i)
      {
	field_item alpha = B(ii, j);
	B.add_row(ii, i, -alpha);
	Q.add_row(ii, i, -alpha);
      }
    if (movie)
    {
      movie_stream << "Elimination in column " << j << endl;
      print2(movie_stream, B, Q);
    }

    basis.join(j);
    i++;
  } // end of main loop
}

template <class field_item>
  field_item det(const matrix<field_item>& A)
{
  // precondition: A must be square
  if (A.get_m() != A.get_n())
  {
    matrix_error (st_matrix_must_be_square, "matrix must be square");
    return 0;
  }

  matrix<field_item> B;
  matrix<field_item> Q;
  vector<index> basis;

  field_item det;

  rref(A, B, Q, basis, det, 0, cout);

  return det;
}




template <class field_item>
  matrix<field_item> inv(const matrix<field_item>& A)
{
  // precondition: A must be square
  if (A.get_m() != A.get_n())
  {
    matrix_error (st_matrix_must_be_square, "matrix must be square");
    return 0;
  }

  matrix<field_item> B;
  matrix<field_item> Q;
  vector<index> basis;

  field_item det;

  rref(A, B, Q, basis, det, 0, cout);

  if (det == 0)
    matrix_error (st_matrix_is_singular, "matrix is singular");

  return Q;
}


#ifdef no_default_arguments
template <class int_item>
  void rref_int(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& Q,
    vector<index>& basis, int_item& det,
    int movie, ostr& movie_stream)
#else
template <class int_item>
  void rref_int(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& Q,
    vector<index>& basis, int_item& det,
    int movie, ostr& movie_stream)
#endif
{
  det = 1;
  int_item det_denom = 1; // differs from field version
  index m = A.get_m();
  index n = A.get_n();
  Q = eye(int_item(1), m);
  B = A;
  basis.resize(0);

  if (movie)
  {
    movie_stream << "Reduced row echelon form for integral matrix\n";
    print2(movie_stream, B, Q);
  }

  for (index i = 0, j = 0; i < m && j < n; j++)
  {
    // main loop:
    // for any cols j of B
    int_item max = 0;
    index i_max = i;

    // find non-zero entry in the column j
    if (movie)
      movie_stream
        << "Find non-zero entry in the column "
        << j << endl;
    for (index ii = i; ii < m; ii++)
    {
      if (absolute_value(B(ii, j)) > max)
      {
	max = absolute_value(B(ii, j));
	i_max = ii;
      }
    }
    if (max == 0)
    {
      // of main loop: column j is negligible
      if (movie)
        movie_stream << "Column " << j << " is negligible\n";
      continue;
    }

    if (movie)
      movie_stream << "Pivot item: (" << i_max << ", " << j << ")\n";

    if (i != i_max)
    {
      B.swap_rows(i, i_max);
      Q.swap_rows(i, i_max);
      det = -det;
      if (movie)
      {
        movie_stream << "Swap rows: " << i << ", " << i_max << endl;
        print2(movie_stream, B, Q);
      }
    }

    int_item pivot = B(i, j);

    if (pivot < 0)	// differs from field version
    {			// differs from field version
      B.mult_row(i, -1);// differs from field version
      Q.mult_row(i, -1);// differs from field version
      pivot = -pivot;   // differs from field version
      det = -det;	// differs from field version
    }                   // differs from field version

    for (index ii = 0; ii < m; ii++)	// eliminate in column j
      if (ii != i)
      {
        int_item alpha = B(ii, j);
        int_item delta = gcd(pivot, alpha);// differs from field version
        int_item b_ii = -alpha / delta;  // differs from field version
        int_item b_i = pivot / delta;  // differs from field version
        B.mult_row(ii, b_i);  // differs from field version
        B.add_row(ii, i, b_ii); // differs from field version
        Q.mult_row(ii, b_i);  // differs from field version
        Q.add_row(ii, i, b_ii); // differs from field version
        det_denom = det_denom * b_i;  // differs from field version
        alpha = gcd(gcd(B.row(ii)), gcd(Q.row(ii)));  // differs from field version
        B.div_row(ii, alpha);   // differs from field version
        Q.div_row(ii, alpha); // differs from field version
        det = det * alpha;  // differs from field version
      }
    if (movie)
    {
      movie_stream << "Elimination in column " << j << endl;
      print2(movie_stream, B, Q);
    }


    basis.join(j);
    i++;
  } // end of main loop

  for (index i = 0; i < basis.get_n(); i++) // differs from field version
    det = det * B(i, basis[i]);	// differs from field version
  det = det/det_denom;	// differs from field version
}


template <class int_item>
  int_item det_int(const matrix<int_item>& A)
{
  // precondition: A must be square
  if (A.get_m() != A.get_n())
  {
    matrix_error (st_matrix_must_be_square,
      "matrix must be square");
    return 0;
  }

  matrix<int_item> B;
  matrix<int_item> Q;
  vector<index> basis;
  int_item d;

  rref_int(A, B, Q, basis, d, 0, cout);

  return d;
}

#ifdef no_default_arguments
template <class int_item>
  void smith(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& P,
    matrix<int_item>& Q, index& rank, int_item& det,
    int movie, ostr& movie_stream)
#else
template <class int_item>
  void smith(const matrix<int_item>& A,
    matrix<int_item>& B, matrix<int_item>& P,
    matrix<int_item>& Q, index& rank, int_item& det,
    int movie, ostr& movie_stream)
#endif
{
  det = 1;
  index m = A.get_m();
  index n = A.get_n();
  Q = eye(int_item(1), n);
  P = eye(int_item(1), m);
  B = A;

  if (movie)
  {
    movie_stream << "Smith's normal diagonal form\n";
    print3(movie_stream, Q, P, B);
  }

  for (index corner = 0; corner < m && corner < n; corner++)
  {
    index new_i, new_j, i, j;
    int_item pivot_item;

    if (!find_pivot_item(B, corner, new_i, new_j))
      // the smallest (in absolute value) non-zero entry in the matrix
      break; // all others entries are 0

    if (movie)
      movie_stream << "The smallest (in absolute value) non-zero entry: ("
        << new_i << ", " << new_j << ")\n";

    while(1)
    {
      do{
	i = new_i;
	j = new_j;
	pivot_item = B(i, j);

        if (movie)
          movie_stream << "Pivoting item: (" << i << ", " << j << ")\n";

	for (index jj = 0; jj < n; jj++)
	  if (jj != j)
	  {
            int_item p = quotient(B(i, jj), pivot_item);
	    B.add_col(jj, j, -p);
	    Q.add_col(jj, j, -p);
	  }
	for (index ii = 0; ii < m; ii++)
	  if (ii != i)
	  {
	    int_item p = quotient(B(ii, j), pivot_item);
	    B.add_row(ii, i, -p);
	    P.add_row(ii, i, -p);
	  }

        if (movie)
        {
          movie_stream << "After pivoting step:\n";
          print3(movie_stream, Q, P, B);
        }

	new_j = find_pivot_item_in_row(B, corner, i);
	if(new_j == j)
	  new_i = find_pivot_item_in_col(B, corner, j);
	else
	  new_i = i;
      }while (i != new_i || j != new_j);
	// while pivot entry is changing,
	// i.e. until others entries in row i and column j are 0

      index k, l;
      if (!find_non_divisor_of_item(B, corner, pivot_item, k, l))
	break;

      B.add_row(i, k, 1);
      P.add_row(i, k, 1);

      if (movie)
      {
        movie_stream << "Non-divisor entry: (" << k << ", " << l << ")\n";
        movie_stream << "Add the " << k << "-th row to the " << i
          << "-th row\n";
        print3(movie_stream, Q, P, B);
      }

    }

    if (i != corner)
    {
      B.swap_rows(i, corner);
      P.swap_rows(i, corner);
      det = -det;
    }
    if (j != corner)
    {
      B.swap_cols(j, corner);
      Q.swap_cols(j, corner);
      det = -det;
    }
    if (B(corner, corner) < 0)
    {
      B.mult_row(corner, -1);
      P.mult_row(corner, -1);
      det = -det;
    }
    if (movie)
      print3(movie_stream, Q, P, B);

  }

  rank = 0;

  for (index i = 0; i < m && i < n; i++)
    if(B(i, i) != 0)
    {
      det = det * B(i, i);
      rank++;
    }
    else
      break;
}

template <class int_item>
  int find_pivot_item(matrix<int_item>& B, index corner,
    index& min_i, index& min_j)
{
  int_item min = 0;
  for (index i = corner; i < B.get_m(); i++)
    for (index j = corner; j < B.get_n(); j++)
      if (B(i, j) != 0 && (min == 0 || absolute_value(B(i, j)) < min))
      {
	min = absolute_value (B(i, j));
	min_i = i;
	min_j = j;
      }
  if (min == 0)
    return 0;
  return 1;
}


template <class int_item>
  index find_pivot_item_in_row(matrix<int_item>& B, index corner,
    index i)
{
  int_item min = 0;
  index min_j = 0;

  for (index j = corner; j < B.get_n(); j++)
    if (B(i, j) != 0 && (min == 0 || absolute_value(B(i, j)) < min))
    {
      min = absolute_value (B(i, j));
      min_j = j;
    }

  return min_j;
}

template <class int_item>
  index find_pivot_item_in_col(matrix<int_item>& B, index corner,
    index j)
{
  int_item min = 0;
  index min_i = 0;

  for (index i = corner; i < B.get_m(); i++)
    if (B(i, j) != 0 && (min == 0 || absolute_value(B(i, j)) < min))
    {
      min = absolute_value (B(i, j));
      min_i = i;
    }

  return min_i;
}

template <class int_item>
  int find_non_divisor_of_item(matrix<int_item>& B, index corner,
    int_item item, index& k, index& l)
{
  for (index i = corner; i < B.get_m(); i++)
    for (index j = corner; j < B.get_n(); j++)
      if (B(i, j) % item != 0)
      {
	k = i;
	l = j;
	return 1;
      }
  return 0;
}



#endif GAUSS_H_
