/********************************************************************



 N.Yu.Zolotykh 2000
 University of Nizhni Novgorod, Russia
********************************************************************/

/**
    \file
    All extreme rays and basis of a cone
 */


#include <time.h>
#include <string.h>
#include "arageli.h"
#include "motzkin.h"
#include "matrices.h"
#include "bigarith.h"

void print_help()
{
  cout<<"***        S K E L E T O N         ***\n";
  cout<<"***   Nikolai Yu. Zolotykh, 2000   ***\n";
  cout<<"This is a part of Arageli "<<Arageli_version<<'\n';
  cout<<"All extreme rays and basis of a cone defined by a system Ax >= 0\n";
  cout<<"Usage:\n";
  cout<<"  skeleton options <input >output\n";
  cout<<"Options:\n";
  cout<<" -a or -A:\t outputs the input matrix\n";
  cout<<" -f or -F:\t outputs the extreme rays (default)\n";
  cout<<" -q or -Q:\t outputs f * transpose(a)\n";
  cout<<" -e or -E:\t outputs basis\n";
  cout<<" -t or --time:\t outputs time\n";
  cout<<" -l or --all:\t prints all above\n";
  cout<<" -m or --movie:\t prints all intermidiate tables\n";
  cout<<" -mxxx or --modxxx:\t modification, xxx is one of the following:\n";
  cout<<"   min:\t \n";
  cout<<"   max:\t \n";
  cout<<"   no:\t (default) \n";
  cout<<" -s:\t not suppresses special output\n";
  cout<<" -v or --version:\t prints version\n";
  cout<<" -? or -h or --help:\t prints this message\n";
  cout<<"Examples: \n";
  cout<<" skeleton --all --movie --modmin <cube3.ext >cube3.out\n";
  cout<<" skeleton <faces.dat >vertices.dat \n";
}

void main(int argc, char *argv[])
{

  // default values:
  int output_ine = 0;
  int output_ext = 0;
  int output_inc = 0;
  int output_bas = 0;
  int output_time = 0;
  int not_suppress_special_output = 0;
  int movie = mm_no_movie;
  int modification = mm_no_modification;

  // arguments parsing:
  for(int i = 1; i < argc; i++)
  {
    if(strcmp(argv[i], "-a") == 0 || strcmp(argv[i], "-A") == 0)
      output_ine = 1;
    else if(strcmp(argv[i], "-f") == 0 || strcmp(argv[i], "-F") == 0)
      output_ext = 1;
    else if(strcmp(argv[i], "-q") == 0 || strcmp(argv[i], "-Q") == 0)
      output_inc = 1;
    else if(strcmp(argv[i], "-e") == 0 || strcmp(argv[i], "-E") == 0)
      output_bas = 1;
    else if(strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--time") == 0)
      output_time = 1;
    else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "-?") == 0
       || strcmp(argv[i], "--help") == 0)
    {
      print_help();
      return;
    }
    else if(strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--version") == 0)
    {
      cout << "Skeleton from Arageli " << Arageli_version << '\n';
      return;
    }
    else if(strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "--all") == 0)
    {
      output_ine = 1;
      output_ext = 1;
      output_inc = 1;
      output_bas = 1;
      output_time = 1;
    }
    else if (strcmp(argv[i], "-s") == 0)
      not_suppress_special_output = 1;
    else if(strcmp(argv[i], "-m") == 0 || strcmp(argv[i], "--movie") == 0)
      movie = mm_movie;
    else if(strcmp(argv[i], "-mmin") == 0
      || strcmp(argv[i], "--modmin") == 0)
      modification = mm_min_modification;
    else if(strcmp(argv[i], "-mmax") == 0
      || strcmp(argv[i], "--modmax") == 0)
      modification = mm_max_modification;
    else if(strcmp(argv[i], "-mno") == 0
      || strcmp(argv[i], "--modno") == 0)
      modification = mm_no_modification;
    else
    {
      cout << "Unknown argument: " << argv[i] << '\n';
      cout << "For help type skeleton -h \n";
      return;
    }
  }

  if (!output_ine && !output_ext && !output_inc && !output_bas && !output_time)
    output_ext = 1;

  // call the main subroutine:

  matrix<big_int> ine, ext, inc, bas;
  cin >> ine;

  time_t begin_time = time(NULL);
  ////////////////////////////////////////////////////////////////////////////
  skeleton(ine, ext, inc, bas, modification, movie, cout);
  ////////////////////////////////////////////////////////////////////////////
  time_t end_time = time(NULL);

  // output:

  if(output_ine + output_ext + output_inc + output_bas + output_time == 1
    && !not_suppress_special_output)
  {
    if (output_ine) cout << ine;
    if (output_ext) cout << ext;
    if (output_inc) cout << inc;
    if (output_bas) cout << bas;
    if (output_time) cout << end_time - begin_time;
  }
  else
  {
    if (output_ine) cout << "!a:\n" << ine;
    if (output_ext) cout << "!f:\n" << ext;
    if (output_inc) cout << "!q:\n" << inc;
    if (output_bas) cout << "!e:\n" << bas;
    if (output_time) cout << "!Time (seconds) =\n" << end_time - begin_time
      << '\n';
  }
}

