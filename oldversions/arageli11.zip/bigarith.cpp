//  N.Yu.Zolotykh 1999, 2000
//  University of Nizhni Novgorod, Russia

/*!
    \file
    Implementation of bigarith module.
*/

#include"bigarith.h"

void big_arith_warning(const char *s)
{
  cerr << "Big arith warning: " << s << "\n";
}

void big_arith_error(const char *s)
{
  cerr << "Big arith error: " << s << "\n";
}

void big_arith_fatal_error(const char *s)
{
  cerr << "Big arith fatal error: \n " << s << "\n";
  exit(1);
}

/***************************/
/*                         */
/*    low level memory     */
/*   managment routines    */
/*                         */
/***************************/

static inline digit* get_mem_for_data(size_t nitems)
{
  digit* p = (digit *) malloc(nitems * sizeof(digit));
  if (!p)
    big_arith_fatal_error("the heap overflow");
  return p;
}

static inline void free_data(digit *p)
{
  if (p)
    free(p);
}

static inline digit* realloc_data(digit *p, size_t newnitems)
{
  if (newnitems)
  {
    p = (digit*) realloc(p, newnitems * sizeof(digit));
    if (!p)
      big_arith_fatal_error("the heap overflow");
  }
  else
  {
    free_data(p);
    p = NULL;
  }
  return p;
}

static inline void
  copy_data(digit *dest, const digit *source, size_t newnitems)
{
  memmove(dest, source, newnitems * sizeof(digit));
}

/***************************/
/*                         */
/*    number allocation    */
/*         routines        */
/*                         */
/***************************/

void big_int::
  alloc_number(int new_sign, digit * new_data, size_t new_len)
{
  number = new big_struct;
  if (!number)
    big_arith_fatal_error("the heap overflow");

  number->sign = new_sign;
  number->data = new_data;
  number->len = new_len;
  number->refs = 1;
}

void big_int::free_number()
{
  if (number == NULL)
    return;
  number->refs--;
  if (number->refs != 0)
    return;
  free_data(number->data);
  delete [] number;
  number = NULL;
}

inline void big_int::
  free_mem_and_alloc_number(int new_sign, digit * new_data, size_t new_len)
{
  free_number();
  alloc_number(new_sign, new_data, new_len);
}

inline void big_int::alloc_zero()
{
  alloc_number(0, NULL, 0);
}

inline void big_int::free_mem_and_alloc_zero()
{
  free_number();
  alloc_zero();
}

/***************************/
/*                         */
/*      calc_bdn_radix     */
/*                         */
/***************************/

static void calc_bdn_radix(digit radix, digit & bdn_radix, size_t & chars_per_digit)
//bdn_radix = maximal power of radix fit in digit;
{
  bdn_radix = 1;
  chars_per_digit = 0;
  //digit max_digit = -1;
  digit t = max_digit/radix;
  while (t)
  {
    t /= radix;
    bdn_radix *= radix;
    chars_per_digit++;
  }
}

/***************************/
/*                         */
/*         optimize        */
/*                         */
/***************************/

inline static digit * optimize(size_t & new_len, digit * p, size_t len)
// deleting leading zeros
{
  new_len = do_optimize(p, len);
  if (new_len != len)
    if (new_len)
    {
      digit* new_p = get_mem_for_data(new_len);
      copy_data(new_p, p, new_len);
      free_data(p);
      p = new_p;
    }
    else
    {
      free_data(p);
      p = NULL;
    }
  return p;
}

/***************************/
/*                         */
/*      constructors       */
/*    and destructors      */
/*                         */
/***************************/

big_int::big_int()
{
  alloc_zero();
}

big_int::big_int(const big_int & b)
{
  b.number->refs++;
  number = b.number;
}

big_int::big_int(char *str)
{
  alloc_zero();
  istrstream s(str);
  big_int b;
  s >> b;
  *this = b;
}

big_int::big_int(int b)
{
  alloc_zero();
  if (b)
  {
    digit *p = get_mem_for_data(1);

    if (b > 0)
    {
      p[0] = b;
      free_mem_and_alloc_number(1, p, 1);
    }
    else
    {
      p[0] = -b;
      free_mem_and_alloc_number(-1, p, 1);
    }
  }
}

big_int::~big_int()
{
  free_number();
}

/***************************/
/*                         */
/*        operator =       */
/*                         */
/***************************/

big_int & big_int::operator = (const big_int & b)
{
  // make a copy of a number, just increments the reference count}
  if (number == b.number)
    return *this;
  free_number();
  b.number->refs++;
  number = b.number;
  return *this;
}

/***************************/
/*                         */
/*      Unary operators    */
/*                         */
/***************************/

big_int operator + (const big_int & a)  // unary plus
{
  return a;
}

big_int operator - (const big_int & b)  // unary minus
{
  big_int a;
  digit *result;
  size_t blen;

  blen = b.number->len;
  if (b.number->sign == 0)
    a.free_mem_and_alloc_zero();
  else if ((a.number == b.number) && (a.number->refs == 1))
    a.number->sign = -b.number->sign;
  else
  {
    result = get_mem_for_data(blen);
    copy_data(result, b.number->data, blen);      // copy data
    a.free_mem_and_alloc_number(-b.number->sign, result, blen);
  }
  return a;
}

/***************************/
/*                         */
/*        operator +       */
/*                         */
/***************************/

big_int operator + (const big_int & b, const big_int & c)
// Thanks to Max Alekseyev for a lot of suggestions
{
  digit *sum,
   *newsum;
  size_t sumlen;
  big_int a;
  int bsign = b.number->sign;
  int csign = c.number->sign;
  int sumsign;
  size_t blen = b.number->len;
  size_t clen = c.number->len;
  digit *bdata = b.number->data;
  digit *cdata = c.number->data;
  big_int::big_struct *u, *v;

  if (bsign == 0)
    a = c;
  else if (csign == 0)
    a = b;
  else
  {
    if (bsign == csign)
    {
      sumsign = bsign;
      if (blen >= clen)
      {
	u = b.number;
	v = c.number;
      }
      else
      {
	u = c.number;
	v = b.number;
      }
      sum = get_mem_for_data(u->len + 1);
      copy_data(sum, u->data, u->len);
      sumlen = do_add(sum, v->data, u->len, v->len);
    }
    else // bsign != csign
    {
      if (blen >=clen)
      {
	sum = get_mem_for_data(blen);
	sumsign = bsign;
	copy_data(sum, bdata, blen);
	if (do_sub(sum, cdata, blen, clen))     // �� ����
	  goto c_ge_b;				// yes, it is
	sum = optimize(sumlen, sum, blen);
      }
      else
      {
	sum = get_mem_for_data(clen);
c_ge_b:
	sumsign = csign;
	copy_data(sum, cdata, clen);
	do_sub(sum, bdata, clen, blen);
	sum = optimize(sumlen, sum, clen);
      }
    }
    if (sumlen)
      a.free_mem_and_alloc_number(sumsign, sum, sumlen);
    else
      a.free_mem_and_alloc_zero();
  }
  return a;
}

/***************************/
/*                         */
/*        operator -       */
/*                         */
/***************************/

big_int operator - (const big_int & b, const big_int & c)
{
   return b+(-c);
}

/***************************/
/*                         */
/*        operator *       */
/*                         */
/***************************/

big_int operator *(const big_int & b, const big_int & c)
{

  digit *result;
  size_t blen,
    clen,
    resultlen;
  int bsign,
    csign;
  big_int a;

  blen = b.number->len;
  clen = c.number->len;
  bsign = b.number->sign;
  csign = c.number->sign;

  if ((bsign == 0) || (csign == 0))
    a.free_mem_and_alloc_zero();
  else
  {
    resultlen = blen + clen;
    result = get_mem_for_data(resultlen);
    if (do_mult(b.number->data, c.number->data, result, blen, clen) == 0)
      resultlen--;
    a.free_mem_and_alloc_number(bsign * csign, result, resultlen);
  }
  return a;
}

/***************************/
/*                         */
/*         divide          */
/*                         */
/***************************/

void divide(big_int & a, const big_int & b, const big_int & c, big_int & res)
 // a = b / c; res = b % c
{
  digit *u,
   *v,
   *q,
   *r;
  size_t alen,
    blen,
    clen,
    rlen;
  digit runint;
  int bsign,
    csign;

  blen = b.number->len;
  clen = c.number->len;
  bsign = b.number->sign;
  csign = c.number->sign;

  if (!csign)
    big_arith_error("divide by zero");
  else if (!bsign)
  {
    a.free_mem_and_alloc_zero();
    res.free_mem_and_alloc_zero();
  }
  else if (blen < clen)
  {
    a.free_mem_and_alloc_zero();
    res = b;
  }
  else if (clen == 1)
  {
    q = get_mem_for_data(blen);
    runint =
      do_divide_by_digit(b.number->data, q, blen, c.number->data[0]);
    if (q[blen - 1])
      alen = blen;
    else
      alen = blen - 1;
    if (alen)
      a.free_mem_and_alloc_number(bsign * csign, q, alen);
    else
    {
      a.free_mem_and_alloc_zero();
      free_data(q);
    }
    if (runint == 0)
      res.free_mem_and_alloc_zero();
    else
    {
      u = get_mem_for_data(1);
      u[0] = runint;
      res.free_mem_and_alloc_number(bsign, u, 1);
    }
  }
  else
  {
    u = get_mem_for_data(blen + 1);
    v = get_mem_for_data(clen);
    q = get_mem_for_data(blen - clen + 1);
    copy_data(u, b.number->data, blen);
    copy_data(v, c.number->data, clen);

    rlen = do_divide(u, v, q, blen, clen);
    if (q[blen - clen])
      alen = blen - clen + 1;
    else
      alen = blen - clen;

    free_data(v);
    if (rlen == 0)
      res.free_mem_and_alloc_zero();
    else
    {
      r = get_mem_for_data(rlen);
      copy_data(r, u, rlen);
      res.free_mem_and_alloc_number(bsign, r, rlen);
    }
    free_data(u);
    if (alen != 0)
      a.free_mem_and_alloc_number(bsign * csign, q, alen);
    else
    {
      a.free_mem_and_alloc_zero();
      free_data(q);
    }
  }
}

big_int operator % (const big_int & b, const big_int & c)
{
  big_int a,
    r;
  divide(a, b, c, r);
  return r;
}

big_int operator / (const big_int & b, const big_int & c)
{
  big_int a,
    r;
  divide(a, b, c, r);
  return a;
}

/***************************/
/*                         */
/*   Combined operators    */
/*                         */
/***************************/

// combined assignment-addition operator
inline big_int & operator += (big_int & b, const big_int & c)
{
  return b = b + c;
};

// combined assignment-subtraction operator
inline big_int & operator -= (big_int & b, const big_int & c)
{
  return b = b - c;
};

// combined assignment-multiplication operator
inline big_int & operator *= (big_int & b, const big_int & c)
{
  return b = b * c;
};

// combined assignment-division operator
inline big_int & operator /= (big_int & b, const big_int & c)
{
  return b = b / c;
};

// combined assignment-remainder operator
inline big_int & operator %= (big_int & b, const big_int & c)
{
  return b = b % c;
};

/***************************/
/*                         */
/*    Compare functions    */
/*                         */
/***************************/

int cmp(const big_int & a, const big_int & b)
//sign(a-b)
{
  int result;

  int asign,
    bsign;
  size_t alen,
    blen;
  big_int c;

  asign = a.number->sign;
  bsign = b.number->sign;
  alen = a.number->len;
  blen = b.number->len;

  if (asign < bsign)
    result = -1;
  else if (asign > bsign)
    result = 1;
  else if (asign == 0)
    result = 0;                 // asign == bsign == 0
  else if (alen < blen)
    result = -asign;            // asign == bsign != 0
  else if (alen > blen)
    result = asign;
  else
  {                             // asign == bsign != 0, alen == blen
    c = a - b;
    result = c.number->sign;
  }
  return result;
}

int operator < (const big_int & a, const big_int & b)
{
  return cmp(a, b) == -1;
}

int operator == (const big_int & a, const big_int & b)
{
  return cmp(a, b) == 0;
}

int operator != (const big_int & a, const big_int & b)
{
  return cmp(a, b) != 0;
}

int operator > (const big_int & a, const big_int & b)
{
  return cmp(a, b) == 1;
}

int operator >= (const big_int & a, const big_int & b)
{
  return cmp(a, b) != -1;
}

int operator <= (const big_int & a, const big_int & b)
{
  return cmp(a, b) != 1;
}

/***************************/
/*                         */
/*      Random numbers     */
/*                         */
/***************************/

big_int random_number(int length)
{
  big_int a;
  digit *p = get_mem_for_data(length);
  for (int i = 0; i < length; i++)
    p[i] = rand();
  size_t new_len;
  p = optimize(new_len, p, length);
  if (new_len)
    a.free_mem_and_alloc_number(1, p, new_len);
  return a;
}

/***************************/
/*                         */
/*     Stream operators    */
/*                         */
/***************************/

static digit stream_radix(ios & s)
{
  if (s.flags() & ios::dec)
    return 10;
  if (s.flags() & ios::hex)
    return 16;
  if (s.flags() & ios::oct)
    return 8;
  return 10; // it is very strange
}

ostream & operator << (ostream & s, const big_int & x)
{
  if (!x.number->sign)
    return s << "0";

  digit bdn_radix;
  size_t chars_per_block;
  calc_bdn_radix(stream_radix(s), bdn_radix, chars_per_block);

  size_t bdnlen = x.number->len;
  digit *bdn = get_mem_for_data(2 * bdnlen); //bdnlen + bdnlen/chars_per_block
  digit *numberdata = get_mem_for_data(x.number->len);
  copy_data(numberdata, x.number->data, x.number->len);
  bdnlen = do_big_int_to_bdn(numberdata, bdn, x.number->len, bdn_radix);
  free_data(numberdata);

  if (x.number->sign == -1)
    s << '-';
  s << bdn[bdnlen - 1];
  for (size_t i = bdnlen - 1; i > 0; i--)
  {
    s.width(chars_per_block);
    s.fill('0');
    s << bdn[i - 1];
  }
  free_data(bdn);
  return s;
}

static void set_stream_radix(ios & s, digit radix)
{
  if (radix == 10)
    s.setf(ios::dec, ios::basefield);
  else if (radix == 16)
    s.setf(ios::hex, ios::basefield);
  else if (radix == 8)
    s.setf(ios::oct, ios::basefield);
  else // error
    s.setf(ios::dec, ios::basefield);
}

istream & operator >> (istream & s, big_int & x)
{
  char ch;
  int sign = 1;
  digit radix = 10;


  do
    s.get(ch);
  while (isspace(ch));

  if (ch == '-')
    sign = -1;
  else if (ch != '+')
    s.putback(ch);

  s.get(ch);

  int zero = 0;
  if (ch == '0')
  {
    zero = 1;
    s.get(ch);
    switch (ch)
    {
      case 'o': radix = 8; break;
      case 'x': radix = 16; break;
      default: s.putback(ch);
    }
  }
  else
    s.putback(ch);

  do
    s.get(ch);
  while (ch == '0');
  s.putback(ch);

  ostrstream buffer;



  while(s.get(ch))
  {
    if ( radix == 10 && isdigit(ch)
      || radix == 16 && isxdigit(ch)
      || radix == 8  && isdigit(ch) && ch < '8')
      buffer << ch;
    else
    {
      s.putback(ch);
      break;
    }
  }



  if (!buffer.tellp())
  {
    x = 0;
    if (!zero)
      big_arith_warning("empty string; treating as zero.");
    return s;
  }

  buffer << ends;



  char * buffer_str = buffer.str();

  digit bdn_radix;
  size_t chars_per_block;
  calc_bdn_radix(radix, bdn_radix, chars_per_block);

  size_t length_of_str = strlen(buffer_str);
  size_t number_of_blocks = (length_of_str - 1)/chars_per_block + 1;
  digit* bdn = get_mem_for_data(number_of_blocks);
  size_t length_of_block = length_of_str % chars_per_block;
                                       // for the first block
  if (!length_of_block) length_of_block = chars_per_block;

  char * buffer_str_cur = buffer_str;
  for (size_t j = number_of_blocks; j > 0; j--)
  {
    istrstream stream_block(buffer_str_cur, length_of_block);
    set_stream_radix(stream_block, radix);
    stream_block >> bdn[j-1];
    buffer_str_cur += length_of_block;
    length_of_block = chars_per_block;  // for the last blocks
  }


  digit* data = get_mem_for_data(number_of_blocks);
  size_t len = do_bdn_to_big_int(bdn, data, number_of_blocks, bdn_radix);
  free_data(bdn);
  data = realloc_data(data, len);
  if (data)
    x.free_mem_and_alloc_number(sign, data, len);
  else
    x.free_mem_and_alloc_zero();

  delete[] buffer_str;

  return s;
}

/*
int log2(const big_int & a)
{
  if (!a.number->len)
    return -1;
  int l = (a.number->len - 1) * BITS_PER_WORD;
  digit f = a.number->data[a.number->len - 1];
  while(f >>= 1) l++;
  return l;
}

big_int operator << (const big_int & a, unsigned int n)
{
  unsigned int alen = a.number->len;
  if(!n || !alen) return a;
  unsigned int s=(log2(a)+n)/BITS_PER_WORD+1, m=n/BITS_PER_WORD, t=0;
  n %= BITS_PER_WORD;
  unsigned int k=BITS_PER_WORD-n;
  digit * p = alloc_data(s);
  for(int i=0; i<alen; i++) 
  { 
    p[m+i] = (a.number->data[i] << n) | t; 
    t = a.number->data[i] >> k;
  }
  if(t) p[m+alen]=t;
  big_int r;
  r.alloc_number(a.number->sign, p, s);
  return r;
}

big_int operator >> (const big_int & a, unsigned int n)
{
  unsigned int alen=a.number->len;
  if(!n||!alen) return a;
  unsigned int l=log2(a); if(l<n) return a.zero;
  unsigned int s=(l-n)/BITS_PER_WORD+1, m=n/BITS_PER_WORD;
  n %= BITS_PER_WORD;
  unsigned int k=BITS_PER_WORD-n, t=0;
  digit * p = alloc_data(s);
  if(alen>s+m) t = a.number->data[alen-1] << k;
  for(int i=s-1; i>=0; i--) 
  { 
    p[i] = (a.number->data[i+m] >> n) | t; 
    t = a.number->data[i+m] << k;
  }
  big_int r;
  r.alloc_number(a.number->sign, p, s);
  return r;
}
*/