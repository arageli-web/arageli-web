//N.Yu.Zolotykh 2000
//University of Nizhni Novgorod, Russia

#include "arageli.h"

#ifndef POWEREST_H_
#define POWEREST_H_

/** \file
    Useful mathematical routines.
    This module includes functions of integer power calculations,
    square rooting, factorial computations and others.
 */


#if !defined(__BORLANDC__)
// �᫨ ���� �।��騩 !define, � ��稭����� �஡����!?

///  Integer power a^n
template <class monoid, class integer>
  monoid power(monoid a, integer n);

///  Integer squre root of x
template <class integer_class>
  integer_class sqrt(const integer_class& x);

/// Returns a!
template <class integer_class>
  integer_class factorial(const integer_class& a);

/// Returns absolute value
template <class number_class>
  number_class absolute_value(const number_class& b);

/// Returns quotient and remainder of a/b
/**
Returns  <i> true </i> :)
quotient p and remainder r of a/b such that

- a = p*b + r
- 0 <= r < |b|
*/
template <class euclid_ring_item>
  void quotient_remainder(euclid_ring_item a, euclid_ring_item b,
  euclid_ring_item& p, euclid_ring_item& r);

/// Returns quotient of a/b
template <class euclid_ring_item>
  euclid_ring_item quotient(euclid_ring_item a, euclid_ring_item b);

/// Returns remainder of a/b
template <class euclid_ring_item>
  euclid_ring_item remainder(euclid_ring_item a, euclid_ring_item b);

#endif // !defined(__BORLANDC__)

// Implementation:

template <class monoid, class integer>
  monoid power(monoid a, integer n)
{
  int neg = n < 0;
  if (neg)
    n = -n;
  monoid res = 1;
  while (n != 0)
  {
    if (n % 2 != 0) res = res * a;
    a = a * a;
    n = n / 2;
  }
  //return neg ? 1.0/res : res;
  return res;
}

template <class integer_class>
  integer_class sqrt(const integer_class& x)
{
  if (x <= 0)
    return 0;                   // no error handler, so ...
  else if (x == 1)
    return 1;
  else
  {
    integer_class r = x / 2;
    integer_class q;
    while(1)
    {
      q = x / r;
      if (q >= r)
        return r;
      else
        r = (r + q) / 2;
    }
  }
}

template <class integer_class>
  integer_class factorial(const integer_class& a)
{
  integer_class p = 1;
  for (integer_class i = 1; i <= a; i = i + 1)
    p = p * i;
  return p;
}

template <class number_class>
  number_class absolute_value(const number_class& b)
{
  if (b < number_class(0))
    return -b;
  else
    return b;
}

template <class euclid_ring_item>
  void quotient_remainder(euclid_ring_item a, euclid_ring_item b,
    euclid_ring_item& p, euclid_ring_item& r)
{
  r = a%b;
  p = a/b;

  if (a < 0 && r != 0)
  {
    if (b > 0)
      p = p - 1;
    else
      p = p + 1;
    r = absolute_value(b) + r;
  }
}

template <class euclid_ring_item>
  euclid_ring_item quotient(euclid_ring_item a, euclid_ring_item b)
{
  euclid_ring_item p;
  euclid_ring_item r;

  quotient_remainder(a, b, p, r);

  return p;
}

template <class euclid_ring_item>
  euclid_ring_item remainder(euclid_ring_item a, euclid_ring_item b)
{
  euclid_ring_item p;
  euclid_ring_item r;

  quotient_remainder(a, b, p, r);

  return r;
}

#endif //POWEREST_H_
