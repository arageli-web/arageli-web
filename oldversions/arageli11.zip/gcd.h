//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia
#include <stdlib.h>
#include "powerest.h"

#ifndef GCD_H_
#define GCD_H_

/**
    \file
   Euclidian algorithm.
   This module consists of function which implements Euclidian algorithm
   for greatest common divisor producing.
*/


/**
   Euclidian algorithm produces
   the greatest common divisor of two integer u and v
 */

template <class item_class>
  item_class gcd(const item_class & a, const item_class & b)
{
  item_class r;
  item_class u = absolute_value(a);
  item_class v = absolute_value(b);
  while (v != 0)
  {
    r = u % v;
    u = v;
    v = r;
  }
  return u;
}


#endif
