//  N.Yu.Zolotykh 1999, 2000
//  University of Nizhni Novgorod, Russia
//  Arageli 1.02


/**
    \file
    Big Integer Numbers implementation.

    This module implements a class big_int for representing
    Big Integer Numbers, i.e. `arbitrary precision' integers.

    You can use assembler code written for some critical parts of the module.
    For this you should define macros USE_ASM.
*/

#include<iostream.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<strstream.h>
#include "arageli.h"

#ifndef __cplusplus
#  error Must use C++ for the type big_int.
#endif

#ifndef BIGARITH_H_
#define BIGARITH_H_

#ifdef USE_ASM
#  if defined(__WIN32__) || defined (__WATCOMC__)
     typedef unsigned int digit; // 4 bytes
     const digit max_digit = 0xFFFFFFFF;
#    include"bigar32.h"
#  else
     typedef unsigned int digit;
     const digit max_digit = 0xFFFF;
#    include"bigarbc.h"
#  endif
#else
     typedef unsigned int digit;
     const digit max_digit = 0xFFFF;
#    include"bigar.h"
#endif


/** Implementation of a Big Integer Number.
    An instance of the data type big_int is
    an integer number of arbitrary length. */

class big_int
{

  /** \example testbg.cpp
      A demo program for bigarith module. */
  /** \example testbig.cpp
      A test program for bigarith module. */
  /** \example testbio.cpp
      A test program for input-output routines of bigarith module. */

 public:

  big_int();                    ///< Constructor
  big_int(char *str);           ///< Converts str to a big_int
  big_int(const big_int & b);   ///< Constructor: makes a copy of a number
  big_int(int b);               ///< Constructor: converts b to a big number
  ~big_int();                   ///< Destructor

  big_int & operator = (const big_int & b);     ///< Assignment

  /// Converts a string to a big_int
  // friend void string_to_num(char *s, big_int & b);
  // ���� �� ���� ����� ��� �㭪��,
  // � ���-����� � powerest ᮧ���� 蠡��� b=s

  /// Converts a big_int to a string
  // void to_string(char *string, size_t size, digit radix = 10) const;
  /// Reads a number
  friend ostream & operator << (ostream & s, const big_int & x);
  /// Writes a number
  friend istream & operator >> (istream & s, big_int & x);

  /// Compares two big integers
  /**
     Returns
      -  0  if a = b,
      -  -1 if a < b,
      -  1  if a > b
   */
  friend int cmp(const big_int & a, const big_int & b);

  /// Test for equality
  friend int operator == (const big_int & a, const big_int & b);

  /// Test for inequality
  friend int operator != (const big_int & a, const big_int & b);

  /// Test for greater
  friend int operator > (const big_int & a, const big_int & b);

  /// Test for greater than or equal to
  friend int operator >= (const big_int & a, const big_int & b);

  /// Test for less
  friend int operator < (const big_int & a, const big_int & b);

  /// Test for less than or equal to
  friend int operator <= (const big_int & a, const big_int & b);

  friend big_int operator + (const big_int & a);       ///< Unary plus
  friend big_int operator - (const big_int & a);       ///< Unary minus

  /// Binary plus
  friend big_int operator + (const big_int & b, const big_int & c);
  /// Binary minus
  friend big_int operator - (const big_int & b, const big_int & c);
  /// Multiplication
  friend big_int operator *(const big_int & b, const big_int & c);
  /// Divizion
  friend big_int operator / (const big_int & b, const big_int & c);
  /// Remainder
  friend big_int operator % (const big_int & b, const big_int & c);
  /// Combined assignment-addition operator
  friend big_int & operator += (big_int & b, const big_int & c);
  /// Combined assignment-subtraction operator
  friend big_int & operator -= (big_int & b, const big_int & c);
  /// Combined assignment-multiplication operator
  friend big_int & operator *= (big_int & b, const big_int & c);
  /// Combined assignment-division operator
  friend big_int & operator /= (big_int & b, const big_int & c);
  /// Combined assignment-remainder operator
  friend big_int & operator %= (big_int & b, const big_int & c);

  /// Division b by c
  /** Returns a quotient a = b / c; and remainder r = b % c */
  friend void divide(big_int & a, const big_int & b, const big_int & c,
      big_int & res);

  /// Returns psudo-random number with length `digits'
  friend big_int random_number(int length);


 private:

  // the following type is used inside the big_arith unit and implements
  // the storage for a Big Integer Number

  struct big_struct
  {
    int sign;                   // the sign: 0, 1 or -1
    digit *data;                // the storage for digits
    size_t len;                 // the number of digits
    int refs;                   // the number of points to this number
  } *number;

  // number allocation routines
  void alloc_number(int new_sign, digit * new_mem, size_t new_len);
  void free_number();
  void free_mem_and_alloc_number(int new_sign, digit * new_data, size_t new_len);
  void alloc_zero();
  void free_mem_and_alloc_zero();

};
#endif BIGARITH_H_
