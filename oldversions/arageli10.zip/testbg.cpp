//********************************************************************
// testbg.cpp           Big arithmetics test
//
//N.Yu.Zolotykh 1999, 2000
//University of Nizhni Novgorod, Russia
//********************************************************************

/**
   \file
   Big arithmetics test
 */

#include<iostream.h>
#include <ctype.h>
#include "bigarith.h"
#include "powerest.h"

#if defined(__BORLANDC__) && !defined(__WIN32__)
#  include <alloc.h>
#endif


void test(big_int a, big_int b, int echo = 1)
{
  if (echo)
  {
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
  }

  if (a <= 10000)
    if (echo) cout << a << "! = " << factorial(a) << endl;
  if (b <= 10000)
    if (echo) cout << b << "! = " << factorial(b) << endl;

  big_int sum = a + b;
  big_int sub = a - b;
  big_int mul = a * b;
  big_int quo = a / b;
  big_int rem = a % b;
  big_int sqr = sqrt(a);

  if (echo) cout
    << "a+b     = " << sum << endl
    << "a-b     = " << sub << endl
    << "a*b     = " << mul << endl
    << "a/b     = " << quo << endl
    << "a%b     = " << rem << endl
    << "sqrt(a) = " << sqr << endl;

  int error_count = 0;
  if (sum - b != a)
  {
    error_count++;
    cout << "error in addition \n";
  }
  if (sub + b != a)
  {
    error_count++;
    cout << "error in subtraction \n";
  }
  if (absolute_value(rem) > absolute_value(b) || a != b * quo + rem)
  {
    error_count++;
    cout << "error in division \n";
  }
  if (sqr * sqr > a || (sqr + 1) * (sqr + 1) <= a)
  {
    error_count++;
    cout << "error in rooting \n";
  }
  if (!error_count) cout << "ok\n";

}


void main()
{

#if defined(__BORLANDC__) && !defined(__WIN32__)
long memavail = coreleft();
#endif

{
  
  big_int a, b;

  cout << "Big arithmetics test\n"
    << "First of all, tree special examples:\n";

  cout << "1-st" << endl;
  a = "100000000000000000000";
  b = "10000000000";
  test(a,b);

  cout << "2-nd" << endl;
  a = "88324001366761939746549495863516861064950065520957783943261528711385488254530054111685430381492095963568016051560655393689567458933694253847947832283140028875267539270369949504419892202312645384588102776710665820872314333788431511433864242605473215830341951617902145503437983966122064932382766743322898389102160022195175260593675382";
  b = "36894823947562488362989727081483887800365382823662491";
  test(a,b,0);

  cout << "3-rd" << endl;
  a = "5333245856853565415055585011049022425580427473278165038478223503030859107340270041475114438225715463301864901187605682558229291473418475637016158619625254838034794153099448795995916199228619670416233191463383053963384329482622136176256765643570288127756605225377217068936747872993388901044275204880340763055855393748002806711757961433758136310906685845030008416";
  b = "492795842627912932954814370012435141701919872711274673189442383997743460695103452642552188307998619408058929346014856379838443669625449085032539";
  test(a,b,0);

  cout << "Now enter any numbers. For exit enter 0 0 \n";
  while (1)
  {
    cout << "a..";
    cin >> a;
    cout << "b..";
    cin >> b;

    if (a == 0 && b == 0) break;

    test(a, b);
  }

}

#if defined(__BORLANDC__) && !defined(__WIN32__)
memavail = coreleft() - memavail;
cout << " mem = " << memavail << " must be zero" << endl ;
#endif

}
