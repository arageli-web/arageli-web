//********************************************************************
// testbio.cpp     Big Arith input-output routines test
//
//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia
//********************************************************************


#include <iostream.h>
#if defined(__BORLANDC__) && !defined(__WIN32__)
#  include <alloc.h>
#endif
#include <ctype.h>
#include "bigarith.h"

int main()
{
#if defined(__BORLANDC__) && !defined(__WIN32__)
long memavail = coreleft();
#endif

{

cout << "Input-output BigArith test\n"  
  << "Enter any big_int number \n"      
  << "For exit enter 0 \n"; 

while (1)
{
  big_int a;
  cin >> a;
  cout << a <<"\n";
  if (a == 0) break;
}


}
#if defined(__BORLANDC__) && !defined(__WIN32__)
memavail = coreleft() - memavail;
cout << " mem = " << memavail << endl;
#endif

return 0;
}
