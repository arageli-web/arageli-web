//N.Yu.Zolotykh 1999
//32-bit modification (c) 2000 by Max A. Alekseyev
//University of Nizhni Novgorod, Russia

#include "arageli.h"

#ifndef BIGAR32_H_
#define BIGAR32_H_

extern "C" {
digit cdecl do_big_int_to_bdn(digit *, digit *, size_t, digit);
digit cdecl do_bdn_to_big_int(digit *, digit *, size_t, digit);
digit cdecl do_add(digit *, digit *, size_t, size_t);
digit cdecl do_sub(digit *, digit *,  size_t, size_t);
digit cdecl do_optimize(digit *, size_t);
digit cdecl do_mult(digit *, digit *, digit *, size_t, size_t);
digit cdecl do_mult_by_digit(digit *, digit *, size_t, digit);
unsigned int cdecl do_divide_by_digit(digit *, digit *, size_t, size_t);
size_t cdecl do_divide(digit *, digit *, digit *,  size_t, digit);
}

#endif

