//  N.Yu.Zolotykh 1999, 2000
//  University of Nizhni Novgorod, Russia

/*! \file Low-level bigarith routines for Borland C++ for DOS */

#include"bigarith.h"
#include"bigarbc.h"

#if defined(__BORLANDC__)
#pragma option -w-rvl
#endif

#if !defined(__HUGE__) && !defined(__LARGE__)
#  error Huge or Large memory model must be used
#endif

size_t do_big_int_to_bdn(digit * a, digit * b, size_t n, digit bdn_radix)
{

size_t two_n_minus_two;

asm{
        xor ax, ax
        cmp n, ax
        je on_return

        push ds

        lds si, a
        les di, b

        mov bx, n
        dec bx
        shl bx, 1
        mov two_n_minus_two, bx
	xor cx, cx          //count digits in the result
     }

 next_digit:

asm     xor dx, dx

 div_loop:

asm {
        mov ax, ds:[si+bx]
        div bdn_radix
        mov ds:[si+bx], ax
        sub bx, 2
        jnc  div_loop

        inc cx              //count digits in the result
        mov es:[di], dx     //residue: the new digit in the result
        inc di
        inc di
        mov bx, two_n_minus_two
        xor ax, ax
        cmp ds:[si+bx], ax
        jne  next_digit

        sub bx, 2

        mov two_n_minus_two, bx
        jnc  next_digit

        mov ax, cx           //return the number of digits in the result

        pop ds
     }

on_return:
}

size_t do_bdn_to_big_int(digit * a, digit * b, size_t n, digit bdn_radix)
{
digit m, carry;

asm {
        push ds

        lds si, a            //first, optimize

        std

        mov bx, n
	mov cx, bx           //count of digits n
        dec bx
        shl bx, 1            //2*n-2
        mov ax, ds
        mov es, ax
	mov di, si
        add di, bx
        xor ax, ax
        repe scasw           //find non-zero
        mov m, ax            //m==0
	je end              //if non found  return: all digits are zeros
	inc cx               //the number of non-zero digits
        inc di
        inc di

        mov si, di
        les di, b

        mov ax, ds:[si]
        mov es:[di], ax
        dec si
        dec si
        mov m, 1
        dec cx
	jcxz end
     }

 loop:

asm {
        push cx
        mov cx, m
        xor bx, bx
        mov carry, bx
     }

 mul_loop:

asm {
        mov ax, es:[di+bx]
        mul bdn_radix
        add ax, carry
        adc dx, 0
	mov carry, dx
        mov es:[di+bx], ax
        inc bx
        inc bx
        loop  mul_loop

        cmp carry, 0
        je  h1
        mov ax, carry
        mov es:[di+bx], ax
        inc bx
        inc bx
    }

 h1:

asm {
        shr bx, 1
        mov cx, bx
	dec cx
        mov bx, 2
        mov ax, ds:[si]
        add es:[di], ax
        jcxz  label_1

        mov ax, 0                      //invalid: xor ax, ax
     }

 add_loop:

asm {
        adc es:[di+bx], ax
        inc bx
        inc bx
        loop  add_loop
    }

label_1:

asm {
        jnc  h2
        mov ax, 1
        mov es:[di+bx], ax
        inc bx
        inc bx
    }

 h2:

asm {
        shr bx, 1
        mov m, bx

        dec si
        dec si

        pop cx

        loop  loop
    }

end:

asm {   mov ax, m
        pop ds
    }
}


size_t do_add(digit * p1, digit * p2, size_t m, size_t n)
{
  asm{
	  push dS
	  mov cx, n
	  mov dx, m
	  sub dx, cx

          lds SI, p1
          les dI, p2

          xor Bx, bx              // bx = 0}

          clc                     // clear 䫠� ��७��}
  }

  loop1:
  asm     {
          mov ax, es:[di+bx]
	  adc [si+bx], ax
          inc bx                  // invalid: add bx, 2}
          inc bx
          loop loop1

          mov cx, dx              // cx = m-n}
          jcxz lastfig            //if m==n  done

          mov dx, 0               //invalid: xor dx, dx
          }

  loop2:
  asm     {
          adc [si+bx], dx
          inc bx
          inc bx
          loop loop2
          }
  lastfig:
  asm     {
          jae end
          mov dx, 1
          mov [si+bx], dx
          inc bx
          inc bx
          }
  end:
  asm     {
          shr bx, 1
          mov ax, bx              // ax = bx = bx/2 the number of "figures"
          pop ds
          }
}

int do_sub(digit * p1, digit * p2, size_t m, size_t n)
{
asm {
	push ds
	mov cx, n
        mov dx, m
        sub dx, cx

        lds si, p1
        les di, p2

        xor bx, bx              // bx = 0

        clc                     // clear cf
        }
loop1:
asm {   mov ax, es:[di+bx]
        sbb [si+bx], ax
        inc bx                  // invalid: add bx, 2
	inc bx
        loop loop1

        mov cx, dx              // cx = m-n
        mov ax, 0               // invalid: xor dx, dx
        jcxz lastfig           // if m==n  done
    }
loop2:
asm {
        sbb [si+bx], ax
        inc bx
        inc bx
        loop loop2
    }
lastfig:
asm {
        jae end                // if �� �뫮 �����  return ax == 0
        mov ax, 1               // else return 1
    }
end:
asm {
	pop ds
    }
}

size_t do_optimize(digit * a, size_t n)
{
asm {
        push ds
        std
        lds si, a
        mov bx, n
        mov cx, bx
        dec bx
        shl bx, 1
        mov ax, ds
        mov es, ax
        mov di, si
	add di, bx
        xor ax, ax
        repe scasw      // find non-zero}
        je end         // if non found  return}
        mov ax, cx
        inc ax
}
end:
asm {
	pop ds
    }
}

size_t do_mult(digit *u, digit *v, digit *w, size_t m, size_t n)
{
  size_t vj;
asm  {
        push ds

        cld             //forward scanning
        les di, w
        mov cx, m
        xor ax, ax
        rep stosw

        shl m, 1        //m = 2 * m
        shl n, 1        //n = 2 * n

        les di, w
        lds si, u

        xor bx, bx      //bx==j = 0
     }

loopj:
asm  {
        push si         //save ds:si -> u
        push ds
        lds si, v

        mov ax, [si+bx] //save vj
        mov vj, ax

        pop ds          //retake ds:si -> u
        pop si
        push bx         //save j
        xor cx, cx      //p==cx = 0 ��७��
        mov bx, cx      //i==bx = 0
      }

loopi:

asm   {
        mov ax, ds:[si+bx]      //ax = u_i
        mul vj                  //x:y == dx:ax = u_i * v_j

        add es:[di+bx], cx      //w_i+j = w_i+j + p
        adc dx, 0               //+ ��७��

        add es:[di+bx], ax      //w_i+j = w_i+j + y
        adc dx, 0               //+ ��७��

        mov cx, dx              //��७��

        inc bx
        inc bx

        cmp bx, m

        jb loopi                //if i < m  loop

        mov es:[di+bx], cx      //w_m+j = p

        inc di                  //es:di -> w_j+0
        inc di
        pop bx                  //j
        inc bx
        inc bx

        cmp bx, n

        jb loopj                //if j < 2n  loop

	mov ax, cx              //return major digit

        pop ds
    }
}

size_t do_mult_by_digit(digit * a, digit * p, size_t n, size_t d)
{
asm  {
        push ds
        lds si, a
        les di, p

        shl n, 1

        xor cx, cx
        mov bx, cx
     }

loop:

asm  {
        mov ax, ds:[si+bx]
        mul d
	add ax, cx
        adc dx, 0
        mov cx, dx
        mov es:[di+bx], ax

        inc bx
        inc bx

        cmp bx, n

        jb loop

        mov es:[di+bx], cx
        mov ax, cx

        pop ds
     }
}


size_t do_divide_by_digit(digit * a, digit * p, size_t n, digit d)
{
asm {
        push ds
        lds si, a
        les di, p
        mov cx, d
        mov bx, n
        dec bx
        shl bx, 1

        xor dx, dx
    }
loop:

asm {
        mov ax, ds:[si+bx]
	div cx                  //ax = dx:ax div cx; dx = dx:ax mod cx
        mov es:[di+bx], ax

        sub bx, 2

        jnc loop
     }

label_1:

asm  {
	mov ax, dx              //return residue
	pop ds
     }
}

size_t do_divide(digit * u, digit * v, digit * q, size_t m, size_t n)
{

size_t two_n, two_m, v_n_minus_one, v_n_minus_two, d, q_hat, r_hat;

asm {
      push ds

      les di, u
      lds si, v

      mov ax, n
      shl ax, 1
      mov two_n, ax
      mov ax, m
      shl ax, 1
      mov two_m, ax

      mov bx, n
      dec bx
      shl bx, 1
      mov ax, ds:[si+bx]
      mov v_n_minus_one, ax
    }

/**********************************************************************/

     //d1: find d && normilize

asm {
       mov dx, 1
       xor ax, ax                 //b
       mov cx, v_n_minus_one
       add cx, 1
       jc j1
       div cx
       mov d, ax
       jmp j2
     }

j1:

asm    mov d, dx

j2:

     //multiply v by d

asm {
       xor cx, cx                  //carry
       mov bx, cx                  //count
    }

loop_d1_1:

asm {
       mov ax, ds:[si+bx]
       mul d
       add ax, cx
       adc dx, 0
       mov cx, dx
       mov ds:[si+bx], ax
       inc bx
       inc bx
       cmp bx, two_n
       jb loop_d1_1
     }


     //multiply u by d

asm {
       xor cx, cx                      //carry
       mov bx, cx                      //count
    }

loop_d1_2:

asm {
       mov ax, es:[di+bx]
       mul d
       add ax, cx
       adc dx, 0
       mov cx, dx
       mov es:[di+bx], ax
       inc bx
       inc bx
       cmp bx, two_m
       jb loop_d1_2
       mov es:[di+bx], cx
    }

//**********************************************************************

     //d2: loop on j==bx

                        //initialize v_n_minus_one, v_n_minus_two
asm {
       mov bx, n
       dec bx
       shl bx, 1
       mov ax, ds:[si+bx]
       mov v_n_minus_one, ax
       mov ax, ds:[si+bx-2]
       mov v_n_minus_two, ax

       mov bx, m
       sub bx, n
       shl bx, 1                  //bx == 2*(m-n)
       add di, two_m
    }

//**********************************************************************

     //d3: calculate q_hat

d3:

asm {

       mov dx, es:[di]           //u[j+n]
       mov ax, es:[di-2]         //u[j+n-1]
       cmp dx, v_n_minus_one
       jae label_1               //u[j+n] >= v[n-1]
       div v_n_minus_one
       mov r_hat, dx
       mov q_hat, ax
       jmp label_2
    }
label_1:

asm {
       mov ax, -1            	// q_hat = ffff
       mov dx, es:[di-2]        // u[j+n-1]
       jmp label_4
    }

label_3:
asm {
       mov ax, q_hat
       dec ax
       mov dx, r_hat
    }
label_4:
asm {
       mov q_hat, ax
       add dx, v_n_minus_one    // r_hat = u[j+n-1] + v[n-1]
       jc d4
       mov r_hat, dx
    }
label_2:
asm {
       mov ax, q_hat
       mul v_n_minus_two
       cmp dx, r_hat
       jb d4                           // <
       ja label_3                      // >
       cmp ax, es:[di-4]
       ja label_3                      // >
    }

//************************************************************************

     //d4: multiply && subtract

d4:

asm {
       push bx
       sub di, two_n               //u[m]

       xor cx, cx                  //carry
       mov bx, cx                  //count
    }

loop_d4:

asm {
       mov ax, ds:[si+bx]          //v[bx]
       mul q_hat
       add ax, cx
       adc dx, 0
       sub es:[di+bx], ax          //u[bx]
       adc dx, 0
       mov cx, dx                  //new carry
       inc bx
       inc bx
       cmp bx, two_n
       jb loop_d4
       sub es:[di+bx], cx
    }

//*************************************************************************

d5:

asm   jnc d7

//*************************************************************************

d6: //q_hat correction

asm {                              // very rare event
       dec q_hat
       mov cx, n                   //count
       xor bx, bx
       clc                         //carry
     }

loop_d6:

asm {
       mov ax, ds:[si+bx]          //v[bx]
       adc es:[di+bx], ax          //u[bx]
       inc bx
       inc bx
       loop  loop_d6
       xor ax, ax
       adc es:[di+bx], ax
    }

//*************************************************************************

    //d7: end loop on bx

d7:

asm {
       add di, two_n
       pop bx

      //record q[j]

       push es
       push di
       les di, q
       mov ax, q_hat
       mov es:[di+bx], ax
       pop di
       pop es

      //end loop on bx

       dec di
       dec di
       sub bx, 2
       jnc jmpd3
       jmp d8
     }

jmpd3:

asm    jmp d3

//*********************************************************************

d8:  //denormalize

asm {
       les di, u
       mov bx, n
       dec bx
       shl bx, 1         //bx==2*(n-1)
       xor dx, dx
       mov cx, d
     }

loop_d8:

asm {
       mov ax, es:[di+bx]
       div cx
       mov es:[di+bx], ax
       sub bx, 2
       jnc  loop_d8
    }

//***********************************************************************

    //optimize u

asm {
       std
       lds si, u
       mov bx, n
       mov cx, bx
       dec bx
       shl bx, 1
       mov ax, ds
       mov es, ax
       mov di, si
       add di, bx
       xor ax, ax
       repe scasw     //find non-zero
       je end        //if non found  return
       mov ax, cx
       inc ax         //return ax == the number of digits in u
    }

end:

asm {

     //optimize in q one digit

     mov bx, m
     sub bx, n
     shl bx, 1                 //bx == 2*(m-n)
     les di, q
     mov dx, 0
     cmp es:[di+bx], dx
     je  h
     inc bx
     inc bx
   }

 h:
asm  pop ds
}
