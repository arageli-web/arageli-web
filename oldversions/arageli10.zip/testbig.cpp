//********************************************************************
// testbig.cpp           Big arithmetics test
//
//N.Yu.Zolotykh 1999
//University of Nizhni Novgorod, Russia
//********************************************************************


#include<iostream.h>
#include<time.h>
#include "bigarith.h"

#if defined(__BORLANDC__) && !defined(__WIN32__)
#  include <alloc.h>
#endif


void main()
{

#if defined(__BORLANDC__) && !defined(__WIN32__)
  long memavail = coreleft();
#endif

  int error_count = 0;
  int test_count = 0;

time_t begin_time = time(NULL);

{
  big_int a, b;
  for (int i = 1; i < 100; i++)
  {
    cout << i << "\n";
    for (int j = 1; j < 100; j++)
    {
      test_count++;

      a = random_number(i);
      b = random_number(j);

      big_int summa = a + b;
      big_int subtraction = a - b;
      big_int multiplication = a * b;
      big_int division = a / b;
      big_int residue = a % b;

      if (summa - a != b)
      {
	cout << "error in addition" << "\n";
	error_count++;
      }
      if (subtraction + b != a)
      {
	cout << "error in subtraction" << "\n";
	error_count++;
      }
      if ((a != 0) && (multiplication / a != b) ||
	(a == 0) && (multiplication != 0))
      {
	cout << "error in multiplication" << "\n";
	error_count++;
      }
      if (a != b * division + residue)
      {
	cout << "error in division" << "\n";
        cout << "a="   << a << endl;
        cout << "b="   << b << endl;
        cout << "a/b=" << division << endl;
        cout << "a%b=" << residue << endl;
	error_count++;
      }
    }
  }
}

time_t end_time = time(NULL);

cout << "time = " << end_time - begin_time << "s\n";

cout << "Total tests number = " << test_count << "\n";
cout << "Error amount = " << error_count << "\n";

#if defined(__BORLANDC__) && !defined(__WIN32__)
memavail = coreleft() - memavail;
cout << " mem = " << memavail << " must be zero" << "\n" ;
#endif

}
