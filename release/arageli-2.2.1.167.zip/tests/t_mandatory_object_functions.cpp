/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_mandatory_object_functions.cpp
//  Created:    2005/4/7    8:10
//
//  Author: Andrey Somsikov
//	Modified by: Sergey Lyalin
*/


#include "ts_stdafx.hpp"


using namespace Arageli;

template<typename T>
bool mandatoryConstFunctions()
{
    bool fail = false;

#define ARAGELI_TS_CHECK(CHF, F)					\
	if(!CHF(F))										\
	{												\
		fail = true;								\
		tout										\
			<< "Failed: " << #CHF "(" #F ")\nwith"	\
			<< "\n\tT = " << typeid(T).name()		\
			<< "\n\t" #F " = " << F << '\n';		\
	}

    // positive tests
    ARAGELI_TS_CHECK(is_null, factory<T>::null());
    ARAGELI_TS_CHECK(is_unit, factory<T>::unit());
    ARAGELI_TS_CHECK(is_opposite_unit, factory<T>::opposite_unit());

    // negative tests
    ARAGELI_TS_CHECK(!is_unit, factory<T>::null());
    ARAGELI_TS_CHECK(!is_opposite_unit, factory<T>::null());
    ARAGELI_TS_CHECK(!is_null, factory<T>::unit());
    ARAGELI_TS_CHECK(!is_opposite_unit, factory<T>::unit()); 
    ARAGELI_TS_CHECK(!is_null, factory<T>::opposite_unit());
    ARAGELI_TS_CHECK(!is_unit, factory<T>::opposite_unit());

	//if(fail)
	//{
	//	tout << "\nFailed: type = " << typeid(T).name() << '\n';
	//}

    return fail;
}

TEST_FUNCTION(mandatory_const_functions, 
              "Tests existance and algorithmic correctness of the "
              "constant related functions that is mandatory for all objects")
{                                               
    bool fail = false;

//    fail |= mandatoryConstFunctions<polynom<int> >();
    fail |= mandatoryConstFunctions<sparse_polynom<int> >();
    fail |= mandatoryConstFunctions<monom<int> >();
    fail |= mandatoryConstFunctions<matrix<int> >();
    fail |= mandatoryConstFunctions<vector<int> >();
    fail |= mandatoryConstFunctions<rational<int> >();
    fail |= mandatoryConstFunctions<big_int>();

    fail |= mandatoryConstFunctions<sparse_polynom<big_int> >();
    fail |= mandatoryConstFunctions<monom<big_int> >();
    fail |= mandatoryConstFunctions<matrix<big_int> >();
    fail |= mandatoryConstFunctions<vector<big_int> >();
    fail |= mandatoryConstFunctions<rational<big_int> >();

    fail |= mandatoryConstFunctions<sparse_polynom<rational<int> > >();
    fail |= mandatoryConstFunctions<monom<rational<int> > >();
    fail |= mandatoryConstFunctions<matrix<rational<int> > >();
    fail |= mandatoryConstFunctions<vector<rational<int> > >();

    fail |= mandatoryConstFunctions<sparse_polynom<rational<big_int> > >();
    fail |= mandatoryConstFunctions<monom<rational<big_int> > >();
    fail |= mandatoryConstFunctions<matrix<rational<big_int> > >();
    fail |= mandatoryConstFunctions<vector<rational<big_int> > >();

    fail |= mandatoryConstFunctions<sparse_polynom<residue<int> > >();
    fail |= mandatoryConstFunctions<monom<residue<int> > >();
    fail |= mandatoryConstFunctions<matrix<residue<int> > >();
    fail |= mandatoryConstFunctions<vector<residue<int> > >();


    if (fail)
        return resFAIL;

    return resOK;
}

/* End of file t_mandatory_object_functions.cpp */
