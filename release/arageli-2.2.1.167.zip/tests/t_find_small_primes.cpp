/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_find_small_primes.cpp
//  Created:    17.01.2006
//
//  Author: Aleksey Bader
*/


#include "ts_stdafx.hpp"


TEST_FUNCTION(find_small_primes, "Test find_small_primes fuction.")
{
    using namespace Arageli;
	TestResult res = resOK;

    int N = 50;
    int *int_array = new int[N];
    small_primes(int_array, N);
    int k = 0;
    
    for(int i = 0; i < N && k < 5; ++i)
    {
        //std::cout << int_array[i] << ' ';
        if (!is_prime(int_array[i])) k++;
    }
    if (k > 0) 
    {
        res = resFAIL;
        tout << "Test fail on " << k << "tests." << '\n';
    }
    return res;
}


/* End of file t_find_small_primes.cpp */
