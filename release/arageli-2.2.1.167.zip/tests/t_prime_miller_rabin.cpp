/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_prime_miller_rabin.cpp
//  Created:    24.12.2005
//
//  Author: Aleksey Bader
*/


#include "ts_stdafx.hpp"


TEST_FUNCTION(is_pseudoprime_miller_rabin, "Test is_pseudoprime_miller_rabin function")
{
	using namespace Arageli;
	
	bool fail = false;

	for(int i = 3; i <= 1000; ++i)
	{
		if(is_prime(i) != is_pseudoprime_miller_rabin(i, 20))
		{
			tout << "is_pseudoprime_miller_rabin is failed on i = int(" << i << ").\n";
			fail = true;
		}

		if(is_prime(big_int(i)) != is_pseudoprime_miller_rabin(big_int(i), 20))
		{
			tout << "is_pseudoprime_miller_rabin is failed on i = big_int(" << i << ").\n";
			fail = true;
		}
	}

	if(fail)return resFAIL;
    return resOK;
}


/* End of file t_prime_miller_rabin.cpp */
