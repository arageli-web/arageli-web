// File : t_opposite.cpp
// Author : Zaitsev Mikhail
// Tester : Aleksandrov Vladimir
// Date of creation : 2006/01/26
// Date of modification : 2006/01/31
// Testing date : 
// Description : Test for function opposite()
// Using functions : is_null(),operator+=()
// Errors :


#include "../ts_stdafx.hpp"
#include "rand.hpp"

using namespace Arageli;


template <class T>
bool m_opposite(const char* s)
{
  matrix<T> A(s);
  matrix<T> O=A;
  O.opposite();

  if(!((A+=O).is_null()))
  {
    tout<<"function failed with"<<s;
	return true;
  }

  return false;

}


TEST(matrix,opposite,"Test for function opposite")
{
  bool fail=false;
  RNG element(2,16);

  for(int k=0;k<10;k++)
 {
	 int cols=1+element.Rand()%5;
	 int rows=1+element.Rand()%5;
	 std::strstream buff;
	 buff<<'(';
	 for(int i=0; i<rows; i++)
	 {
		buff<<'(';
		for(int j=0; j<cols-1; j++)
			// 1: buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<',';
			// 2: buff<<(element.Rand()-(1<<14))<<',';
			 buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
		// 1: buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<')';
		// 2: buff<<(element.Rand()-(1<<14))<<')';
		 buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		if(i!=rows-1) buff<<',';
	 }
	 buff<<')';
	 buff<<'\x0';
     
	 //fail |=m_opposite<rational>(buff.str());
	 //fail |=m_opposite<int>(buff.str());
	 fail |=m_opposite<big_int>(buff.str());

 }

 if(fail) return resFAIL;
 return resOK;

}

/* File t_opposite.cpp */