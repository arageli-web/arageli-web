// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Code of random number generation class.

#include "../ts_stdafx.hpp"
#include "rand.hpp"

int RNG::ShortRand()
{
	return prev=(prev*ARAGELI_TESTSYS_RAND_A+ARAGELI_TESTSYS_RAND_C)%ARAGELI_TESTSYS_RAND_M;
}

void RNG::init (int tParam, int tRange)
{
	bool def=false;

	if(tParam<0)
		def=true;

	if(tRange<=0)
		def=true;

	if(def)
		param=0, range=1<<16, prev=0;
	else
	{	
		param=tParam;
		range=tRange;
		prev=param;
	}
	bottom=0;

	int realRange;
	for( realRange=0; range>1; range/=2,realRange++ );
	range=1<<realRange;//���� �� ������ �� �������� :)

	mas[0]=param;
	for(int i=1; i<55; i++)
		mas[i]=ShortRand();

	for(int i=0; i< ARAGELI_TESTSYS_RAND_COUNT; i++)
		Rand();
}


int RNG::Rand()
{
	int tem=mas[bottom]=(mas[bottom]+mas[(bottom+22)%55])%range;
	bottom=(++bottom)%55;

	return tem;
}

RNG::~RNG()
{}
