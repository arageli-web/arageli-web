// Author : Sidnev Alexey
// Tester :
// Creation date : 03.02.2006
// Modification date: 06.02.2006
// Testing date: 
// Description : Test of opposite(). 
//		Be used: t_opposite.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"

using namespace Arageli;

bool vector_opposite_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int vsize=gen.Rand()%30;
		Arageli::vector<int> vi(vsize);

		for(int i=0; i<vsize; i++)
			vi[i]=1+gen.Rand();

		Arageli::vector<big_int> vbi(vsize);

		for(int i=0; i<vsize; i++)
			vbi[i]=1+gen.Rand();

		Arageli::vector<double> vd(vsize);

		for(int i=0; i<vsize; i++)
			vd[i]=gen.Rand()+1.0;

		Arageli::vector<float> vf(vsize);

		for(int i=0; i<vsize; i++)
			vf[i]=gen.Rand()+1.0;

		fail |=t_opposite< Arageli::vector<int> >(vi);
		fail |=t_opposite< Arageli::vector<big_int> >(vbi);
		fail |=t_opposite< Arageli::vector<double> >(vd);
		fail |=t_opposite< Arageli::vector<float> >(vf);

		Arageli::vector<rational<int> > vri(vsize);

		for(int i=0; i<vsize; i++)
			vri[i]=(rational<int>)(gen.Rand()+1);


		Arageli::vector<rational<big_int> > vrbi(vsize);

		for(int i=0; i<vsize; i++)
			vrbi[i]=(rational<big_int>)(gen.Rand()+1);

		fail |=t_opposite< Arageli::vector<rational<int> > >(vri);
		fail |=t_opposite< Arageli::vector<rational<big_int> > >(vrbi);

	
		if(fail) 
		{
			tout<<"Function vector_opposite_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(vector,opposite,"Test opposite() function.")
{ 
	bool fail=vector_opposite_test(3426,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}