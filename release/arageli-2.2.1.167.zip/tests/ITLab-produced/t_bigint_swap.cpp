// Author : Aleksandrov Vladimir
// Tester : Sidnev Alexey 
// Creation date : 20.01.2006
// Modification date: 30.01.2006
// Testing date: 12.02.2006
// Description :

#include "../ts_stdafx.hpp"
#include "rand.hpp"

#include <time.h>
#include <strstream>

using namespace Arageli;



template <class T>
bool big_int_swap (const T A,const T B)
{
	try
	{
		big_int a=A, b=A, d=B, c=B;
		
		a.swap(d);
		if ((a!=c)||(d!=b))
		{
			tout<<"function swap failed with A="<<A<<", B="<<B<<'\n';
			return true;
		}
		return false;
	}
	catch(Arageli::exception& e)
	{
		tout << "EXCEPTION: ";
		e.output(tout); tout << '\n';
		return true;
	}
}


bool big_int_swap_test(int param, int count)
{
	bool fail=false;
	RNG gen(param,1<<16);

		fail |= big_int_swap(0,0);
	
		char x=3;
		char y=4;
		fail |= big_int_swap((signed char) (x),(signed char) (y));
		fail |= big_int_swap((unsigned char) (x),(unsigned char) (y));
		fail |= big_int_swap(x,y);

		if(fail) 
		{
			tout<<"Function big_int_swap_test failed on first step.\n";
			return fail;
		}

	
		for (int k=0; k<count; k++)
		{
			int a=gen.Rand();
			int b=gen.Rand();
			fail |= big_int_swap(a,b);
			fail |= big_int_swap(double (a),double (b));
			fail |= big_int_swap(float (a),float (b));
			fail |= big_int_swap(long (a),long (b));
			fail |= big_int_swap((long double) (a),(long double) (b));
			fail |= big_int_swap((signed short) (a),(signed short) (b));
			fail |= big_int_swap((unsigned short) (a),(unsigned short) (b));
			fail |= big_int_swap((unsigned int) (a),(unsigned int) (b));
			fail |= big_int_swap((signed int) (a),(signed int) (b));

			if(fail) 
			{
				tout<<"Function big_int_swap_test failed on "<<k+1<<" step.\n";
				return fail;
			}
		}
		bool a1=1;
		bool a2=1;
		fail |= big_int_swap(a1,a2);

		if(fail) 
		{
			tout<<"Function big_int_swap_test failed on last step.\n";
			return fail;
		}

	return false;
}


TEST(big_int,swap,"Test")
{ 
	bool fail=big_int_swap_test(100,1000);
	
	if(fail) return resFAIL;
	return resOK;

}
