// File : t_matrix_is_squarte.cpp
// Author : Zaitsev Mikhail
// Tester : Aleksandrov Vladimir
// Date of creation : 2006/01/27
// Date of modification : 2006/01/31
// Testing date :
// Description : Test for function is_squarte()
// Using functions : ncols(),nrows()
// Errors : 


#include "../ts_stdafx.hpp"
#include "rand.hpp"

using namespace Arageli;


template <class T>
bool m_is_squarte(const char* s)
{
  matrix<T> A(s);
  bool result=false;
  if(A.ncols()==A.nrows()) result=true;

 if(result!=A.is_squarte())
  {
    tout<<"function failed with"<<s;
	return true;
  }

 return false;

}


TEST(matrix,is_squarte,"Test for function is_squarte")
{
  bool fail=false;
  RNG element(2,16);

  for(int k=0;k<10;k++)
 {
	 int cols=1+element.Rand()%5;
	 int rows=1+element.Rand()%5;
	 std::strstream buff;
	 buff<<'(';
	 for(int i=0; i<rows; i++)
	 {
		buff<<'(';
		for(int j=0; j<cols-1; j++)
			// 1: buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<',';
			// 2: buff<<(element.Rand()-(1<<14))<<',';
			 buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
		// 1: buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<')';
		// 2: buff<<(element.Rand()-(1<<14))<<')';
		 buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		if(i!=rows-1) buff<<',';
	 }
	 buff<<')';
	 buff<<'\x0';

     // 1: fail |=m_is_squarte<rational<> >(buff.str());
	 // 2: fail |=m_is_squarte<int>(buff.str());
	 fail |=m_is_squarte<big_int>(buff.str());

 }

 if(fail) return resFAIL;

 return resOK;

}

/* End of file t_matrix_is_squarte.cpp */