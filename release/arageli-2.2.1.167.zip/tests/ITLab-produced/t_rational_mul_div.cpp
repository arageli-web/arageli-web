// Author : Sidnev Alexey
// Tester :
// Creation date : 1.02.2006
// Modification date: 1.02.2006
// Testing date: 
// Description : Test of *, / operations. 
//		Be used: t_rational_mul_div, t_mul_div.


#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;


bool rational_mul_div_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int iper1=gen.Rand(), iper2=gen.Rand();
		big_int biper1=gen.Rand(), biper2=gen.Rand();

		while(!( iper2=gen.Rand() ));
		while(!( biper2=gen.Rand() ));

		//rational<int> ri1(iper1,iper2);
		rational<big_int> rbi1(biper1,biper2);

		while(!( iper2=gen.Rand() ));
		while(!( biper2=gen.Rand() ));

		//rational<int> ri2(gen.Rand(),iper2);
		rational<big_int> rbi2(gen.Rand(),biper2);

		//fail |=t_rational_mul_div<int,int>(ri1, ri2);
		fail |=t_rational_mul_div<big_int,big_int>(rbi2, rbi2);
		//fail |=t_rational_mul_div<big_int,int>(rbi1, ri1);

		//fail |=t_mul_div<rational<big_int>,rational<int> >(rbi1, ri1);
		//fail |=t_mul_div<rational<int>,rational<int> >(ri1, ri2);
		fail |=t_mul_div<rational<big_int>,rational<big_int> >(rbi1, rbi2);
	
		if(fail) 
		{
			tout<<"Function rational_mul_div_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}


TEST(rational,mul_div,"Test *,/ functions.")
{ 
	bool fail=rational_mul_div_test(3456,1000);

/*
	rational<int> a(4,44);
	rational<big_int> b(11,8);
	b/a;
*/

	if(fail)
		return resFAIL;
	else
		return resOK;
}
