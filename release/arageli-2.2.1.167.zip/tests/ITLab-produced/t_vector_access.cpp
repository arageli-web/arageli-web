// Author : Sidnev Alexey
// Tester :
// Creation date : 18.02.2006
// Modification date: 18.02.2006
// Testing date: 
// Description : Test of [], (...), el, at, insert, push, erase functions. 
//		Be used: t_vector_access, t_vector_set_get.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_vector.hpp"

using namespace Arageli;

bool vector_access_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int vsize=gen.Rand()%30;
		
		Arageli::vector<int> vi(vsize);
		int i=gen.Rand();
		for(int i=0; i<vsize; i++)
			vi[i]=gen.Rand();

		Arageli::vector<big_int> vbi(vsize);
		big_int bi=gen.Rand();
		for(int i=0; i<vsize; i++)
			vbi[i]=gen.Rand();

		Arageli::vector<double> vd(vsize);
		double d=gen.Rand();
		for(int i=0; i<vsize; i++)
			vd[i]=gen.Rand();

		Arageli::vector<float> vf(vsize);
		float f=gen.Rand();
		for(int i=0; i<vsize; i++)
			vf[i]=gen.Rand();

		Arageli::vector<rational<int> > vri(vsize);
		rational<int> ri=gen.Rand();
		for(int i=0; i<vsize; i++)
			vri[i]=(rational<int>)gen.Rand();

		Arageli::vector<rational<big_int> > vrbi(vsize);
		rational<big_int> rbi=gen.Rand();
		for(int i=0; i<vsize; i++)
			vrbi[i]=(rational<big_int>)gen.Rand();

		fail |=t_vector_access< rational<int> >(vri);
		fail |=t_vector_access< rational<big_int> >(vrbi);
		fail |=t_vector_access< int >(vi);
		fail |=t_vector_access< big_int >(vbi);
		fail |=t_vector_access< double >(vd);
		fail |=t_vector_access< float >(vf);

		fail |=t_vector_set_get< rational<int> >(vri, ri);
		fail |=t_vector_set_get< rational<big_int> >(vrbi, rbi);
		fail |=t_vector_set_get< int >(vi, i);
		fail |=t_vector_set_get< big_int >(vbi, bi);
		fail |=t_vector_set_get< double >(vd, d);
		fail |=t_vector_set_get< float >(vf, f);

		if(fail) 
		{
			tout<<"Function vector_plus_minus_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(vector,access,"Test [], (...), el, at, insert, push, erase functions.")
{ 
	bool fail=vector_access_test(8542,1000);
	
	if(fail)
		return resFAIL;
	else
		return resOK;
}