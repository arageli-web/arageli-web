// Author : Aleksandrov Vladimir
// Tester : 
// Creation date : 20.01.2006
// Modification date: 30.01.2006
// Testing date: 
// Description :

//������� ������ :)

#include "../ts_stdafx.hpp"
#include "rand.hpp"

#include <time.h>
#include <strstream>

using namespace Arageli;



template <class T>
bool big_int_even_odd (const T A)
{	
	try
	{
		big_int a=A, b=A;
		
		if (a[0]!=a.is_odd()) 
		{
			tout<<"function even_odd failed no 1 check with A="<<A<<'\n';
			return true;
		}
	
		if (a[0]==a.is_even()) 
		{
			tout<<"function even_odd failed on 2 check with A="<<A<<'\n';
			return true;
		}	
	
		if (a.is_odd()==a.is_even()) 
		{
			tout<<"function even_odd failed on 3 check with A="<<A<<'\n';
			return true;
		}
		return false;
	}
	catch(Arageli::exception& e)
	{
		tout << "EXCEPTION: ";
		e.output(tout); tout << '\n';
		return true;
	}
}


bool big_int_even_odd_test(int param, int count)
{
	bool fail=false;
	RNG gen(param,1<<16);

	fail |= big_int_even_odd((int)0);	// ������
	
	char x=3;
	fail |= big_int_even_odd((signed char) (x));
	fail |= big_int_even_odd((unsigned char) (x));
	fail |= big_int_even_odd(x);
	
	if(fail) 
		{
			tout<<"Function big_int_even_odd_test failed on first step.\n";
			return fail;
		}
	
	for (int k=0; k<count; k++)
	{
		int a=gen.Rand();
		fail |= big_int_even_odd(a);
		fail |= big_int_even_odd(double (a));
		fail |= big_int_even_odd(float (a));
		fail |= big_int_even_odd(long (a));
		fail |= big_int_even_odd((long double) (a));
		fail |= big_int_even_odd((signed short) (a));
		fail |= big_int_even_odd((unsigned short) (a));
		fail |= big_int_even_odd((unsigned int) (a));
		fail |= big_int_even_odd((signed int) (a));

		if(fail) 
			{
				tout<<"Function big_int_even_odd_test failed on "<<k+1<<" step.\n";
				return fail;
			}
	}
	
	bool a1=1;
	fail |= big_int_even_odd(a1);
	
	if(fail) 
		{
			tout<<"Function big_int_even_odd_test failed on last step.\n";
			return fail;
		}
	return false;
}



TEST(big_int,even_odd,"Test")
{ 
	bool fail=big_int_even_odd_test(100,1000);
	
	if(fail) return resFAIL;
	return resOK;

}
