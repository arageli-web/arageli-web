// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Test of numerator(), denominator(). 
//		Be used: t_rational_numerator_denominator.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;

bool rational_numerator_denominator_test(int param, int count)
{
	bool fail=false;
	RNG gen(param,1<<8);

	for(int k=0;k<count;k++)
	{
		int per=gen.Rand();
		big_int bper=gen.Rand();

		while(!( per=gen.Rand() ));
		while(!( bper=gen.Rand() ));

		fail |=t_rational_numerator_denominator<int>(gen.Rand(), per);
		fail |=t_rational_numerator_denominator<big_int>(gen.Rand(), bper);
	
		if(fail) 
		{
			tout<<"Function rational_numerator_denominator_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,numerator_denominator,"Test numerator(), denominator() functions.")
{ 
	bool fail=rational_numerator_denominator_test(4393,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}