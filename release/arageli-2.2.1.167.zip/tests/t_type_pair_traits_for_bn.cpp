/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_type_pair_traits_for_bn.cpp
//  Created:    27.01.2006
//
//  Author: Sergey Lyalin
*/


#include "ts_stdafx.hpp"


using namespace Arageli;

TEST_FUNCTION(type_pair_traits_for_bn,
			  "Test convertible properties for buit-in numerics")
{                                               
	TestResult res = resOK;

	#define ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(T1, T2)			\
		if(type_pair_traits<T1, T2>::is_specialized)			\
		{														\
			if(!type_pair_traits<T1, T2>::is_convertible)		\
			{													\
				res = resFAIL;									\
				tout											\
					<< "!type_pair_traits<" << #T1 << ", "		\
					<< #T2 << ">::is_convertible\n";			\
			}													\
			if(!type_pair_traits<T1, T2>::is_safe_convertible)	\
			{													\
				res = resFAIL;									\
				tout											\
					<< "!type_pair_traits<" << #T1 << ", "		\
					<< #T2 << ">::is_safe_convertible\n";		\
			}													\
		}														\
		else													\
		{														\
			tout												\
				<< "!type_pair_traits<" << #T1 << ", "			\
				<< #T2 << ">::is_specialized\n";				\
		}

	// The following is only some of the possibilites.
	// We need to add more.

	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, char);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, signed char);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, unsigned char);

	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, short);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, int);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, long);
	
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, float);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, double);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, long double);

	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, unsigned short);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, unsigned int);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(bool, unsigned long);
	
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(signed char, short);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(short, int);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(int, int);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(int, long);
	
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(float, double);
	ARAGELI_TESTSYS_TEST_BUITIN_PAIR1(double, long double);

	return res;
}
