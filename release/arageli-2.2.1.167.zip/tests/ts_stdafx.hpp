// ts_stdafx.hpp : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <cstdlib>
#include <iostream>
#include <sstream>
#include <strstream>	// non standard feature
#include <ctime>
#include <iomanip>
#include <string>

#include <arageli/arageli.hpp>
#include <arageli/random.hpp>
#include <arageli/lll.hpp>

#include <ts/ts.h>

// TODO: reference additional headers your program requires here


////////////////////////////////////////////////////////////////

#pragma warning(disable : 4018)
#pragma warning(disable : 4800)
