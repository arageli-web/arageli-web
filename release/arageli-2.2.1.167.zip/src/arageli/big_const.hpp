/*****************************************************************************
	
	big_const.hpp -- functions that calculates several constants.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2006
	Copyright (C) University of Nizhni Novgorod, Russia, 2006

	// TODO: Authors of this file, please, add your copyrights here.

*****************************************************************************/

/**
	\file
	All fuctions return integer result
	But the sought value equal result / 2 ^ (kbits + 1) 
	Functions terminating by _o return result with 
	0 <= error <= (1/2) ^ ( kbits ). 
	Functions terminating by _u return result with   
	-(1/2 )^ ( kbits ) <= error <=0 
	Functions without termination return result with
	-(1/2 )^ ( kbits + 1 ) <= error <= -(1/2 )^ ( kbits + 1 )	
	It means that (sought value) * 2 ^ ( kbits + 1) is in range [ res, res + 2 ]
	where res is result returned by "_u"  function. 
*/

#ifndef _ARAGELI_big_const_h_
#define _ARAGELI_big_const_h_

#include <cstddef>

#include "config.hpp"
#include "big_int.hpp"
#include "std_import.hpp"

namespace Arageli
{

big_int ln1_25_o(std::size_t kbits);//calculate ln(1.25) with overflow
big_int ln1_25(std::size_t kbits);//calculate ln(1.25)
big_int ln1_25_u(std::size_t kbits);//calculate ln(1.25) with underflow

big_int ln2(std::size_t kbits);//calculate ln(2)
big_int ln2_u(std::size_t kbits);//calculate ln(2) with underflow
big_int ln2_o(std::size_t kbits);//calculate ln(2) with oveflow

big_int lg_2   ( std::size_t nbits ); //calculate lg2 with nbits significant bits  
big_int lg_2_u ( std::size_t nbits ); //calculate lg2 with nbits significant bits  
big_int lg_2_o ( std::size_t nbits ); //calculate lg2 with nbits significant bits  

big_int log2_10( std::size_t nbits ) ;//calculate log2_10
big_int log2_10_o( std::size_t nbits ) ;//calculate log2_10 with nbits significant bits with overflow  
big_int log2_10_u( std::size_t nbits ) ;//calculate log2_10 with nbits significant bits with underflow  

big_int exp ( big_int arg, std::size_t kbits,   int factor = 0 );
big_int exp_u ( big_int arg, std::size_t kbits, int factor = 0 );
big_int exp_o ( big_int arg, std::size_t kbits, int factor = 0 );

big_int exp_2 ( big_int arg, std::size_t kbits,   int factor = 0 );
big_int exp_2_u ( big_int arg, std::size_t kbits, int factor = 0 );
big_int exp_2_o (big_int arg, std::size_t kbits,  int factor = 0 );

big_int e (std::size_t kbits  );
big_int e_u (std::size_t kbits  );
big_int e_o ( std::size_t kbits  );

big_int ln10 (std::size_t kbits);
big_int ln10_u(std::size_t kbits);//calculate ln(1.25) with underflow
big_int ln10_o(std::size_t kbits);//calculate ln(1.25) with oveflow

}

#endif 