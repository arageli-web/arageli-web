/*****************************************************************************
	
	big_float.cpp -- Big Float Numbers implementation.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2006
	Copyright (C) University of Nizhni Novgorod, Russia, 2006

	// TODO: Authors of this file, please, add your copyrights here.

*****************************************************************************/

//#if 0	// WARNING! DISABLED WHILE PORTING!

#include "config.hpp"

#include <sstream>

#include "powerest.hpp"
#include "big_float.hpp"
#include "logarithm.hpp"

#include "big_float.hpp"


#pragma warning(disable : 4244)	// here: conversion from long double to size_t,
								// possible loss of data


namespace Arageli
{


//a-la bigarith 
void big_float_warning ( const char *s )
{
  std::cerr << "Big float warning: " << s << "\n";
}

void big_float_error ( const char *s )
{
  std::cerr << "Big float error: " << s << "\n";
}

void big_float_fatal_error(const char *s)
{
  std::cerr << "Big float fatal error: \n " << s << "\n";
  exit(1);
}


#define CHECK_PREC(p)  if ( p < PREC_MIN || p > PREC_MAX ) \
	{\
		std::cout << p;\
		big_float_warning ( "attempt to use illegal precision. PREC_MIN is used as default precision" );\
		p = PREC_MIN;\
	}\
	//else prec = p;
#define CHECK_MODE(m) if ( m < EXACT || m > TO_INF ) \
 {\
	 big_float_warning ( "attempt to set illegal rounding mode. TO_NEAREST is used as default rounding mode" );\
	 m = TO_NEAREST;\
 }\
 //else mode = m;	
	
//returns |n| mod m
unsigned fracsion ( int n, unsigned m )
{ 
	if ( n < 0 ) 
	return (m-((-n)%m))%m; 
	else return (n%m);
}

int get_exponent_of_double(double d)
{
 
 int *pd = (int*)&d;
 pd += sizeof ( double ) / sizeof ( int ) - 1;
 *pd <<= 1;
 *pd += 0x80000000;//? only for 32 bits 
 *pd >>= ( sizeof ( int ) * 0x8 - 0xB );
  return *pd + 1;
}

_Internal::digit * get_mantissa_of_double (double d) //array of digits representing mantissa of d
{
	_Internal::digit *man;
	_Internal::digit *pint;
	man = new _Internal::digit [ 4 ];
	if (!man)
	{
		std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
		exit ( 1 );
	}
	pint = ( _Internal::digit * ) &d;
	man [ 0 ] = ((*pint) << 16 ) >> 16;
	man [ 1 ] =  ( *pint ) >> 16;
	pint++;
	man [ 2 ] = ((*pint) << 16 ) >> 16;
	man [ 3 ] =  ((( *pint ) << 12 ) >> 28) + 16;
	
	return man;
}

// TODO: Delete this function! It's already implemented (and better).
//swap  a  and b
inline void swap( big_int &a, big_int &b )
{
	a = a + b;
	b = a - b;
	a = a - b;
}

//���������� ���������� ����(digit) � ����� ���� big_int.()  unused now 
inline long get_number_of_digits ( big_int b )
{
	return (b.length() - 1 ) / _Internal::bits_per_digit + 1;
}

//���������� ���� ����� ���� big_int ����� �� ����� ���������
//�������, ������� ���������� ���� �������� �� ��������� � �����
inline int get_sign ( big_int s )
{
	if ( s > 0 ) return 1;
	else return -1;
}

//������������ � ���������� �������� ����������
/*void normalize ( long prec,  int mode, big_int &s, big_int &e )
{
	int is_digit = 0;
	big_int stemp ( s ); 
	
	if ( s == 0 ) 
	{
		 e = 0;
		return;
	}//���� s=0, �� ���������� ���� ��������
	if ( mode == EXACT) return;//������ �� ������

	while ( get_number_of_digits ( s ) < prec )
	{
		s = s << bits_per_digit;// *(max_digit+1);
		e = e - 1;
	}//�������� ���� � �����
	if ( get_number_of_digits ( s ) == prec ) return;
	while (	get_number_of_digits ( s ) > ( prec + 1 ) )
	{
		stemp = s >> bits_per_digit;
		if ( !( is_digit ) && (stemp << bits_per_digit) != s ) is_digit = 1;
		e = e + 1;
		s = stemp;
	}
	switch (mode)
	{	
		case TO_NEAREST:
                       s = ( s + BASE * get_sign ( s ) / 2 ) >> bits_per_digit;
                       e = e + 1;
                       if ( get_number_of_digits ( s ) > prec) 
					   {
						   s = s >> bits_per_digit;
						   e = e+1;
					   }
                       break;
                     
    case TO_ZERO :
                       s = s >> bits_per_digit;
                       e = e + 1;
                       break;
	case TO_P_INF  :
                       if ( s < 0 ) s = s >> bits_per_digit;
                       else 
					   {
							if ( is_digit ) s = ( s >> bits_per_digit) + 1;
							else 
							{
                                   stemp = s >> bits_per_digit;
                                   if ( ( stemp << bits_per_digit ) != s)  s = stemp + 1;
                                   else  s = s >> bits_per_digit;
                            }
                        }
                       e = e + 1;

                       if ( get_number_of_digits ( s ) > prec ) 
					   {
						   s = s >> bits_per_digit;
						   e = e + 1; 
					   }
                       break;
      case TO_M_INF :
                       if ( s > 0 ) s = s >> bits_per_digit;
                       else 
					   {
                             if ( is_digit ) s = s >> ( bits_per_digit ) - 1;
                             else 
							 {
                                    stemp = s >> bits_per_digit;
                                    if ( ( stemp << bits_per_digit ) != s) s = stemp - 1;
                                    else s = s >> bits_per_digit;
                              }
                       }
                       e=e+1;

                      if ( get_number_of_digits ( s ) > prec ) 
					  {
						  s = s >> bits_per_digit; 
						  e = e + 1;
					  }
                      break;
	case TO_INF     :
                       //s=s/(max_digit+1);
                       if ( is_digit )  s = ( s >> bits_per_digit) + get_sign ( s ); 
                       else 
					   {
                             stemp = s >> bits_per_digit;
                             if ( (stemp << bits_per_digit ) != s) s = stemp + get_sign ( s );
                             else        s=s/(max_digit+1);
                       }
                       e = e + 1;
                       if ( get_number_of_digits ( s ) > prec )
					   {
						   s = s >> bits_per_digit;
						   e = e + 1; 
					   }
                       break;
                     
    default         : break;

    }//switch(mode)
	return;
}*/

//normalization 
void big_float::normalize_1 ( long prec, long mode )
{
	if ( !s.sign() ) 
	{
		e = 0;
		return;
	}//significant s=0, then exponenta = 0 
	
	int s_len = s.length() - prec; 
		
	if ( mode == EXACT && s.length() <= PREC_MAX ||  (!s_len)  ) return;// do nothing - mantissa has apropriate length 
	if ( s_len < 0  ) 
	{
		s = s << -s_len;
		e = e + s_len;
		return;
	}//write zero at the end and return
	if ( mode == EXACT )
	{
		mode = TO_NEAREST; // s.lenght > PREC_MAX 
		big_float_error ( "can't perfom operarion with EXACT rounding mode" );
	}
	int is_digit = 0; // needs then rounds to +-infinity
	is_digit = ( (s >> s_len - 1) << s_len - 1 != s ); 
	s = s >> s_len - 1;
	e = e + s_len - 1; 

	switch (mode)
	{	
		case TO_NEAREST:
                       s = ( s + s.sign() ) >> 1;
                       e = e + 1;
                       if ( s.length() > prec ) 
					   {
						   s = s >> 1;
						   e = e + 1;
					   }
                       break;
                     
    case TO_ZERO :
                       s = s >> 1;
                       e = e + 1;
                       break;
	case TO_P_INF  :
                       if ( s.sign() < 0 ) s = s >> 1;
                       else 
					   {
							if ( is_digit ) s = ( s >> 1) + 1;
							else 
								s = s + 1 >> 1;
                       }
                       e = e + 1;

                       if ( s.length() > prec ) 
					   {
						   s = s >> 1;
						   e = e + 1; 
					   }
                       break;
      case TO_M_INF :
                       if ( s.sign() > 0  ) s = s >> 1;
                       else 
					   {
							if ( is_digit ) s = ( s >> 1) - 1;
							else 
								s = s - 1 >> 1;
                       }
                       e = e + 1;

                       if ( s.length() > prec ) 
					   {
						   s = s >> 1;
						   e = e + 1; 
					   }
                       break;
	case TO_INF     :
                       //s=s/(max_digit+1);
                       if ( is_digit )  s = ( s >> 1 ) + s.sign();
                       else 
					   {
                             if ( s [ 0 ] )
								 s = ( s >> 1 ) + s.sign();
							 else    s = s >> 1;
                       }
                       e = e + 1;
                       
					   if ( s.length() > prec )
					   {
						   s = s >> 1;
						   e = e + 1; 
					   }
                       break;
                     
    default         : break;

    }//switch(mode)
	return;
}
//returns exponent
big_int big_float::get_exponent( void ) const
{
	return e;
}

//returns mantissa
big_int big_float::get_significant( void ) const
{
	return s;
}

//default constructor
big_float::big_float(void)// : e(0),s(0)
{
 	//e = s = 0;
}
//copy constructor
big_float::big_float ( const big_float &b )
{
	e = b.e;
	s = b.s;
}

//constructor (from string to big_float) //not implemented yet
big_float::big_float ( char *str )
{
	std::istringstream s ( str );
	s >> *this;
}

//constructor  ( from two big_int to big_float )
big_float::big_float ( const big_int &s, const big_int &e )
{
	this->e = e;
	this->s = s;
	normalize_1 ( ); //???
}

//constructor (from double to big_float) (only for 32 bits )
big_float::big_float( double b )
{
	if ( b == 0.0 ) 
	{
		big_float ();
		return;
	}
	_Internal::digit *man = get_mantissa_of_double ( b );

	if ( b > 0.0 )
	{
		s.free_mem_and_alloc_number( 1, man, 4 );
	}
	else 
	{
		s.free_mem_and_alloc_number( -1, man, 4 );
	}
	e = get_exponent_of_double ( b ) - 52;
	//e = i / 16;
	//e=(get_exponent_of_double(b)-fracsion(get_exponent_of_double(b)-52,16)-52)/16;
	normalize_1 (  );///???
}
big_float::big_float( int i )
{
	*this = big_float( double ( i ));
}

//destructor
big_float::~big_float(){}

/**
	operator=
*/
big_float & big_float::operator = ( const big_float &b  )  
{
	if ( this == &b  ) return *this;
	s = b.s;
	e = b.e;
	return *this;
}

big_float & big_float::operator = ( const double d  )  
{
	if ( d == 0.0 ) 
	{
		s = 0;
		e = 0;
		return *this;
	}
	_Internal::digit *man = get_mantissa_of_double ( d );

	if ( d > 0.0 )
	{
		s.free_mem_and_alloc_number( 1, man, 4 );
	}
	else 
	{
		s.free_mem_and_alloc_number( -1, man, 4 );
	}
	e = get_exponent_of_double ( d ) - 52;
	//e = i / 16;
	//e=(get_exponent_of_double(b)-fracsion(get_exponent_of_double(b)-52,16)-52)/16;
	normalize_1 (  );///???
	return *this;
}

big_float & big_float::operator = ( const int i)
{
	return big_float::operator=( double(i) );
}

/*
*  compare operations 
*/
int cmp ( const big_float & a, const big_float & b ) 
{
	big_float temp = a - b;
	return temp.get_significant().sign();
}

int operator == ( const big_float & a, const big_float & b )
{
	return  cmp ( a, b ) == 0;
	//return ( a.s == b.s && a.e == b.e ); it may be wrong then a and b are present with different precision
}

int operator != ( const big_float & a, const big_float & b )
{
	return cmp ( a, b ) != 0;	 
}

int operator > (const big_float & a, const big_float & b)
{
	return cmp ( a, b ) == 1; 
}

int operator >= (const big_float & a, const big_float & b)
{
	return cmp ( a, b ) != -1;
}

int operator < (const big_float & a, const big_float & b)
{
	return cmp ( a, b ) == -1;
}

int operator <= (const big_float & a, const big_float & b)
{
	return cmp ( a, b ) != 1;
}


//set default global bits precision 
void big_float::set_global_precision ( long p )
{
	CHECK_PREC(p)
	prec = p;
}

//set global rounding mode
void big_float::set_round_mode ( int m )
{
	CHECK_MODE(m)
	mode = m;
}

//unary plus
big_float operator + ( const big_float &a )
{
	return a;// normalizaton needed may be ???
}

//unary minus
big_float operator - ( const big_float &a )
{
	big_float b;
	b.s = -a.s;
	b.e = a.e;
	return b;// normalizaton needed may be ???
}

//operator + 
big_float operator + (const big_float & b, const big_float & c)
{
	return add ( b, c, big_float::prec, big_float::mode);
}

//operator -
big_float operator - (const big_float & b, const big_float & c)
{
	return sub( b, c, big_float::prec, big_float::mode);
}

//operator *
big_float operator * (const big_float & b, const big_float & c)
{
	return mul( b, c, big_float::prec, big_float::mode);
}

//operator /
big_float operator / (const big_float & b, const big_float & c)
{
	return div ( b, c, big_float::prec, big_float::mode );
}

// adding ( with default precision and default rounding mode )
big_float add(const big_float & b, const big_float & c )
{
	return add ( b, c, big_float::prec, big_float::mode );
}

// subtraction ( with default precision and default rounding mode )
big_float sub (const big_float & b, const big_float & c )
{
	return sub( b, c, big_float::prec, big_float::mode );
}

//multiplying ( with default precision and default rounding mode )
big_float mul( const big_float & b, const big_float & c )
{
	return mul(	b, c, big_float::prec, big_float::mode );
}

// division ( with default precision and default rounding mode )
big_float div ( const big_float &b, const big_float & c )
{
	return div (b, c, big_float::prec, big_float::mode );
}

//adding ( with default rounding mode )
big_float add(const big_float & b, const big_float & c, long prec)
{
	return add (b, c, prec, big_float::mode );
}

//subtraction ( with default rounding mode )
big_float sub(const big_float & b, const big_float & c, long prec)
{
	return sub(b,c,prec,big_float::mode);
}

//multiplying ( with default rounding mode )
big_float mul(const big_float & b, const big_float & c, long prec)
{
	return mul(b,c,prec,big_float::mode);
}

//division ( with default rounding mode )
big_float div(const big_float & b, const big_float & c, long prec)
{
	return div(b,c,prec,big_float::mode);
}

//adding
big_float add ( const big_float & b, const big_float & c, long prec, int mode )
{

  CHECK_PREC(prec)//
  CHECK_MODE(mode)//������ ������, ��������
  big_int b_e(b.e), c_e(c.e), b_s(b.s), c_s(c.s);

  big_float temp;
  // some checks   
  if ( !c_s.length() )
  {
	temp = b;
	temp.normalize_1 ( prec, mode );
	return temp;
  }
  if ( !b_s.length() )
  {
	temp = c;
	temp.normalize_1 ( prec, mode );
	return temp;
  }
  
  long delta = b_s.length() - c_s.length();
  
  if ( delta > 0 )
  {
	c_s = c_s << delta;
	c_e = c_e - delta;
  }
  else 
  {
	b_s = b_s << -delta;
	b_e = b_e + delta;
  }
  if ( b_e < c_e )  
  { 
	  swap ( b_e, c_e );
	  swap ( b_s, c_s );
  }
     
  big_int ed = b_e - c_e;//���� ��� ���� ���������, ���� ���� ��� ���������
  
  if ( ed > prec  && mode != EXACT/*+1 */) // ����� ��������� ��� ��� b_e - c_e ����� ������� � mode == EXACT !!! 
	//  ������� ������ ������ ���� mode == TO_NAREST
  {
		temp.s = b_s;//���� mode=EXACT, �����, ������ ������, ���� �������� �� ������ ����
		temp.e = b_e;
		if ( mode != TO_NEAREST )
		{
			temp.s = ( temp.s << 1 ) + c_s.sign();
			temp.e = temp.e - 1;
		}
  }
  else
  {
	  if ( ed.length() > _Internal::bits_per_digit /* PREC_MAX - b_s.length()*/ ) //ed > PREC_MAX and mode == EXACT
	  		big_float_fatal_error( "can't perfom adding with EXACT rounding mode" ); 
	  
	  // WARNING! I have commented '/*.to_digit()*/' at the following
	  // source line because I think it's needless. (Sergey Lyalin)
	  b_s = b_s << ed/*.to_digit ()*/; //����� �������� ��������, ���� mode == EXCACT �  b_e - c_e ����� �������
	   
	   temp.s = c_s + b_s;
	   temp.e = c_e;
  }
  temp.normalize_1 ( prec, mode );
  return temp;
}

//subtraction
big_float sub(const big_float & b, const big_float & c, long prec, int mode)
{
 big_float temp(c);
 temp.s = -temp.s;
 temp = add ( b, temp, prec, mode);
 return temp;
}

//myltiplying
big_float mul( const big_float & b, const big_float & c, long prec, int mode )
{
  CHECK_PREC(prec)//
  CHECK_MODE(mode)//������ ������, ��������
  big_float temp;
  temp.s = b.get_significant() * c.get_significant();
  temp.e = b.get_exponent() + c.get_exponent();
  temp.normalize_1 ( prec, mode );
  return temp;
}

//��������� �������
/*big_float div(const big_float & b, const big_float & c, long prec, int mode)
{
  //������ 2 �����, ���� �������� b/c � ��������� prec
  if (c.s==0) return big_float();//���� !!!!!!!!!!!!!!!������������� � ������ ������
  big_float x,y,z;
	x.s=1;
        int q=get_number_of_digits(c.s);
        int i=0;
	x.e=-c.e-q; //x.e=x.e-q;
        normalize(prec,mode,x.s,x.e);
        y=x;
        normalize(prec,mode,y.s,y.e);
        z=y-x;
        normalize(prec,mode,z.s,z.e);
        //������� ������� 1/c
        std::cout<<(-c.e-q)<<"\n"<<x<<"\t\t"<<y<<"\n";
        long p=prec;
        while (/*(z.e>(-p-2-b.e-get_number_of_digits(b.s))&&(i<100))//)
	{
                i++;
		y=x;
                x=2*y-c*y*y;
                z=x-y;
                std::cout<<"x="<<x<<"\t\t"<<"y="<<y<<"\t\t";
                std::cout<<"z.e="<<z.e<<std::endl;
                //prec=prec*2;
                //getch();
        }
        prec=p;
        if (get_sign(x.s)!=get_sign(c.s)) x=-x;
        z=b*x; normalize(prec,mode,z.s,z.e);
	return (z);
} */
//division
big_float div ( const big_float & b, const big_float & c, long prec, int mode)
{
  //std::cout << "1: " << b << "\t 2: " << c << "  prec" << prec << std::endl; 
  if ( c.s==0 ) return big_float();//���� !!!!!!!!!!!!!!!������������� � ������ ������
  big_float x;
  big_int temp = pow2<big_int> ( prec << 1 );
  
  //std::cout << "temp = " << temp << std::endl;
  //for ( long i=0; i<prec; i++, temp=temp*(max_digit+1),temp=temp*(max_digit+1));
  //std::cout << "c.s = " << c.s << std::endl;
  x.s = temp / c.s;
  x.e = -c.e - prec - prec;
  //x.out( std::cout, 'd');
  x.normalize_1 (prec,mode );
  //std::cout << "  / : "<< x * b << std::endl;
  return mul( x, b, prec, mode );
}
big_float divnu ( const big_float & b, const big_float & c, long prec, int mode)
{
	//������� ������� 1/�, � ����� ������� �� b
	//��� �����, ����� �������� ���������� ���� ������� � ������ ���� ����� 1/2 � 1
	short k = 0;
	big_float x;
	big_float temp = 1;
	temp.out ( std::cout, 'd');
	x.s = c.s;
	while ( x.s.length() % _Internal::bits_per_digit > 0 ) 
	{
		x.s = x.s << 1;
		k++;
	}
	x.e = -( int )x.s.length();// / bits_per_digit;
	for ( int i=0; i < prec + 1; i++ )
	{
		temp = mul (2,temp,prec,mode) - mul ( mul ( temp,temp,prec,mode ),x,prec,mode );
	}
	for (int i = 0; i < k; i++)
	{
		temp = temp * 2;
	}
	temp.e = temp.e + x.e - c.e;
	temp = mul ( b, temp, prec, mode );
	return temp;
}

big_float div_i ( const big_int & c )
{
	std::size_t l  = c.length();

	std::size_t step = 1;
	big_float res;
		
	res.s = 1;
	
	for ( step = 1 ; step < 32; step <<= 1 )
	{
		res.s = res.s * ( pow2<big_int> ( l * step + 1  ) - c * res.s ); 
	}
	//res.e =- l * ( step );
	std::cout << 10000 * res.s / pow2<big_int> ( 500)<< std::endl;
	//std::cout << res.s << std::endl << res.e << std::endl;
	return res;
}


/*std::ostream & operator << (std::ostream & s, const big_float & x)//������� ������
{
 big_int temp=1;
 big_int i=0;

 if ( x.get_exponent() >= 0 )//���� ����� �����, �� � ������� ��� �����
 {
  for( ; i < x.get_exponent () ; i = i + 1, temp = temp >>  bits_per_digit);
  s << ( x.get_significant( ) * temp ) << std::endl;
 }
 else//������� ���������
 {
  big_int num,denum=1;
  num=x.get_significant()*get_sign(x.s);
  for(i=0;i<-x.get_exponent();i=i+1,denum=denum*(max_digit+1));
  temp=num/denum;
  if(x.get_significant()<0) std::cout<<'-';
  s<<temp<<',';
  num=(num-temp*denum)*10;
  for(i=0;i<PREC;i=i+1)
  {
   temp=num/denum;
   s << temp;
   num=(num-temp*denum)*10;

  }
 }
 return s;
}*/

/*
* stream operators 
*/
std::istream & operator >> ( std::istream &is , big_float &fnum )
{
	char simbol;
	big_int dm, de, bm,be;
	long add = 0;
	
	std::stringstream bufferm; //integer part of mantissa
	std::stringstream buffere; //exponenta
		
	do 
	{
		is.get( simbol );
	} while ( isspace ( simbol ) );
	
	if ( simbol == '-') // signum may be 
	{
		bufferm << simbol;
		is.get ( simbol );
	}

	if ( isdigit ( simbol ) ) // mantissa
	{
		bufferm << simbol;
		is.get ( simbol );
		while ( isdigit ( simbol ) )
		{
			bufferm << simbol;
			is.get ( simbol );
		}
	}
	
	if ( simbol == '.')//decimal point
	{
		simbol = is.get ();
		while ( isdigit (simbol) )
		{
			bufferm << simbol;
			simbol = is.get ();
			add++;
		}
	}
	
	if ( simbol == 'e' || simbol == 'E')//exponenta
	{
		is.get ( simbol );
	    if ( simbol == '-') // signum may be 
		{
				buffere << simbol;
				is.get ( simbol );
		}
		while ( isdigit (simbol) )
		{
			buffere << simbol;
			is.get ( simbol );
		}
	}
	
	// WARNING! I have replaced code at the following source region:
	// '!bufferm.pcount()' --> 'bufferm.str().empty()'.
	// Note, the type of bufferm is also changed (see above).
	// Is it correct replacement? (Sergey Lyalin)

	if ( /*!bufferm.pcount()*/bufferm.str().empty() ) //check "-" //don't forget
	{
		fnum = big_float ();//zero 
	}
	else 
	{
		bufferm >> dm;
		if ( /*buffere.pcount ()*/bufferm.str().empty() )
			buffere >> de;
		de = de - add;
		do_bin_convert (dm, de, big_float :: prec /*- 1 bits_per_digit - 1*/, bm, be);
		//if ( be.get_sign() != -1 )
		//{
		//	bm = bm << (be - (be / bits_per_digit) * bits_per_digit); 
		//	be =  be  / bits_per_digit;
		//}
		//else 
		//{
		//	bm = bm << bits_per_digit + be - (be / bits_per_digit) * bits_per_digit; 
		//	be = be / bits_per_digit - 1;
		//}
	    	//std::cout << "bm = " << bm.length() << "    be = "  << be.length() << std::endl; 
		fnum = big_float ( bm, be );
		//std::cout << fnum.get_significant()<< std::endl;
		//std::cout << fnum.get_exponent()<< std::endl;
	}
	
	is.putback ( simbol );
	return is;
}

std::ostream & operator << ( std::ostream &os , const big_float &fnum )
{
	long flags = os.flags( );

	if ( flags & std::ios::scientific )
		fnum.out ( os, 'e' );
	else if ( flags & std::ios :: fixed )
		fnum.out ( os, 'f');
	else 
		printf ( "not implemented yet. Type \"std::cout.setf ( std::ios::scientific, std::ios::floatfield  )\" or \"std::cout.setf ( std::ios::fixed, std::ios::floatfield )\" in your program" );
	return os;
}

///input number  
void big_float :: in ( std::istream & ins, char c )
{
	switch  ( c )
	{
		case 'f': 
			ins >> *this;
			break;		
		case 'd':
			ins >> s >> e;
			normalize_1 ();
			break;
		default:
			big_float_warning ( "unrecognized input format: " );
			std::cerr << c << '\n';
			ins >> *this;
	}//switch ( c )
}

void big_float :: out ( std::ostream & os, char c  ) const 
{
	using namespace _Internal;
	
	if ( !s.sign() ) 
	{
		os << "0.0";
		return;
	}
	std::stringstream str;
	long prev_flags = 0;
	big_int de, dm;
	digit *bdn, *numberdata;
	std::size_t chars_per_block;
	std::size_t bdnlen;
	int  position;//decimal point position 
	char *cfd; // for first number 

	if ( os.precision() > D_PREC_MAX )
		os.precision( D_PREC_MAX ); 
	switch ( c )
	{
		case 'f': //floating point mode
				prev_flags = os.flags ( );
				//digit bdn_radix;
				chars_per_block = 4; // fix me 
				//calc_bdn_radix( 10, bdn_radix, chars_per_block);
				
				cfd = ( char * ) malloc ( (chars_per_block + 1) * sizeof ( char )  );
				if ( !cfd  ) 
				{
					std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
					exit ( 1 );
				}
				do_dec_convert ( dm, de, os.precision(), s, e );
				//fix me - now necessary check de to max precision
				//
				//std::cout << "dm =" << dm << "de = " << de << std::endl; 
				if ( de.number->len  > 1 )
					big_float_fatal_error( "can't perfom output in fixed mode" ); 

				// WARNING! Why was doubledigit used? I've changed. (Sergey Lyalin)
				if ( de.sign() )
					position = os.precision() + /*de.sign() **/ /*doubledigit*/(de) + 1;//number->data[ 0 ] + 1;
				else position = os.precision() + 1;
				if (de.sign() >= 0 || de <= os.precision()/*!(de.sign() < 0 && de.number->data [ 0 ] > os.precision ())*/)
				{
					if ( de.sign() )
					{
						position = os.precision() + de.sign() * de.number->data[ 0 ] + 1;
						do_dec_convert ( dm, de, 2 * os.precision() + de.sign() * de.number->data [ 0 ], s, e);
					}
					else 
					{
						position = os.precision() + 1;
						do_dec_convert ( dm, de, 2 * os.precision(),s, e);
					}
						//std::cout << "dm =" << dm << "de = " << de << std::endl; 
					//std::cout << "position " << position << std::endl;
				}
				 
				//std::cout << "position " << position << std::endl;
				//std::cout	 << "dm =" << dm << "de = " << de << std::endl; 
				if ( !dm.sign() )//?
					os << "0";
				//de = de + os.precision();  
				//std::cout << de << std::endl;
				os.setf ( std::ios :: dec, std::ios :: basefield );
				if ( position <= 0 )
				{
					if ( dm.sign() == -1 )
					{
						os << '-';
						dm.number->sign = 1;
					}
					os<<"0.";
					if ( position + os.precision() <=0 )
					{
						os.width ( os.precision () ); 
						os.fill ( '0' );
						os << 0;
					}
					else 
					{
						if ( position )
						{
							os.width ( -position );
							os.fill ( '0' );
							os << 0;
						}
						str << dm;

						//char *cptr;
						//cptr = str.str().c_str();
						//cptr [ position + os.precision () ] = '\0';
						//os << cptr;

						os << str.str().substr(0, position + os.precision());
					}
				}
//				else if (0 && position > os.precision() )
//				{
//					os << dm; 
//					if ( position - os.precision () - 1  )
//					{
//						os.width ( position - os.precision () - 1  );
//						os << 0;
//					}
//					os << '.';
//					os.width ( os.precision() );
//					os << 0;
//				}
				else 
				{
					bdnlen = dm.number->len;
					bdn = ( digit * ) malloc ( 2 * bdnlen * sizeof ( digit ) );
					if (!bdn)
					{
						std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
						exit ( 1 );
					}
					
					numberdata = ( digit * ) malloc ( dm.number->len * sizeof ( digit ) );
					if ( !numberdata )
					{
						std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
						exit ( 1 );
					}

					memmove ( numberdata, dm.number->data, dm.number->len* sizeof(digit) );
					bdnlen = do_big_int_to_bdn ( numberdata, bdn, dm.number->len, 10000);
					if ( numberdata ) free (numberdata);

					if (dm.number->sign == -1)
						os << '-';
					std::size_t dig,l,point;
					//std::cout << std::endl << bdn [ bdnlen - 1 ] << std::endl;
					l = ( bdnlen - 1 ) * chars_per_block + lg10 ( bdn [ bdnlen - 1 ] ) + 1;
					//std::cout << "position = " << position << std::endl; 
					dig = ( position + chars_per_block - lg10 ( bdn [ bdnlen - 1] ) - 1 ) / chars_per_block + 1; 
					//std::cout << "dig = " << dig;
					point = ( position + chars_per_block - lg10 ( bdn [ bdnlen - 1 ] ) - 1 ) % chars_per_block; 
					//std::cout << "lg = "<<( bdn [ bdnlen - 1 ] ) << std::endl;
					//std::cout << "point = " << point << std::endl;
					if ( dig - 1 )
					{
						os << bdn [ bdnlen - 1 ];
					}
					for ( std::size_t counter = 2; counter < dig; counter++ )
					{
						os.width( chars_per_block );
						os.fill('0');
						os << bdn [bdnlen - counter ];
					}
					if ( point ) 
					{
						ltoa ( bdn [ bdnlen - dig ], cfd, 10 );
						if ( dig - 1 )
						{
							os.width ( chars_per_block - strlen ( cfd )  );
							os.fill ( '0' );
						}
						else 
							os.width ( 0 );
						os << cfd [ 0 ];
						os.width ( 0 );
						point -= ( chars_per_block - strlen ( cfd ) ) % chars_per_block; 
						for ( std::size_t i = 1; i < point; i++ )
							os << cfd [ i ];
						os << '.';
						os << &cfd [ point ];
					}
					else 
					{
						if ( dig - 1 )
						{
							os.width( chars_per_block );
							os.fill('0');
						}
						os << bdn [ bdnlen -dig ];
						os << '.';
					}
					for ( std::size_t counter = dig + 1; counter <= bdnlen; counter++ )
					{
						os.width( chars_per_block );
						os.fill('0');
						os << bdn [bdnlen - counter ];
					}
					if ( bdn ) free ( bdn );
				}
				os.setf ( prev_flags );
				break;
		case 'e':// exponential mode  
				prev_flags = os.flags ( );
				//digit bdn_radix;
				chars_per_block = 4; // fix me 
				//calc_bdn_radix( 10, bdn_radix, chars_per_block);
				
				cfd = ( char * ) malloc ( (chars_per_block + 1) * sizeof ( char )  );
				if ( !cfd  ) 
				{
					std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
					exit ( 1 );
				}
				do_dec_convert ( dm, de, os.precision(), s, e );
				//std::cout << "dm =" << dm << "de = " << de << std::endl; 

				/* operator << for big_int with little modification */
				if ( !dm.sign() )
					os << "0";
				de = de + os.precision();  
				os.setf ( std::ios :: dec, std::ios :: basefield );
	
				bdnlen = dm.number->len;
				bdn = ( digit *) malloc ( 2 * bdnlen * sizeof ( digit ) );
				if (!bdn)
				{
					std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
					exit ( 1 );
				}
				
				numberdata = ( digit * ) malloc ( dm.number->len * sizeof ( digit ) );
				if ( !numberdata )
				{
					std::cerr << "Big arith fatal error: \n " << "the heap overflow" << "\n";
					exit ( 1 );
				}

				memmove ( numberdata, dm.number->data, dm.number->len* sizeof(digit) );
				bdnlen = do_big_int_to_bdn ( numberdata, bdn, dm.number->len, 10000);
				if ( numberdata ) free (numberdata);

				if (dm.sign() == -1)
					os << '-';
				ltoa  ( bdn [ bdnlen - 1 ], cfd, 10 );    
				os << cfd [ 0 ] << '.' << &cfd [ 1 ]; 
	
				for (std::size_t i = bdnlen - 1; i > 0; i--)
				{
					os.width( chars_per_block );
					os.fill('0');
					os << bdn[i - 1];
				}
				if ( bdn ) free ( bdn );
  
				os << 'e' << de; //fix me - see std::ios::uppercase
				os.setf ( prev_flags );
		break; // exponential mode 
		case 'b'://binary ( zero and one ). out significant and exponent separately 
			if ( s.sign() == -1 )
				os << '-';//fix_me see std::ios::showpos
			for ( int counter = s.length () - 1; counter >= 0 ; counter-- )
				os << s [ counter ]; 

			os << '\t';

			if ( e.sign() == -1 )
				os << '-';//fix_me see std::ios::showpos
			for ( int counter = e.length () - 1; counter >= 0 ; counter-- )
				os << e [ counter ]; 
			break;
		case 'd': // out significant and exponent separately, in decimal mode   
			prev_flags = os.setf( std::ios :: dec, std::ios :: basefield );
			os << s << '\t' << e;
			os.setf ( prev_flags );
			break;
		case 'h': // out significant and exponent separately, in hex mode 
			prev_flags = std::cout.setf( std::ios :: hex, std::ios :: basefield );
			os << s << '\t' << e;
			os.setf ( prev_flags );
			break;
		case 'o': // out significant and exponent separately, in oct mode 
			prev_flags = std::cout.setf( std::ios :: oct, std::ios :: basefield );
			os << s << '\t' << e;
			os.setf ( prev_flags );
			break;
		default:
			std::cerr << "Warning unrecognized output format:" << c << std::endl;
			prev_flags = os.setf( std::ios :: dec, std::ios :: basefield );
			os << s << '\t' << e;
			std::cout.setf ( prev_flags );
	}
	
}
///returns a floating-point value representing the smallest integer that is greater than or equal to a
big_float ceil  (const big_float & a)
{
	big_float res ( a );
	big_int e = a.e;
	big_int temp;

	if ( e >=  0 )
		return res;
	if ( e <= -big_int(a.s.length()) ) 
	{
		if ( a.s > 0 )
			return 1.0;
		else return 0.0;
	}
	temp = ( res.s >> e/*.to_digit()*/) << e/*.to_digit()*/ ;
	if ( res.s != temp && res.s > 0 ) 
		res.s = temp + pow2<big_int>( e/*.to_digit ()*/ );  
	else res.s = temp;
	return res;
}

/// returns a floating-point value representing the largest integer that is less than or equal to a
big_float floor (const big_float & a)
{
	big_float res ( a );
	big_int e = a.e;
	big_int temp;

	if ( e >=  0 )
		return res;
	if ( e <= -big_int(a.s.length()) ) 
	{
		if ( a.s > 0 )
			return 1.0;
		else return 0.0;
	}
	temp = ( res.s >> e/*.to_digit()*/) << e/*.to_digit()*/ ;
	if ( res.s != temp && res.s < 0 ) 
		res.s = temp - pow2<big_int>( e/*.to_digit()*/ );  
	else res.s = temp;
	return res;

}

/// Returns the fractal part of the number
big_float frac  (const big_float & a)
{
	if ( a.e >= 0 )
		return 0.0;
	
	big_float res ( a );
	if ( res.e <= - big_int(res.s.length()) )
		return res;
	
	res.s = res.s - ((res.s >> res.e/*.to_digit()*/) << res.e/*.to_digit()*/);
	return res;
}

/// returns an big-integer value representing the smallest integer that is greater than or equal to a
big_int iceil (const big_float & a)
{
	std::size_t l = a.s.length();
	if ( !l ) return l;
	
	big_int temp ( a.s );
	if ( a.e > 0 )
	{
		if ( a.e + a.s.length() > SHRT_MAX/*??*/  )
			big_float_fatal_error ( "Can't convert from big_float to big_int ( exponent too large )..." );
		return a.s <<a.e/*.to_digit()*/;	
	}
	if ( a.e <= -big_int(a.s.length()) )
		return ( a.s > 0 ) ? 1 : 0;
	temp = temp >> a.e/*.to_digit()*/;
	if ( temp << a.e/*.to_digit()*/ != a.s && temp > 0)
		return temp + 1;  
	return temp;
}

/// returns a big-integer  value representing the largest integer that is less than or equal to a
big_int ifloor(const big_float & a)
{
	std::size_t l = a.s.length();
	if ( !l ) return l;
	
	big_int temp ( a.s );
	if ( a.e > 0 )
	{
		if ( a.e + a.s.length() > SHRT_MAX/*??*/  )
			big_float_fatal_error ( "Can't convert from big_float to big_int ( exponent too large )..." );
		return a.s <<a.e/*.to_digit()*/;	
	}
	if ( a.e <= -big_int(a.s.length()) )
			return ( a.s > 0 ) ? 0 : -1;
	temp = temp >> a.e/*.to_digit()*/;
	if ( temp << a.e/*.to_digit()*/ != a.s && temp > 0)
		return temp;  
	return temp - 1;
}
///sqrt 
big_float fsqrt( const big_float & b )
{
	return fsqrt( b, big_float :: prec, big_float :: mode);
}

//user must call fsqrt( const big_float & b ) function instead two forward
//functions ( because EXACT mode not supported yet )  
big_float fsqrt(const big_float & bf, long prec)
{
	return fsqrt( bf, prec, big_float :: mode);
}

big_float fsqrt(const big_float & bf, long prec, int mode)
{
	big_float res ( bf );
	int l;

	if ( res.e [ 0 ] )
	{	
		res.s = res.s << 1;
		res.e = res.e - 1;
	}
	
	l = (res.s.length() - 2 * prec - 1);
	l = (l / 2) * 2;

	if ( l > 0 )
	{	
		res.s = res.s >> l;
		res.e = res.e + l;
	}
	else 
	{
		res.s = res.s << (-l) + 2;
		res.e = res.e + l - 2;
	}
	res.s = sqrt ( res.s );
	res.e = res.e >> 1;
	res.normalize_1 ( prec, mode );//error may be if mode == TO_INF
	
	return res;
}
//Newton fsqrt
big_float nfsqrt ( const big_float & bf, long prec, int mode )
{
	big_float res;
	//std::cout << bf << std::endl;
	res.e = ((( bf.get_exponent() ) + bf.get_significant().length() - 1) >> 1) + 1;
	res.s = 1;
	//res.normalize_1();
	std::cout << "x0 "<<res << std::endl; 
	//res.out ( std::cout, 'd' ) ;
	//std::cout << std::endl;
	std::size_t n = log ( (long double)prec + 1 ) / log ( 2.0l ) + 1;
	
	for ( std::size_t counter = 1; counter <= 2 * n; counter ++ )
	{
		std::cout << div( bf, res, counter * 2, EXACT ) << std::endl;
		res = add ( res,  div( bf, res, counter * 2, EXACT ), counter * 2, TO_NEAREST );  
		std::cout << res << std::endl;
		res.e = res.e - 1;
		std::cout << counter << " iter \t";
		std::cout << res << std::endl;
		//res.out( std::cout, 'd' );
		//std::cout << std::endl;
	}
	res.normalize_1 ( prec, mode );//error may be if mode == TO_INF
	
	return res;
}
//Random numbers 
big_float frandom  ( long prec )
{
	CHECK_PREC(prec)//
	return big_float ( /*random_number1*/big_int::random_with_length_or_less( prec ), -prec );
}
//Random numbers 
big_float frandom  ( )
{
	return big_float ( /*random_number1*/big_int::random_with_length_or_less( big_float::prec ), -big_float::prec );
}

big_float frandom1 ( long bits, const big_int & exp)
{
    CHECK_PREC(bits)//
  	return big_float ( /*random_number1*/ big_int::random_with_length_or_less( bits ) + pow2<big_int>( bits - 1 ) , exp );
}

/*not used now*/
int big_float::is_NaN( )
{
  return 0;
}     
int big_float::is_Zero( )
{
 return ( s==0 );
}

int big_float::is_pZero( )
{
 return ( ( s ==0 ) && (get_sign( s ) == 1) );
}

int big_float::is_mZero()
{
 return ((s==0)&&(get_sign(s)==-1));
}

int big_float::is_Special()
{
  return ((is_NaN())||(is_Inf())||(is_Zero()));
}     
   

int big_float::is_Inf()
{
  return 0;
}

long big_float::prec; //bits precision 
long big_float::mode; //rounding mode


}

//#endif