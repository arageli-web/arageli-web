/*****************************************************************************
	
	misc.hpp -- miscellaneous features

	This file is part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2005
	Copyright (C) Sergey S. Lyalin, 2005
	Copyright (C) University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

/** \file

	Miscellaneous features, routines, classes etc.
*/


#ifndef _ARAGELI_misc_hpp_
#define _ARAGELI_misc_hpp_

#include "config.hpp"


namespace Arageli
{


/// Makes and returns a temporary copy of the argument.
/**	This function is useful to dealing with our container-liked
	structures when an element of structure is used in operation
	with whole its owner.  For example, such operations are
	the dividing a row of a matrix by the element in that row,
	the dividing a polynomial by the leading coefficient and so on. */
template <typename T>
T safe_reference (const T& x) { return x; }


template <typename T1, typename T2, typename Outiter>
void generate_range_helper (T1& t1, const T2& t2, Outiter outiter)
{
	//std::cerr << "\nt1 = " << t1 << ", t2 = " << t2 << ":\n\t";

	if(t1 < t2)
		for(; t1 != t2; ++t1/*, std::cerr << t1 << "  "*/)
			*outiter++ = t1;
	else
		for(; t1 != t2; --t1/*, std::cerr << t1 << "  "*/)
			*outiter++ = t1;

	*outiter = t1;
}


template <typename T1, typename T2, typename T3, typename Outiter>
void generate_range_helper (T1& t1, const T2& t2, const T3& t3, Outiter outiter)
{
	for(; t1 != t3; t1 += t2, ++outiter)
		*outiter = t1;

	*outiter = t1;
}


} // namespace Arageli



//#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
//	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_MISC
//	#include "misc.cpp"
//	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_MISC
//#endif


#endif  //  #ifndef _ARAGELI_misc_hpp_
