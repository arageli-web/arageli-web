/*****************************************************************************
	
	arageli.hpp -- root header file for the Arageli library.
	
	Common information and others.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2005
	Copyright (C) University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

#ifndef _ARAGELI_arageli_hpp_
#define _ARAGELI_arageli_hpp_

/** \file Root header file of the Arageli.
	
	This file contain includes for all public headers of the library.

*/

/**

\mainpage

This is a documentation for library
<a href="http://www.unn.ru/cs/arageli">Arageli</a>
written by <a href="http://www.uic.nnov.ru/~zny"> N.Yu.Zolotykh </a>.

Arageli is the C++ library and the package of programs for computations in arithmetic,
algebra, geometry, linear and integer linear programming.  Arageli is a library for
dealing with precise, i.e. symbolic or algebraic, computations.  It contains a definition
to model basic algebraic structures such as integer numbers with arbitrary precision,
rational numbers, vectors, matrices, polynomials etc.  Arageli is written in C++ and
use power and expressiveness of the language.

Version of bigarith module for Win32 is written by
<a href="http://www-cse.ucsd.edu/users/maxal/"> Max Alekseyev </a>.
Some parts of bigarith module are written by 
<a href="mailto:pieslice@mail.nnov.ru">E.A.Agafonov</a>.
Interface reengineering, some features adding and sparse polynomial
implementation by <a href="mailto:sergey.lyalin@gmail.com">Sergey S. Lyalin</a>.
Dense polynom implementaion, test system development by
<a href="mailto:soav@yandex.ru">Andrey Somsikov</a>.

Arageli is a C++ library for computations in <b>AR</b>ithmetic,
<b>A</b>lgebra, <b>GE</b>ometry,
<b>L</b>inear and <b>I</b>nteger linear programming.

Copyright (C) 2000, 2002, 2005, 2006   Nikolai Yu. Zolotykh

Copyright (C) 2005, 2006 Sergey S. Lyalin

Copyright (C) 2005 Andrey Somsikov

Copyright (C) 200? E. A. Agafonov

This software is free. You can use, copy, and distribute this software and its
documentation for any purpose wihtout commercial profit with or without fee,
provided that the above
copyright notice appear in all copies and that both that copyright notice and
this permission notice appear in supporting documentation.

This software is provided "as is" without warranty.

Any comments and suggestions are welcome.

*/

// This file contains include directives for all general files of the library.
// Do not place here any other definitions.

#include "config.hpp"
#include "basefuncs.hpp"
#include "type_opers.hpp"
#include "type_traits.hpp"
#include "function_traits.hpp"
#include "type_pair_traits.hpp"
#include "misc.hpp"
#include "mixcomp.hpp"
#include "exception.hpp"
#include "factory.hpp"
#include "powerest.hpp"
#include "cmp.hpp"
#include "gcd.hpp"
#include "intalg.hpp"
#include "prime.hpp"
#include "functional.hpp"
#include "io.hpp"
#include "iomanip.hpp"
#include "gauss.hpp"
#include "big_int.hpp"
#include "residue.hpp"
#include "rational.hpp"
#include "vector.hpp"
#include "matrix.hpp"
#include "sparse_polynom.hpp"
//#include "polynom.hpp"
#include "random.hpp"
#include "simplex_method.hpp"
#include "motzkin_burger.hpp"
#include "skeleton.hpp"
#include "lll.hpp"
#include "ctrl_slog.hpp"
#include "texout.hpp"
#include "ctrl_latexlog.hpp"
#include "polyalg.hpp"
#include "resultant.hpp"
#include "sturm.hpp"
#include "interval.hpp"
#include "algebrslt.hpp"
#include "algebraic.hpp"
#include "big_float.hpp"
#include "big_const.hpp"
#include "logarithm.hpp"


#endif // #ifndef _ARAGELI_arageli_hpp_
