/*****************************************************************************
	
	vecalg.cpp -- See vecalh.hpp.

	This file is a part of Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2005--2006
	Copyright (C) Sergey S. Lyalin, 2005--2006
	Copyright (C) University of Nizhni Novgorod, Russia, 2005--2006

*****************************************************************************/

#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_VECALG)

#include "vecalg.hpp"


namespace Arageli
{


template <typename Out, typename Vec>
Out& vec_output_list
(
	Out& out,
	const Vec& x,
	const char* first_bracket,
	const char* second_bracket,
	const char* separator
)
{
	out << first_bracket;
	
	if(!x.is_empty())
	{
		out << x[0];
		
		typedef typename Vec::size_type size_type;
		for(size_type i = 1; i < x.size(); ++i)
			out << separator << x[i];
	}
	
	out << second_bracket;
	return out;
}


}

#else

#include "vecalg.hpp"


namespace Arageli
{

const char* vector_output_list_first_bracket_default = "(";
const char* vector_output_list_second_bracket_default = ")";
const char* vector_output_list_separator_default = ", ";
const char* vector_input_list_first_bracket_default = "(";
const char* vector_input_list_second_bracket_default = ")";
const char* vector_input_list_separator_default = ",";
const char* vector_input_list_range_default = ":";
const char* vector_output_aligned_left_col_default = "||";
const char* vector_output_aligned_right_col_default = "||";

}


#endif // #ifndef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
