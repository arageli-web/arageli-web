/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       hermite.hpp
//  Created:    2005/10/18    23:48
//
//  Author: Andrey Somsikov
*/

#ifndef __ARAGELI_hermite_hpp__
#define __ARAGELI_hermite_hpp__

#include "config.hpp"
#include "matrix.hpp"

namespace Arageli
{

template <class T>
matrix<T> hermite(const matrix<T> &m_);

} // namespace Arageli

#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite
	#include "hermite.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite
#endif

#endif /*__ARAGELI_hermite_hpp__*/
/* End of file hermite.hpp */
