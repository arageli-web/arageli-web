/*****************************************************************************
	
	type_traits.cpp -- File description see in type_traits.hpp.

	This file is part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2005--2006
	Copyright (C) Sergey S. Lyalin, 2005--2006
	Copyright (C) University of Nizhni Novgorod, Russia, 2005--2006

*****************************************************************************/

#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_TYPE_TRAITS)

#include "type_traits.hpp"


namespace Arageli
{

template <typename T>
const type_category::type
	type_traits_default<T>::category_value =
	category_type();

template <typename T>
const typename auto_type_category_by_numeric_limits<T>::value_type
	type_traits<T>::category_value = category_type();

template <typename T>
const type_category::complex
	type_traits<std::complex<T> >::category_value = type_category::complex();

template <typename Iter, typename Val>
const type_category::iterator
	type_traits_iterator<Iter, Val>::category_value =
		type_category::iterator();

template <typename Str, typename Char>
const type_category::string
	type_traits_string<Str, Char>::category_value =
		type_category::string();

template <typename Str>
const type_category::iostream
	type_traits_iostream<Str>::category_value =
		type_category::iostream();


} // namespace Arageli


#endif
