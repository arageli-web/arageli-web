/*****************************************************************************
	
	frwrddecl.hpp -- Some forward declaration.

	���� ���� �������� ������ ���������� Arageli.

	Copyright (C) Nikolai Yu. Zolotykh, 2005
	Copyright (C) Sergey S. Lyalin, 2005
	Copyright (C) University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

/** \file
	Forward declaration for some Arageli structures.
*/


#ifndef _ARAGELI_frwrddecl_hpp_
#define _ARAGELI_frwrddecl_hpp_

#include "config.hpp"


namespace Arageli
{

class big_int;
template <typename T> class rational;
template <typename T, bool REFCNT = true> class vector;
template <typename T, bool REFCNT = true> class matrix;
template <typename F, typename I = int> class monom;
template <typename F, typename I = int, bool REFCNT = true> class sparse_polynom;

template <typename Base, typename Index> class index_subvector;


} // namespace Arageli


#endif  //  #ifndef _ARAGELI_frwrddecl_hpp_
