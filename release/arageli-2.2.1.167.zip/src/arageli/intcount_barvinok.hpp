/*****************************************************************************
	
	intcount_barvinok.hpp -- The algorithm that counts all integer points
		in polytope.

	This file is a part of the Arageli library.

	An implementation of all algorithms in this file
	have been done by Ekaterina Schukina.
	
	An integration of the implemented algorithms
	into Arageli by Sergey Lyalin.

	Copyright (C) Ekaterina Schukina, 2006
	Copyright (C) Sergey S. Lyalin, 2006

*****************************************************************************/

/**
	\file
	This file contains declaration for the Barvinok algorithm for counting
	integer points in a polytope.  A polytop Ax >= b is represented as
	a matrix a = (-b|A). Current implementation works only for bodily polytopes.
*/

//TODO: This file needs to rewrite with new approaches. Polyhedrons, for example.

#ifndef _ARAGELI_intcount_barvinok_hpp_
#define _ARAGELI_intcount_barvinok_hpp_

#include "config.hpp"

#include "_utility.hpp"


namespace Arageli
{


namespace ctrl
{

class intcount_barvinok_idler {};	// Need to complete.

}


template <typename A, typename T, typename Ctrler>
void intcount_barvinok (const A& a, T& res, Ctrler ctrler);


template <typename A, typename T>
inline void intcount_barvinok (const A& a, T& res)
{ intcount_barvinok(a, res, ctrl::intcount_barvinok_idler()); }


template <typename A>
inline typename A::element_type intcount_barvinok (const A& a)
{
	typename A::element_type res;
	intcount_barvinok(a, res, crtl::intcount_barvinok_idler());
	return res;
}


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_INTCOUNT_BARVINOK
	#include "intcount_barvinok.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_INTCOUNT_BARVINOK
#endif

#endif
