/*****************************************************************************

	_utility.hpp -- an internal file with some powerfull services

*****************************************************************************/

#ifndef _ARAGELI__utility_hpp_
#define _ARAGELI__utility_hpp_

#include "config.hpp"

#include <iostream>
#include <algorithm>
#include <utility>

#include "type_opers.hpp"
#include "factory.hpp"
#include "std_import.hpp"
#include "interval.hpp"


namespace Arageli
{
	
template <typename T> struct cnc_value_type
{ typedef typename T::value_type type; };

template <typename T> struct cnc_value_type<const T>
{ typedef typename T::value_type const type; };


template <typename T> struct cnc_reference
{ typedef typename T::reference type; };

template <typename T> struct cnc_reference<const T>
{ typedef typename T::const_reference type; };


template <typename T> struct cnc_pointer
{ typedef typename T::pointer type; };

template <typename T> struct cnc_pointer<const T>
{ typedef typename T::const_pointer type; };


template <typename T> struct cnc_iterator
{ typedef typename T::iterator type; };

template <typename T> struct cnc_iterator<const T>
{ typedef typename T::const_iterator type; };


namespace _Internal
{

class Auto_stream_state
{
	std::ios_base& stream;
	std::ios_base::fmtflags oldflags;

public:

	Auto_stream_state
	(
		std::ios_base& stream_a,
		std::ios_base::fmtflags newflags
	)
	: stream(stream_a)
	{ oldflags = stream.flags(newflags); }

	~Auto_stream_state () { stream.flags(oldflags); }
};


// ���� � s ������� �����������, ���� ��� ���� ���������� false, ����� -- true.
bool is_not_contains_spaces (const char* s);


// �������� �������� �� in ������ s. ���� ������ ��������� �������, ��
// ������������ true, ����� -- false. �������� ��������� ������� ������������
// ������� � �����. �������� ������ ���������� (������� �� ������).
// ������ ������� ����������� ������������ ��� �� ������������ (������� ��
// ������), ���������� ������� ����������� �� ������������.
bool read_literal (std::istream& in, const char* s);


template <typename In, typename Str>
inline bool is_bad_read_literal (In& in, const Str& s)
{
	if(!read_literal(in, s))
	{
		in.clear(std::ios_base::badbit);
		return true;
	}

	return false;
}


// Checks stream's state and if it's not good, sets badbit as a state and returns true,
// otherwise returns false.
template <typename In>
inline bool is_bad_input (In& in)
{
	if(!in)
	{
		in.clear(std::ios_base::badbit);
		return true;
	}
	
	return false;
}


#ifdef ARAGELI_DISABLE_PARTICULAR_COMPILER_WARNINGS
	#pragma warning (push)
	#pragma warning (disable : 4800)
#endif


template <typename T> class auto_array
{
public:

	typedef T element_type; 

	explicit auto_array(T* p = 0) throw()
	: owner(p), pointer(p) {}

	auto_array(const auto_array<T>& q) throw()
	: owner(q.owner), pointer(q.release()) {}

	auto_array<T>& operator= (const auto_array<T>& q) throw()
	{
		if(this != &q)
		{
			if(pointer != q.get())
			{
				if (owner) 
				delete [] pointer;
				owner = q.owner; 
			}
			else if(q.owner)owner = true;
			
			pointer = q.release(); 
		}
		return *this; 
	}

	~auto_array () { if(owner) delete [] pointer; }

	T& operator* () const throw() { return *get(); }

	T* operator-> () const throw() { return get(); }

	T* get () const throw() { return pointer; }

	T* release () const throw() 
	{
		owner = false;
		return pointer; 
	}

private:

	mutable bool owner;

	T* pointer;
};


#ifdef ARAGELI_DISABLE_PARTICULAR_COMPILER_WARNINGS
	#pragma warning (pop)
#endif


template <typename A, typename B, typename Store_A, typename Store_B>
inline void swap_help_1 (A& a, B& b, Store_A& sa, Store_B& sb, true_type)
{ sa.swap(sb); }

template <typename A, typename B, typename Store_A, typename Store_B>
void swap_help_1 (A& a, B& b, Store_A& sa, Store_B& sb, false_type);


template <typename In_a, typename In_b>
int aggregate_cmp (In_a ai, In_a aend, In_b bi, In_b bend);


template <typename T>
std::reverse_iterator<T> make_reverse_iterator (const T& x)
{ return std::reverse_iterator<T>(x); }


template <typename R, typename T>
inline R noncopy_cast (const T& x) { return R(x); }

template <typename R>
inline const R& noncopy_cast (const R& x) { return x; }

template <typename R>
inline R& noncopy_cast (R& x) { return x; }

template <typename R, typename T>
inline R copy_cast (const T& x) { return noncopy_cast<R>(x); }


/// 2^p - 1 module. WARNING! TEMPORARY IMPLEMENTATION.
template <typename D = unsigned int, typename T = big_int>
class module_2pm1
{
public:	// WARNING!

	D degree_a;

public:
	
	module_2pm1 () : degree_a(0) {}

	module_2pm1 (const D& x) : degree_a(x)
	{  }

	operator T () const { return (unit<T>() << degree_a) - unit<T>(); }

};


template <typename D1, typename T1, typename D2, typename T2>
inline bool operator== (const module_2pm1<D1, T1>& a, const module_2pm1<D2, T2>& b)
{ return a.degree_a == b.degree_a; }

template <typename D1, typename T1, typename D2, typename T2>
inline bool operator!= (const module_2pm1<D1, T1>& a, const module_2pm1<D2, T2>& b)
{ return !(a == b); }

} // namespace _Internal

template <typename D1, typename T1>
inline bool is_null (const _Internal::module_2pm1<D1, T1>& a)
{ return is_null(a.degree_a); }

template <typename D1, typename T1>
inline bool is_unit (const _Internal::module_2pm1<D1, T1>& a)
{ return is_unit(a.degree_a); }


template <typename T1, typename D2, typename T2>
inline T1 prrem (T1 a, const _Internal::module_2pm1<D2, T2>& b)
{
	ARAGELI_DEBUG_EXEC_1(T1 _debug_result = prrem(a, T1(b)));
	
	T2 m2p = unit<T2>() << b.degree_a;
	T2 m2pm1 = m2p - unit<T2>();
	if(is_negative(a))a += m2pm1;

	//std::cout << "\nm2p = " << m2p;
	//std::cout << "\nm2pm1 = " << m2pm1;
	//std::cout << "\na = " << a;

	ARAGELI_ASSERT_0(!is_negative(a));

	if(a < m2pm1)return a;

	a -= m2pm1;

	if(a < m2pm1)return a;

	//std::cout << "\na = " << a;

	T1 q = a >> b.degree_a;
	++q;

	//std::cout << "\nq = " << q;

	ARAGELI_ASSERT_1(q < m2pm1);

	//std::cout << "\n(a & m2pm1) = " << (a & m2pm1);

	T1 r = (a & m2pm1) + q;

	//std::cout << "\nr = " << r;

	if(r < m2p)--r;
	else r -= m2p;

	ARAGELI_ASSERT_1(!is_negative(r));
	ARAGELI_ASSERT_1(r < m2pm1);
	//std::cout << "\n_debug_result = " << _debug_result;
	//std::cout << "\nr = " << r;
	ARAGELI_ASSERT_1(_debug_result == r);

	return r;
}


template <typename Out, typename D, typename T>
inline Out& operator<< (Out& out, const _Internal::module_2pm1<D, T>& x)
{
	out << "2^" << x.degree_a << "-1";
	return out;
}


template <typename In, typename D, typename T>
inline In& operator>> (In& in, _Internal::module_2pm1<D, T>& x)
{
	ARAGELI_ASSERT_ALWAYS(!"Ha-ha-ha:)!");
	return in;
}


} // namespace Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE__UTILITY
	#include "_utility.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE__UTILITY
#endif


#endif  //  #ifndef _ARAGELI__utility_hpp_
