/*****************************************************************************
	
	motzkin_burger.hpp -- Motzkin-Burger algorithm for double-description of
		a polyhedral cone.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2006
	Copyright (C) University of Nizhni Novgorod, Russia, 2005--2006

*****************************************************************************/

/**
	\file
	Motzkin-Burger algorithm for double-description of a polyhedral cone.
	The algorithm finds extreame rays and basis of cone Ax >= 0, where
	A is a matrix and x is a vector. Also the file contains an idle
	controller for this algorithm.

	Triangulation of polyhedral cone based on matrix Q that produced by
	Mothzkin-Burger algorithm. Also the file contains an idle controller
	for this algorithm.
*/

#ifndef _ARAGELI_motzkin_burger_hpp_
#define _ARAGELI_motzkin_burger_hpp_

#include "config.hpp"

#include <vector>


namespace Arageli
{

namespace ctrl
{

struct skeleton_motzkin_burger_idler
{
	class abort : public ctrl::abort {};

	template <typename A, typename F, typename Q, typename E>
	void preamble (const A& a, const F& f, const Q& q, const E& e) const {}

	void begin_gauss () const {}

	void end_gauss () const {}

	template <typename I>
	void find_non_zero (const I& i) const {}

	void zero_row () const {}

	template <typename I, typename J>
	void swap_cols_rows (const I& i, const J& j) const {}

	template <typename J>
	void eliminate_col (const J& j) const {}

	template <typename A, typename F, typename Q>
	void show_matrices (const A& a, const F& f, const Q& q) const {}

	void begin_motzkin () const {}

	void end_motzkin () const {}

	template <typename I1, typename I2>
	void select_col (const I1& current_column, const I2& new_column) const {}

	void zero_solution () const {}

	void corollary_inequality () const {}

	void begin_row_balancing () const {}

	template <typename I, typename J>
	void balanced_rows (const I& j_p, const J& j_m) const {}

	void end_row_balancing () const {}

	void delete_negates () const {}

	template <typename A, typename F, typename Q, typename E>
	void conclusion (const A& a, const F& f, const Q& q, const E& e) const {}
};

} // namespace ctrl


/// The Motzkin-Burger algorithm without modifications.
/** Finds extreme rays f and basis e of a cone ax >= 0
	returns also an incidence matrix q = f * transpose(a). */
template
<
	typename A, typename F,
	typename Q, typename E,
	typename Ctrler
>
void skeleton_motzkin_burger
(
	A& a, F& f, Q& q, E& e,
	Ctrler ctrler
);


/// The Motzkin-Burger algorithm without modifications.
/** Just calls full version of the function. */
template <typename A, typename F, typename Q, typename E>
inline void skeleton_motzkin_burger (A& a, F& f, Q& q, E& e)
{
	return skeleton_motzkin_burger
		(a, f, q, e, ctrl::skeleton_motzkin_burger_idler());
}


/// The Motzkin-Burger algorithm with selecting minimum elements.
/** Finds extreme rays f and basis e of a cone ax >= 0
	returns also an incidence matrix q = f * transpose(a). */
template
<
	typename A, typename F,
	typename Q, typename E,
	typename Ctrler
>
void skeleton_motzkin_burger_min
(
	A& a, F& f, Q& q, E& e,
	Ctrler ctrler
);


/// The Motzkin-Burger algorithm with selecting minimum elements.
/** Just calls full version of the function. */
template <typename A, typename F, typename Q, typename E>
inline void skeleton_motzkin_burger_min (A& a, F& f, Q& q, E& e)
{
	return skeleton_motzkin_burger_min
		(a, f, q, e, ctrl::skeleton_motzkin_burger_idler());
}


/// The Motzkin-Burger algorithm with selecting maximum elements.
/** Finds extreme rays f and basis e of a cone ax >= 0
	returns also an incidence matrix q = f * transpose(a). */
template
<
	typename A, typename F,
	typename Q, typename E,
	typename Ctrler
>
void skeleton_motzkin_burger_max
(
	A& a, F& f, Q& q, E& e,
	Ctrler ctrler
);


/// The Motzkin-Burger algorithm with selecting maximum elements.
/** Just calls full version of the function. */
template <typename A, typename F, typename Q, typename E>
inline void skeleton_motzkin_burger_max (A& a, F& f, Q& q, E& e)
{
	return skeleton_motzkin_burger_max
		(a, f, q, e, ctrl::skeleton_motzkin_burger_idler());
}

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

namespace ctrl
{

struct triangulate_motzkin_burger_idler
{
	class abort : public ctrl::abort {};

	template <typename Q>
	void preamble (const Q& q) const {}

	template <typename Row, typename Q>
	void select_vertex (const Row& row, const Q& q) const {}

	template <typename Row, typename Vs, typename Q>
	void select_vertex
	(const Row& row, const Vs& newvertices, const Q& q) const {}

	template <typename Row, typename Vs, typename Q>
	void finish_vertex
	(const Row& row, const Vs& vertices, const Q& q) const {}

	template <typename Col, typename Vs, typename Q>
	void select_col
	(const Col& col, const Vs& vertices, const Q& q) const {}

	template <typename Col, typename Vs, typename Q>
	void select_side
	(const Col& col, const Vs& newvertices, const Q& q) const {}

	template <typename Sm, typename Vs, typename Q, typename Tr>
	void new_simplex
	(
		const Sm& simplex, const Vs& vertices,
		const Q& q, const Tr& tr
	) const {}

	template <typename Q, typename Tr>
	void conclusion (const Q& q, const Tr& tr) const {}
};

} // namespace ctrl


/// Triangulates a polihedral cone with structure matrix q.
/** Triangulates a polihedral cone. q is matrix of the structure of a cone.
	In particular this matrix is obtained from Motzkin-Burger algorithm as
	q-matrix. Values itself in that matrix is not matter, only equality
	with zero is valuable. Output matrix tr contains d columns and several
	rows, number of which is equal to number of simpixes founded in
	the polihedral cone. Matrix tr contains indexes of vertexes that include
	in each simplex according to an order in q matrix.*/
template
<
	typename Q,	///< type for Q-matrix: matrix of the structure of a polihedral
	typename T,	///< type for matrix with triangulation numbers
	typename Ctrler
>
void triangulate_motzkin_burger (const Q& q, T& tr, Ctrler ctrler);


/// Triangulates a polihedral cone with structure matrix q.
/** See full version of this function. */
template
<
	typename Q,	///< type for Q-matrix: matrix of the structure of a polihedral
	typename T	///< type for matrix with triangulation numbers
>
inline void triangulate_motzkin_burger (const Q& q, T& tr)
{ return triangulate_motzkin_burger(q, tr, ctrl::triangulate_motzkin_burger_idler()); }


template
<
	typename A, typename F,
	typename Q, typename E
>
void integer_conv_motzkin_burger (A& a, F& f, Q& q, E& e);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_MOTZKIN_BURGER
	#include "motzkin_burger.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_MOTZKIN_BURGER
#endif

#endif
