#ifndef _ARAGELI_std_import_hpp_
#define _ARAGELI_std_import_hpp_

#include <cmath>
#include <algorithm>

namespace Arageli
{

#define ARAGELI_STD_IMPORT_1(NAME)	\
	template <typename T>			\
	inline T NAME (const T& x)		\
	{ return std::NAME(x); }

ARAGELI_STD_IMPORT_1(sin)
ARAGELI_STD_IMPORT_1(cos)
ARAGELI_STD_IMPORT_1(tan)
ARAGELI_STD_IMPORT_1(sinh)
ARAGELI_STD_IMPORT_1(cosh)
ARAGELI_STD_IMPORT_1(tanh)
ARAGELI_STD_IMPORT_1(asin)
ARAGELI_STD_IMPORT_1(acos)
ARAGELI_STD_IMPORT_1(atan)
ARAGELI_STD_IMPORT_1(abs)
ARAGELI_STD_IMPORT_1(exp)
ARAGELI_STD_IMPORT_1(floor)
ARAGELI_STD_IMPORT_1(ceil)
ARAGELI_STD_IMPORT_1(log)
ARAGELI_STD_IMPORT_1(log10)
ARAGELI_STD_IMPORT_1(sqrt)

template <typename T1, typename T2>
inline T1 pow (const T1& x, const T2& y)
{ return std::pow(x, y); }

template <typename T1, typename T2>
inline void swap (T1& x, T2& y)
{ return std::swap(x, y); }

}

#endif
