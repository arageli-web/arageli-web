#include <iostream>
#include <exception>


#include <arageli/exception.hpp>

//#include "test1.hpp"

namespace Arageli
{

	void test1 (std::ostream& report);
	int test2 ();	// see test2.cpp

}

int test3 ();	// see test3.cpp
int test4 ();	// see test4.cpp
int test5 ();	// see test5.cpp


using namespace std;


int main ()
{
	try
	{
		cout
			<< "The Arageli Library version " << ARAGELI_VERSION << "\n"
			<< "Copyright (C) Nikolay Yu. Zolotykh 1999 -- 2005\n";

		//Arageli::test1(cout);
		//Arageli::test2();
		//test3();
		test4();
		//test5();
	}
	catch(const bad_alloc& e)
	{
		cerr
			<< "\n\nException: Out of memory (std::bad_alloc)."
			<< "\n'what' message: " << e.what();
	}
	catch(const std::exception& e)
	{
		cerr
			<< "\n\nStandard C++ Exception (std::exception)."
			<< "\nSubtype of exception: " << typeid(e).name()
			<< "\n'what' message: " << e.what();
	}
	catch(const Arageli::exception& e)
	{
		cerr
			<< "\n\nArageli Exception (Arageli::exception)."
			<< "\nSubtype of exception: " << typeid(e).name()
			<< "\n'msg' message: " << e.msg();
	}
	//catch(...)
	//{
	//	cerr << "\n\nUnknown Exception.";
	//}
		
	cout << "\n\nPress Enter key for exit\n" << flush;
	
	{
		char tbuf[1000];
		cin.getline(tbuf, 999);
	}

	return 0;
}
