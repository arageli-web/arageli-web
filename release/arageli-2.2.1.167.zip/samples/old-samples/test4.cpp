#include <iostream>
#include <fstream>
#include <map>
#include <sstream>

#include <arageli/arageli.hpp>
#include <arageli/simplex_method.hpp>
#include <arageli/rand.hpp>
#include <arageli/ctrl_slog.hpp>
#include <arageli/ctrl_latexlog.hpp>
#include <arageli/residue.hpp>
#include <arageli/algebraic.hpp>

#include <arageli/big_float.hpp>
#include <arageli/intcount_barvinok.hpp>

#include "test1.hpp"


using namespace Arageli;
//using namespace std;
using namespace Arageli::simplex_method;
using namespace Arageli::ctrl;
using namespace Arageli::ctrl::simplex_method;
using Arageli::vector;

using std::ostream;
using std::cout;
using std::cin;
using std::ofstream;
using std::ifstream;
using std::cerr;
using std::endl;
using std::string;




struct the_second_test_Shevchenko_ctrl_idler
{
	template <typename A, typename B, typename C>
	void preamble (const A& a, const B& b, const C& c) const {}

	basis_artificial_idler ctrl_for_basis_artificial () const
	{ return basis_artificial_idler(); }

	primal_row_iters_idler ctrl_for_primal_row_iters () const
	{ return primal_row_iters_idler(); }

	template <typename T, typename X>
	void primal_opt (const T& res, const X& x_opt) const {}

	gomory1_iters_idler ctrl_for_primal_task_gomory1_iters () const
	{ return gomory1_iters_idler(); }

	gomory1_iters_idler ctrl_for_dual_task_gomory1_iters () const
	{ return gomory1_iters_idler(); }

	dual_col_iters_idler ctrl_for_dual_col_iters () const
	{ return dual_col_iters_idler(); }

	template <typename T, typename X>
	void primal_opt_int (const T& res, const X& x_opt_int) const {}

	template
	<
		typename Da, typename Db, typename Dc,
		typename T, typename Bsuba, typename Bsubc
	>
	void dual
	(
		const Da& da, const Db& db, const Dc& dc,
		const T& res_offset,
		const Bsuba& bsuba, const Bsubc& bsubc
	) const {}

	template <typename T, typename Y>
	void dual_y_opt (const T& res, const Y& y_opt) const {}

	template
	<
		typename Invbsuba, typename Bsubc,
		typename Y, typename U
	>
	void y_to_u_opt
	(
		const Invbsuba& invbsuba, const Bsubc& bsubc,
		const Y& y_opt, const U& u_opt
	) const {}

	template <typename T, typename Y>
	void dual_y_opt_int (const T& res, const Y& y_opt) const {}

	template
	<
		typename Invbsuba, typename Bsubc,
		typename Y, typename U
	>
	void y_to_u_opt_int
	(
		const Invbsuba& invbsuba, const Bsubc& bsubc,
		const Y& y_opt_int, const U& u_opt_int
	) const {}

};


// �������� ������ �������������� ��������� ����������������
// � ������������ � ��� ������� ������� � ���������� ������.
// ����������� �� �������� ������: � ������� b �� ������ ����
// ������������� ���������; � ������, � ������������ ������
// ������� ����� ������������� �������.
template
<
	typename T1, bool REFCNT1,
	typename T2, bool REFCNT2,
	typename T3, bool REFCNT3,
	typename Ctrler
>
void the_second_test_Shevchenko
(
	const matrix<T1, REFCNT1>& a,
	const vector<T2, REFCNT2>& b,
	const vector<T3, REFCNT3>& c,
	Ctrler ctrler
)
{
	typedef matrix<T1, false> Matrix;
	typedef vector<T1, false> Vector;
	typedef vector<size_t, false> Basis;
	
	ctrler.preamble(a, b, c);
	Matrix q;
	row_table_create(a, b, q);
	Basis basis;
	result_kind rk = basis_artificial
		(q, basis, ctrler.ctrl_for_basis_artificial());
	ARAGELI_ASSERT_0(rk == rk_found);
	
	//Matrix bsuba;
	//fill_submatrix_col(a, basis-1, bsuba);
	//fill_subvector(c, basis-1, bsubc);
	Basis first_basis = basis;	// ��������� �� �������

	// ������ ������ ������ ������ ���������� �������� �������.

	row_table_place_c(c, q);
	row_table_pivot_basis_c(q, basis);
	rk = primal_row_iters(q, basis, ctrler.ctrl_for_primal_row_iters());
	ARAGELI_ASSERT_0(rk == rk_found);

	Vector x_opt;
	row_table_extract_solution(q, basis, x_opt);
	ctrler.primal_opt(q(0, 0), x_opt);

	// ������� ������� ������ ������ � ����� ������.

	Matrix t;
	Basis nonbasis;
	row_to_col_table(q, basis, t, nonbasis);
	gomory1_iters
		(t, nonbasis, ctrler.ctrl_for_primal_task_gomory1_iters());
	Vector x_opt_int;
	col_table_extract_solution(t, a.ncols(), x_opt_int);
	ctrler.primal_opt_int(t(0, 0), x_opt_int);

	// ������ ������������ ������.

	Matrix bsuba, da;
	Vector bsubc, db, dc;
	T1 primal_res_offset;
	primal_to_dual_standard_discr
		(a, b, c, first_basis, da, db, dc, primal_res_offset, bsuba, bsubc);
	std::cout << "***** " << det(bsuba) << " *******";
	ctrler.dual(da, db, dc, primal_res_offset, bsuba, bsubc);

	// ������ ������������ ������ ���������� ������������ �������� �������.

	col_table_create_by_standard(da, db, dc, t, nonbasis);
	t(0, 0) = primal_res_offset;
	rk = dual_col_iters
		(t, nonbasis, ctrler.ctrl_for_dual_col_iters());
	ARAGELI_ASSERT_0(rk == rk_found);
	Vector y_opt;
	col_table_extract_solution(t, da.ncols(), y_opt);
	ctrler.dual_y_opt(-t(0, 0), y_opt);

	Matrix invbsuba = inverse(bsuba);
	Vector u_opt = (y_opt + bsubc)*inverse(bsuba);
	ctrler.y_to_u_opt(invbsuba, bsubc, y_opt, u_opt);

	// ������ ������������ ������ � ����� ������.

	gomory1_iters
		(t, nonbasis, ctrler.ctrl_for_dual_task_gomory1_iters());
	Vector y_opt_int;
	col_table_extract_solution(t, da.ncols(), y_opt_int);
	ctrler.dual_y_opt_int(-t(0, 0), y_opt_int);

	Vector u_opt_int = (y_opt_int + bsubc)*inverse(bsuba);
	ctrler.y_to_u_opt_int(invbsuba, bsubc, y_opt_int, u_opt_int);

	cout << "\n*****************************************\n";
	cout
		<< "\nOptimal point: " << x_opt
		<< "\nOptimal integer point: " << x_opt_int
		<< "\nOptimal point for dual: " << u_opt
		<< "\nOptimal integer point for dual: " << u_opt_int << '\n';
	cout << "\n*****************************************\n";
}


struct the_second_test_Shevchenko_ctrl_latexlog
{
	ostream& stream;

	the_second_test_Shevchenko_ctrl_latexlog(ostream& stream_a) : stream(stream_a) {}

	template <typename A, typename B, typename C>
	void preamble (const A& a, const B& b, const C& c) const
	{
		stream << "���� ������ ��������� ����������������:\n$$\\max cx$$\n"
			"$$\\left\\{ \\begin{tabular}{l}$Ax = b,$\\\\ $x \\ge 0,$ \\end{tabular}\\right.$$"
			"\n���\n";
		stream << "$$A = ";
		output_latex(stream, a, true);
		stream << ",$$\n$$b = ";
		output_latex(stream, b, true);
		stream << "^T,$$\n$$c = ";
		output_latex(stream, c, true);
		stream << ".$$\n��������� ������ ��� ������ ��� $x \\in R^{" << a.ncols()
			<< "}$ � ��� $x \\in Z^{" << a.ncols() << "}$."
			" ��������� ������������ � ����� "
			"������ ��� ���� ���� �������.\\par";
		stream << endl;
	}

	basis_artificial_latexlog<ostream> ctrl_for_basis_artificial () const
	{ return basis_artificial_latexlog<ostream>(stream, false, false); }

	primal_row_iters_latexlog<ostream> ctrl_for_primal_row_iters () const
	{ return primal_row_iters_latexlog<ostream>(stream, false, false); }

	template <typename T, typename X>
	void primal_opt (const T& res, const X& x_opt) const
	{
		stream
			<< "����, ����������� ������ ��� ������ ������ $x = " << x_opt
			<< "^T$, �������� ������� $" << res << "$.\n";
	}

	gomory1_iters_latexlog<ostream> ctrl_for_primal_task_gomory1_iters () const
	{ return gomory1_iters_latexlog<ostream>(stream, false, false); }

	gomory1_iters_latexlog<ostream> ctrl_for_dual_task_gomory1_iters () const
	{ return gomory1_iters_latexlog<ostream>(stream, false, false); }

	dual_col_iters_latexlog<ostream> ctrl_for_dual_col_iters () const
	{ return dual_col_iters_latexlog<ostream>(stream, false, false); }

	template <typename T, typename X>
	void primal_opt_int (const T& res, const X& x_opt_int) const
	{
		stream
			<< "����������� ������ ��� ������ ������ � ����� ������ $x = " << x_opt_int
			<< "^T$, �������� ������� $" << res << "$.\n";
	}

	template
	<
		typename Da, typename Db, typename Dc,
		typename T, typename Bsuba, typename Bsubc
	>
	void dual
	(
		const Da& da, const Db& db, const Dc& dc,
		const T& res_offset,
		const Bsuba& bsuba, const Bsubc& bsubc
	) const
	{
		stream
			<< "������������ ������:\n$$\\min ub$$\n"
			"$$uA \\ge c,$$\n";
		stream << "��� $u = (u_1";
        for(size_t i = 2; i <= db.size(); ++i)
			stream << ", u_{" << i << "}";
		stream << ")$. ��������� ������ ��� ������ ��� $u \\in R^{" << da.nrows()
			<< "}$ � ��� $x \\in Z^{" << da.nrows() << "}$."
			" ����� ���������� ������� $y = uB - c_B \\ge 0$, ���\n$$B = ";
		output_latex(stream, bsuba, true);
		stream << ",$$\n$$c_B = ";
		output_latex(stream, bsubc, true);
		stream << " $$ \n����� �������� ������������ ������ ����� ���������� � �����"
			" ���������� ���:\n$$\\min c'x$$\n"
			"$$\\left\\{ \\begin{tabular}{l}$A'y^T \\le b',$\\\\ $y \\ge 0,$ \\end{tabular}\\right.$$"
			"\n���\n";
		stream << "$$A' = ";
		output_latex(stream, da, true);
		stream << ",$$\n$$b' = ";
		output_latex(stream, db, true);
		stream << "^T,$$\n$$c' = ";
		output_latex(stream, dc, true);
		stream << "$$������� � ������� ������� $" << res_offset << "$. ���������"
			" ������ ���������� ������� ������ � ������������� ����.";
	}

	template <typename T, typename Y>
	void dual_y_opt (const T& res, const Y& y_opt) const
	{		
		stream
			<< "����� �������, ������ ����������� ������"
			" ��� ������������ ������ $y = " << y_opt
			<< "^T$, �������� ������� $" << res << "$.\n";
	}

	template
	<
		typename Invbsuba, typename Bsubc,
		typename Y, typename U
	>
	void y_to_u_opt
	(
		const Invbsuba& invbsuba, const Bsubc& bsubc,
		const Y& y_opt, const U& u_opt
	) const
	{
		stream <<
			"����������� �������� ������������ ���������� $u$:\n"
			"$$u = (y + c_B)B^{-1} = \\left(y + ";
		output_latex(stream, bsubc, true);
		stream << "^T\\right)";
		output_latex(stream, invbsuba, true);
		stream << " = ";
		output_latex(stream, u_opt, true, eep_alone, false);
		stream << "^T.$$\n";
	}

	template <typename T, typename Y>
	void dual_y_opt_int (const T& res, const Y& y_opt) const
	{
		stream
			<< "����� �������, ������ ����������� ������������� ������"
			" ��� ������������ ������ $y = " << y_opt
			<< "^T$, �������� ������� $" << res << "$.\n";
	}

	template
	<
		typename Invbsuba, typename Bsubc,
		typename Y, typename U
	>
	void y_to_u_opt_int
	(
		const Invbsuba& invbsuba, const Bsubc& bsubc,
		const Y& y_opt_int, const U& u_opt_int
	) const
	{
		stream <<
			"����������� �������� ������������ ���������� $u$:\n"
			"$$u = (y + c_B)B^{-1} = \\left(y + ";
		output_latex(stream, bsubc, true);
		stream << "^T\\right)";
		output_latex(stream, invbsuba, true);
		stream << " = ";
		output_latex(stream, u_opt_int, true, eep_alone, false);
		stream << "^T.$$\n";
	}

};


template <typename A, typename B, typename C>
void task_from_file (const char* filename, A& a, B& b, C& c)
{
	ifstream task(filename);
	
	if(!task)
	{
		cout << "\nERROR. Can't open file '" << filename << "'\n";
		exit(1);
	}
	
	task >> a >> b >> c;
}

template <typename A, typename B, typename C, typename Basis>
void task_basis_from_file (const char* filename, A& a, B& b, C& c, Basis& basis)
{
	ifstream task(filename);
	
	if(!task)
	{
		cout << "\nERROR. Can't open file '" << filename << "'\n";
		exit(1);
	}
	
	task >> a >> b >> c >> basis;
}


template <typename A, typename B, typename C>
void print_task (const A& a, const B& b, const C& c)
{
	output_aligned(cout << "\nA =\n", a);
	cout << "b = " << b << "\nc = " << c << '\n';
}


void test4_1 (const std::string& file_with_problem)
{
	ofstream out("the_second_test_Shevchenko2.output.tex");

	typedef rational<> T;
	matrix<T, false> a;
	vector<T, false> b, c;

	task_from_file(file_with_problem.c_str(), a, b, c);

	the_second_test_Shevchenko
		(a, b, c, the_second_test_Shevchenko_ctrl_latexlog(out));
}


template <typename A, typename AA, typename B, typename Det, typename Basis>
void partial_rref_int_order
(
	const A& a,
	AA& aa, B& b, Det& det,
	const Basis& basis
)
{
	AA q; Basis basis_out;
	rref_order(a, aa, q, basis, basis_out, det);
	aa *= std::abs(det);
	// B = *b|N
	b = aa;
	b.erase_cols(basis);
}


template <typename A1, typename A2>
void create_vector_order (const A1& a1, A2& a2, size_t n)
{
	a2 = a1;
	for(size_t i = 0; i < n; ++i)
		if(std::find(a1.begin(), a1.end(), i) == a1.end())
			a2.push_back(i);
}


void test4_2 ()
{
	// ���������� ��������� �������-������� ��� ������� ����� ������ ���.

	typedef big_int T;
	typedef matrix<T, false> Matrix;
	typedef vector<T, false> Vector;
	
	Matrix a;
	Vector b, c;

	task_from_file("../../../../samples/old-samples/Shevchenko_course-3_v-896.task.txt", a, b, c);
	print_task(a, b, c);

	Vector basis = "(1, 3, 4)";

	//a.swap_cols(2, 3);
		rational<> det;

	{
		Matrix ab = a;
		ab.insert_col(0, b);
		
		matrix<rational<> > newa, bn;
		partial_rref_int_order(matrix<rational<> >(ab), newa, bn, det, basis);
		a = bn;
		output_aligned(cout << "PARTIAL_RREFINT(b|A) = \n", newa);
		output_aligned(cout << "\nbn = \n", bn);
	}

	//Vector nonbasis;
	//basis_to_nonbasis(basis, nonbasis, 0, a.ncols());
	//cout << "\nbasis = " << basis << '\n';
	//Matrix bmat = a.take_cols(basis);
	//Matrix Bm1N = a;

	a.opposite();
	//a.insert_col(0, b+1);
	a.mult_col(0, -1);
	Matrix ba_orig = a;
	for(int i = 0; i < a.ncols(); ++i)
	{
		Vector v(a.ncols());
		v[i] = 1;
		a.insert_row(i/*a.nrows()*/, v);
	}


	output_aligned(cout << "\nA =\n", a);
	//output_aligned(cout << "\nB =\n", bmat);
	//cout << "\nnonbasis = " << nonbasis;

	Matrix f, q, e;
	skeleton(a, f, q, e, ctrl::make_skeleton_slog(std::cout, false));

	matrix<rational<> > ff = f;
	for(int i = 0; i < ff.nrows(); ++i)
		if(!is_null(ff(i, 0)))ff.div_row(i, safe_reference(ff(i, 0)));

	output_aligned(cout << "\nff = \n", ff);

	//ff.erase_col(0);
	matrix<rational<> > xbdelta = transpose(matrix<rational<> >(ba_orig)*transpose(ff));
	output_aligned(cout << "\nxbdelta = \n", xbdelta);
	matrix<rational<> > xb = xbdelta/std::abs(det);
	output_aligned(cout << "\nxb = \n", xb);

	matrix<rational<> > pre_x = xb;
	
	for(size_t i = 0; i < ff.ncols(); ++i)
		pre_x.insert_col(pre_x.ncols(), ff.copy_col(i));

	output_aligned(cout << "\nx preorder = \n", pre_x);
	matrix<rational<> > x;

	Vector order;
	create_vector_order(basis, order, pre_x.ncols());
	Vector invorder;
	vec_inverse_permutation(order, invorder);

	mat_col_copy_order(pre_x, x, invorder);
	x.erase_col(0);

	output_aligned(cout << "\nx =\n", x);

	std::cout << "\n******* TRIANGULATION *********\n";
	output_aligned(std::cout << "\nQ from Skeleton = \n", q);

	matrix<int> tr;
	triangulate_motzkin_burger(q, tr);

	output_aligned(cout << "\nsimplexes: \n", tr);

	//{
	//	typedef matrix<rational<> > MR;

	//	MR xN, v, q;

	//	xN = ff;
	//	xN.erase_col(0);

	//	MR xB = - MR(Bm1N)*transpose(xN);
	//	for(size_t i = 0; i < xB.nrows(); ++i)
	//		for(size_t j = 0; j < xB.ncols(); ++j)
	//			xB(i, j) += b[i];

	//	xB = transpose(xB);

	//	output_aligned(cout << "\nxN =\n", xN);
	//	output_aligned(cout << "\nxB =\n", xB);

	//}

	//output_aligned(cout << "\nff = \n", ff);
	//output_aligned(cout << "\nfff =\n", matrix<double>(ff));

	//output_aligned(cout << "\nB^(-1) = \n", inverse(matrix<rational<T> >(bmat)));
	//output_aligned(cout << "\n(b'|-A') =\n", ba_orig);
	//output_aligned(cout << "\nB^(-1)*(b'|-A') =\n", inverse(matrix<rational<T> >(bmat))*(ba_orig));
	//matrix<rational<T> > xout = transpose(inverse(matrix<rational<T> >(bmat))*(ba_orig)*transpose(f));
	//output_aligned(cout << "\n(B^(-1)*(b'|-A')*X')^T =\n", xout);

	//xout.insert_col(0, f.copy_col(0));
	//for(int i = 1; i < f.ncols(); ++i)
	//	xout.insert_col(xout.ncols(), f.copy_col(i));

	//output_aligned(cout << "\nX = \n", xout);
	//for(int i = 0; i < xout.nrows(); ++i)
	//	if(!is_null(xout(i, 0)))xout.div_row(i, safe_reference(xout(i, 0)));

	//output_aligned(cout << "\nX normalized =\n", xout);

}

void problem_1a_2term_Shevchenko (const std::string& file_with_problem, matrix<big_int>& f, matrix<int>& tr,
								  vector<big_int>& deltaBinvb)
{
	// ���������� ��������� �������-������� ��� ������� ����� ������ ���.

	typedef big_int T;
	typedef matrix<T, false> Matrix;
	typedef vector<T, false> Vector;
	
	Matrix a;
	Vector b, c;
	Vector basis;

	task_basis_from_file(file_with_problem.c_str(), a, b, c, basis);
	print_task(a, b, c);


	rational<> det;

	{
		Matrix ab = a;
		ab.insert_col(0, b);
		
		matrix<rational<> > newa, bn;
		partial_rref_int_order(matrix<rational<> >(ab), newa, bn, det, basis);
		a = bn;
		output_aligned(cout << "PARTIAL_RREFINT(b|A) = \n", newa);
		deltaBinvb = newa.copy_col(0);
		output_aligned(cout << "\nbn = \n", bn);
	}


	a.opposite();
	a.mult_col(0, -1);
	Matrix ba_orig = a;

	for(int i = 0; i < a.ncols(); ++i)
	{
		Vector v(a.ncols());
		v[i] = 1;
		a.insert_row(i, v);
	}

	output_aligned(cout << "\nA =\n", a);

	Matrix /*f,*/ q, e;
	skeleton(a, f, q, e, ctrl::make_skeleton_slog(std::cout, false));

	matrix<rational<> > ff = f;
	for(int i = 0; i < ff.nrows(); ++i)
		if(!is_null(ff(i, 0)))ff.div_row(i, safe_reference(ff(i, 0)));

	output_aligned(cout << "\nff = \n", ff);

	matrix<rational<> > xbdelta = transpose(matrix<rational<> >(ba_orig)*transpose(ff));
	output_aligned(cout << "\nxbdelta = \n", xbdelta);
	matrix<rational<> > xb = xbdelta/std::abs(det);
	output_aligned(cout << "\nxb = \n", xb);

	matrix<rational<> > pre_x = xb;
	
	for(size_t i = 0; i < ff.ncols(); ++i)
		pre_x.insert_col(pre_x.ncols(), ff.copy_col(i));

	output_aligned(cout << "\nx preorder = \n", pre_x);
	matrix<rational<> > x;

	Vector order;
	create_vector_order(basis, order, pre_x.ncols());
	Vector invorder;
	vec_inverse_permutation(order, invorder);

	mat_col_copy_order(pre_x, x, invorder);
	x.erase_col(0);

	output_aligned(cout << "\nx =\n", x);

	std::cout << "\n******* TRIANGULATION *********\n";
	output_aligned(std::cout << "\nQ from Skeleton = \n", q);

	//matrix<int> tr;
	triangulate_motzkin_burger(q, tr);

	output_aligned(cout << "\nsimplexes: \n", tr);
}

void problem_1b_2term_Shevchenko (const std::string& file_with_problem, matrix<big_int>& f, matrix<int>& tr)
{
	// ���������� ��������� �������-������� ��� ������� ������������ ������ ���.

	typedef big_int T;
	typedef matrix<T, false> Matrix;
	typedef vector<T, false> Vector;
	
	Matrix a;
	Vector b, c;

	task_from_file(file_with_problem.c_str(), a, b, c);
	print_task(a, b, c);

	a = transpose(a);
	a.insert_col(0, -c);

	a.insert_row(0, T(0));
	a(0, 0) = 1;

	output_aligned(cout << "\n-c|A^T =\n", a);

	Matrix /*f,*/ q, e;
	skeleton(a, f, q, e, ctrl::make_skeleton_slog(std::cout));

	matrix<rational<> > ff = f;
	for(int i = 0; i < ff.nrows(); ++i)
		if(!is_null(ff(i, 0)))ff.div_row(i, safe_reference(ff(i, 0)));

	output_aligned(cout << "\nff =\n", ff);

	std::cout << "\n******* TRIANGULATION *********\n";
	output_aligned(std::cout << "\nQ from Skeleton = \n", q);

	//matrix<int> tr;
	triangulate_motzkin_burger(q, tr);

	output_aligned(cout << "\nsimplexes: \n", tr);
}


void find_in_bounding_box
(
	const matrix<big_int> simplex, const big_int& det,
	Arageli::vector<big_int>& row_coefs, Arageli::vector<big_int>& res
)
{

	matrix<rational<> > rsimplex = simplex;
	vector<rational<> > up(rsimplex.ncols() - 1, -10000000), bot(rsimplex.ncols() - 1, 10000000);
	vector<rational<> > recup(rsimplex.ncols() - 1, 0), recbot(rsimplex.ncols() - 1, 0);
	for(size_t i = 0; i < rsimplex.nrows(); ++i)
	{
		if(rsimplex(i, 0) >= 1)
		{
			if(rsimplex(i, 0) > 1)rsimplex.div_row(i, safe_reference(rsimplex(i, 0)));
		
			for(size_t j = 0; j < up.size(); ++j)
			{
				rational<> curup = rsimplex(i, j+1), curbot = rsimplex(i, j+1);
				//std::cerr << "\nup = " << up << ", bot = " << bot;
				if(up[j] < curup)up[j] = curup;
				if(bot[j] > curbot)bot[j] = curbot;
			}
		}
		else if(rsimplex(i, 0) == 0)
		{
			// ����������� �����������:

			for(size_t j = 0; j < up.size(); ++j)
			{
				rational<> curup = rsimplex(i, j+1), curbot = rsimplex(i, j+1);
				if(recup[j] < curup)recup[j] = curup;
				if(recbot[j] > curbot)recbot[j] = curbot;
			}
			
		}
	}

	

	std::cerr << "\nup = " << up + recup << ", bot = " << bot + recbot << "\n";

	vector<big_int> rup = floor(up + recup), rbot = ceil(bot + recbot);

	std::cerr << "\nrup = " << rup << ", rbot = " << rbot << "\n";
	std::cerr << "Number of potential points: " << product(rup - bot + 1) << "\n";

	matrix<big_int> ainv = det*inverse(matrix<rational<> >(simplex));

	//output_aligned(cout << "\nSIMPLEX\n", ainv);

	vector<big_int> point = rbot;
	point.push_front(1);	// always
	
	for(;;)
	{
		vector<big_int> z = point*ainv;
		if(z == 0){ cerr << "ERROR1"; return; }
		if(Arageli::allcmp_vec_by_val(z, 0, std::greater_equal<big_int>()))
		{
			bool good = false;
			for(size_t i = 0; i < simplex.nrows(); ++i)
				if(simplex(i, 0) > 1 && z[i] != 0){ good = true; break; }

			if(good)
			{
				row_coefs = z;
				res = point;
				return;
			}
		}

		for(size_t i = 1; i < point.size(); ++i)
			if(++point[i] > rup[i-1])
				point[i] = rbot[i-1];
			else break;

		std::cerr << point;

		vector<big_int> tpoint = point;
		tpoint.erase(0);
		if(tpoint == rbot)break;
	}

	row_coefs.resize(0);
}


void picking_coefs
(
	const matrix<big_int> simplex, const big_int& det,
	Arageli::vector<big_int>& row_coefs, Arageli::vector<big_int>& res
)
{
	Arageli::vector<big_int> col_0 = simplex.copy_col(0), col_0_orig = col_0;
	std::replace(col_0.begin(), col_0.end(), big_int(), det+1);
	Arageli::vector<big_int> ups = det/col_0;
	if(is_null(col_0_orig))
	{
		cout << "������: ���� ����������� �����������.#########################################";
		row_coefs.resize(0);
		return;
	}

	row_coefs.assign(col_0.size(), 0);
	row_coefs[0] = 1;

	Arageli::vector<int> nonintegers;
	for(size_t i = 0; i < simplex.nrows(); ++i)
		if(simplex(i, 0) > 1)nonintegers.push_back(i);

	cout << "\ndet = " << det << '\n';

	for(;;)
	{
		//cout << row_coefs << "\n";
		big_int sum = dotprod(row_coefs, col_0_orig);

		for(size_t i = 0; i < row_coefs.size(); ++i)
		{
			if(is_null(col_0_orig[i]))continue;
			ARAGELI_ASSERT_0(sum <= det);
			big_int delta = (det - sum)/col_0_orig[i];
			if(is_null(delta))
			{
					sum -= row_coefs[i]*col_0_orig[i];
					ARAGELI_ASSERT_0(!is_negative(sum));
					row_coefs[i] = 0;
			}
			else
			{
				if(i == 0)
					row_coefs[i] += delta;
				else
					++row_coefs[i];

				break;
			}
		}

		cerr << "\n" << row_coefs;

		if(is_null(row_coefs))break;

		if
		(
			dotprod(col_0_orig, row_coefs) == det &&
			!is_null(row_coefs.copy_subvector(nonintegers))
		)
		{
			// ��������� ������� ���������.
			res.assign(simplex.ncols(), 0);
			for(size_t i = 0; i < simplex.nrows(); ++i)
				res += simplex.copy_row(i)*row_coefs[i];

			bool is_div = true;
			for(size_t i = 0; i < res.size(); ++i)
				if(!is_divisible(res[i], det)){ is_div = false; break; }

			if(is_div)
			{
				res /= det;
				return;
			}
		}

	}

	row_coefs.resize(0);
}


void problem_2_2term_Shevchenko (matrix<big_int>& f, matrix<int>& tr)
{
	while(tr.nrows())
	{
		// ������������ ������� �������� � tr

		Arageli::vector<int> isimplex = tr.take_row(0);
		matrix<big_int> simplex = f.copy_rows(isimplex);
		//tr.erase_row(0);

		// ������� �� ������ �������. ���� ��� �������, �� �� ������������ ���, ��� �� �����.
		bool is_not_int = false;
		for(size_t j = 0; j < simplex.nrows(); ++j)
			if(simplex(j, 0) > 1)
			{
				is_not_int = true;
				break;
			}

		if(!is_not_int)
		{
			cout << "��� ������� ��������� " << isimplex << " �����.\n";
			continue;
		}

		big_int det = det_int(simplex);

		cout << "������������ ��������� " << isimplex << " ����� " << det << ".\n";
		if(det == 1 || det == -1)
		{
			continue;
		}

		det = std::abs(det);

		Arageli::vector<big_int> row_coefs, res;

		find_in_bounding_box(simplex, det, row_coefs, res);
		output_aligned(cout/* << "������������� ��������\n"*/, simplex);

		if(row_coefs.is_empty())
		{
			cout << "\n����� ����� ����� �� �������.\n";
		}
		else
		{
			size_t newnum = f.nrows();
			for(size_t i = 0; i < f.nrows(); ++i)
				if(f.copy_row(i) == res){ newnum = i; break; }

			cout << "\n������������ ���������� �����: " << row_coefs;
			if(newnum == f.nrows())
				cout << "\n����� �����: " << res << ", ����� " << f.nrows();
			else
				cout << "\n��� ����� " << res << " ��� ���� (" << newnum << ").";
			cout << "\n����� ���������: \n";
			
			for(size_t i = 0; i < row_coefs.size(); ++i)
				if(!is_null(row_coefs[i]))
				{
					vector<int> newsimplex = isimplex;
					newsimplex[i] = newnum;
					cout << "\t" << newsimplex << '\n';
					tr.insert_row(0, newsimplex);
				}
				cout << std::endl;
			if(newnum == f.nrows())f.insert_row(f.nrows(), res);
		}
	}

	matrix<big_int> ineq, q, e, f_all = f;

	//skeleton(f_all, ineq, q, e);
	//skeleton(ineq, f_all, q, e);

	for(size_t i = 0; i < f.nrows();)
		if(f(i, 0) > 1)f.erase_row(i);
		else ++i;
	
	
	output_aligned(cout << "\n��� ����� �����, �������������� �� '���������' � ���.����.: \n", f);

	skeleton(f, ineq, q, e);

	output_aligned(cout << "������� ������� ���������� (����������� ������� Ax >= 0):\n", ineq);
	skeleton(ineq, f, q, e);
	output_aligned(cout << "������� ����� � ���. ����.:\n", f);

	//output_aligned(cout << "�������� ������� ����� � ���. ����.", f_all);
}


void solve_mod_2 (vector<big_int> cureq, big_int curb, big_int curmodule, matrix<big_int>& curres)
{
	ARAGELI_ASSERT_0(cureq.size() == 2);
	big_int first = cureq[0], alpha = cureq[1], gamma = curb;
	cout << "\n���������� ������: ";
	for(;;)
	{
		cout << "\n(" << first << ", " << alpha << ") = " << gamma << " (mod " << curmodule << ")" << std::flush;

		if(gamma == 0)break;

		//alpha -= curmodule/2;
		if(first != 1)
		{
			// ���������� �� ������ ����������:
			big_int invfirst = inverse_mod(first, curmodule);
			cout
				<< "\n��������� �� ������ ����������: (" << first << "^(-1) = "
				<< invfirst << "(mod " << curmodule << "))" << std::flush;
			first = first*invfirst%curmodule;
			alpha = alpha*invfirst%curmodule;
			gamma = gamma*invfirst%curmodule;
			
			cout << "\n(" << first << ", " << alpha << ") = " << gamma << " (mod " << curmodule << ")" << std::flush;
		}

		if(alpha == 1 || alpha == 0)break;
			// The Algorithm :)

			if(alpha > curmodule/2)
			{
				alpha -= curmodule;
				cout << "\n(" << first << ", " << alpha << ") = " << gamma << " (mod " << curmodule << ")" << std::flush;

				big_int newalpha = prrem(curmodule, -alpha);
				big_int newgamma = prrem(gamma - curmodule, -alpha);
				curmodule = -alpha;
				alpha = newalpha;
				gamma = newgamma;
			}
			else
			{
				big_int newalpha = prrem(-curmodule, alpha);
				gamma = prrem(gamma, alpha);
				curmodule = alpha;
				alpha = newalpha;
			}
	}
}


void problem_3a_2term_Shevchenko (const std::string& file_with_problem/*,
								  vector<big_int>& deltaBinvb*/)
{
	typedef big_int T;
	typedef matrix<T, false> Matrix;
	typedef vector<T, false> Vector;
	
	Matrix a;
	Vector b, c;
	Vector basis;

	task_basis_from_file(file_with_problem.c_str(), a, b, c, basis);
	print_task(a, b, c);

	Matrix B = a.copy_cols(basis - 1);
	output_aligned(cout << "\n�������� ����������:\n", B);
	Matrix D, P, Q;
	big_int det;
	size_t rank;

	smith(B, D, P, Q, rank, det);
	det = std::abs(det);
	output_aligned(cout << "\ncheck\n", P*B*Q);

	output_aligned(cout << "\n���(B):\n", D);
	output_aligned(cout << "\nP:\n", P);
	output_aligned(cout << "\nQ:\n", Q);

	vector<big_int> beta = det*inverse(matrix<rational<> >(B))*vector<rational<> >(b);
	cout << "\nbeta = " << beta;

	Matrix sys = Q;
	vector<size_t> erasedrows;
	vector<big_int> modules;
	for(size_t i = 0; i < D.nrows(); ++i)
	{
		modules.push_back(D(i, i));
		if(D(i, i) == 1)erasedrows.push_back(i);
	}

	modules.erase_subvector(erasedrows);
	sys.erase_cols(erasedrows);

	sys = transpose(sys);

	vector<big_int> sysb = det - c.copy_subvector(basis-1)*Q;
	sysb.erase_subvector(erasedrows);

	for(size_t i = 0; i < sys.nrows(); ++i)
	{
		for(size_t j = 0; j < sys.ncols(); ++j)
			sys(i, j) = prrem(sys(i, j), modules[i]);
		sysb[i] = prrem(sysb[i], modules[i]);
	}

	//sys = "((17, 11, 1))"; sysb = "(1)"; modules = "(18)";

	output_aligned(cout << "\n������� ������� ���������� ���������: \n", sys);
	output_aligned(cout << "\n������ ������ ������: \n", sysb);
	output_aligned(cout << "\n������ �������: \n", modules);

	// ������ ��������� ���������


	vector<big_int> lasteq = sys.copy_row(sys.nrows() - 1);
	big_int curmodule = modules.back();
	matrix<big_int> res;
	double upbound = std::pow(double(curmodule), 1.0/B.ncols()) - 1;
	cout << "����������� �� ���������� ������� �����: " << upbound;

	for(size_t i = 0; i < sys.ncols(); ++i)
	{
		for(size_t j = 0; j <= upbound; ++j)
		{
			cout << "\nv[" << i << "] = " << j << '\n';
			vector<big_int> cureq = lasteq;
			big_int curb = prrem(sysb.back() - j*cureq[i], curmodule);
			cureq.erase(i);
			matrix<big_int> curres;
			solve_mod_2(cureq, curb, curmodule, curres);
			//curres.insert_col(i, vector<big_int>(curres.nrows(), big_int(j)));
			//for(size_t k = 0; k < curres.nrows(); ++k)
			//	res.insert_row(res.nrows(), curres.copy_row(k));
		}
	}
}



void test4_3 ()
{

	Arageli::vector<big_int> vect(2);
	vect[0] = 0;

}


void test4_4 ()
{
	typedef /*sparse_polynom<rational<> >*/rational<> P;
	typedef matrix<P> M;

	M a = "((-1, 1, 1), (2, -1, -1), (1, 0, 0), (0, 1, 0), (0, 0, 1))";
	M f, q, e;
	skeleton(a, f, q, e);

	output_aligned(std::cout << "\nF =\n", f);
	output_aligned(std::cout << "\nQ =\n", q);
	output_aligned(std::cout << "\nE =\n", e);

	a = "((1, 1, 0), (1, 2, 0), (1, 0, 1), (1, 0, 2))";
	skeleton(a, f, q, e);

	output_aligned(std::cout << "\n*********************\nF =\n", f);
	output_aligned(std::cout << "\nQ =\n", q);
	output_aligned(std::cout << "\nE =\n", e);
}


void test4_5 ()
{
	typedef sparse_polynom<rational<> > P;
	typedef matrix<P> M;

	M a = "((1, 1), (1, x), (1, 0))";
	M f, q, e;
	skeleton(a, f, q, e, ctrl::make_skeleton_slog(std::cout));

	output_aligned(std::cout << "\nF =\n", f);
	output_aligned(std::cout << "\nQ =\n", q);
	output_aligned(std::cout << "\nE =\n", e);

	a = "((-1, 1), (x, -1))";
	skeleton(a, f, q, e, ctrl::make_skeleton_slog(std::cout));

	output_aligned(std::cout << "\n*********************\nF =\n", f);
	output_aligned(std::cout << "\nQ =\n", q);
	output_aligned(std::cout << "\nE =\n", e);
}


void test4_6 ()
{
	typedef matrix<rational<int> > M;
	//M a = "((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, -1, -1), (-1/2, 1, 1))";
	M a = "((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, -1, -1), (-1/2, 1, 1))";
	M f, q, e;
	matrix<size_t> tr;
	skeleton(a, f, q, e);
	triangulate_motzkin_burger(q, tr, ctrl::triangulate_motzkin_burger_idler());

	output_aligned(std::cout << "\nF =\n", f);
	output_aligned(std::cout << "\nQ =\n", q);
	output_aligned(std::cout << "\nE =\n", e);
	output_aligned(std::cout << "\nTr =\n", tr);

}


void test4_7 ()
{
	typedef residue<sparse_polynom<residue<int> > > T;
	T a = "( ((1(mod 2))*x) (mod ((1(mod 2))*x^3)) )";


	for(int i = 0; i < 30; ++i)
	{
		std::cout << a << '\n';
		a += T("1(mod 2) (mod ((1(mod 2))*x^3))");
	}
	
}


void test4_8 ()
{
	typedef std::map<std::string, Arageli::matrix<rational<> > > Vars;
	std::map<std::string, Arageli::matrix<rational<> > > vars;

	{
		std::ifstream varsfile("easymath.vars.txt");

		for(;;)
		{
			std::string line;
			std::getline(varsfile, line);
			if(line.empty())break;
			std::istringstream buffer(line);
			buffer >> line;
			buffer >> vars[line];
		}
	}

	for(;;)
	{
		std::string line;
		std::cout << "\n>";
		std::getline(std::cin, line);
		std::istringstream buffer(line);
		std::string command;
		buffer >> command;

		if(command == "exit" || command == "quit")break;
		else if(command == "new")
		{
			buffer >> command;
			if(command == "matrix")
			{
				buffer >> command;
				buffer >> vars[command];
				if(!buffer && !buffer.eof())
					std::cout << "Warning. Value is unset.";
			}
			else
				std::cout << "Error. Unknown type \"" << command << "\".";
		}
		else if(command == "delete")
		{
			buffer >> command;
			Vars::iterator i = vars.find(command);
			if(i == vars.end())
				std::cout << "Error. Variable \"" << command << "\" is undefined.";
			else
				vars.erase(i);
		}
		else if(command == "list")
		{
			for(Vars::iterator i = vars.begin(); i != vars.end(); ++i)
				Arageli::output_aligned(std::cout << i->first << " =\n", i->second);
		}
		else if(command == "print")
		{
			buffer >> command;

			if(command == "add" || command == "mul" || command == "sub")
			{
				std::string arg1, arg2;
				buffer >> arg1 >> arg2;
				if(arg2.empty())arg2 = arg1;
				Vars::mapped_type temp;

				Vars::iterator iarg1 = vars.find(arg1), iarg2 = vars.find(arg2);
				if(iarg1 == vars.end() || iarg2 == vars.end())
				{
					std::cout
						<< "Error. Variable \"" << arg1 << "\" or \""
						<< arg2 << "\" are undefined.";
				}
				else
					if(command == "add")
						temp = iarg1->second + iarg2->second;
					else if(command == "mul")
						temp = iarg1->second * iarg2->second;
					else if(command == "sub")
						temp = iarg1->second - iarg2->second;
					else if(command == "div")
						temp = iarg1->second / iarg2->second;
				
				output_aligned(std::cout, temp);
			}
			else
			{
				Vars::iterator i = vars.find(command);
				if(i == vars.end())
					std::cout << "Error. Variable \"" << command << "\" is undefined.";
				else
					Arageli::output_aligned(std::cout << i->first << " =\n", i->second);
			}
		}
		else if(command == "set")
		{
			buffer >> command;

			if(command == "add" || command == "mul" || command == "sub" || command == "mov")
			{
				std::string arg1, arg2;
				buffer >> arg1 >> arg2;
				if(arg2.empty())arg2 = arg1;

				Vars::iterator iarg1 = vars.find(arg1), iarg2 = vars.find(arg2);
				if(iarg1 == vars.end() || iarg2 == vars.end())
				{
					std::cout
						<< "Error. Variable \"" << arg1 << "\" or \""
						<< arg2 << "\" are undefined.";
				}
				else
					if(command == "add")
						iarg1->second += iarg2->second;
					else if(command == "mul")
						iarg1->second *= iarg2->second;
					else if(command == "sub")
						iarg1->second -= iarg2->second;
					else if(command == "div")
						iarg1->second /= iarg2->second;
					else if(command == "mov")
						iarg1->second = iarg2->second;
				
				std::cout << iarg1->first << " =\n";
				output_aligned(std::cout, iarg1->second);
			}
			else
			{
				buffer >> command;
				Vars::iterator i = vars.find(command);
				if(i == vars.end())
					std::cout << "Error. Variable \"" << command << "\" is undefined.";
				else
					buffer >> i->second;
			}
		}
		else if(command == "addmult")
		{
			size_t i1, i2;
			rational<> alpha, beta;
			std::string var;
			buffer >> command >> var >> i1 >> alpha >> i2 >> beta;

			Vars::iterator i = vars.find(var);
			if(i == vars.end())
				std::cout << "Error. Variable \"" << var << "\" is undefined.";
			else
			{
				if(command == "row")
				{
					i->second.addmult_rows(i1, alpha, i2, beta);
				}
				else if(command == "col")
				{
					i->second.addmult_cols(i1, alpha, i2, beta);
				}

				output_aligned(std::cout << i->first << " =\n", i->second);
			}

		}
		else if(command == "save")
		{
			std::ofstream varsfile("easymath.vars.txt");

			for(Vars::iterator i = vars.begin(); i != vars.end(); ++i)
				varsfile << i->first << " " << i->second << "\n";
		}
		else if(command == "det")
		{
			buffer >> command;
			Vars::iterator i = vars.find(command);
			if(i == vars.end())
				std::cout << "Error. Variable \"" << command << "\" is undefined.";
			else
				std::cout << det(i->second);
		}
		else if(command == "smith")
		{
			buffer >> command;
			Vars::iterator i = vars.find(command);
			if(i == vars.end())
				std::cout << "Error. Variable \"" << command << "\" is undefined.";
			else
			{
				matrix<big_int> P, Q, res;
				size_t rank;
				big_int det;
				smith(matrix<big_int>(i->second), res, P, Q, rank, det);
				output_aligned(cout << "Smith\n", res);
				output_aligned(cout << "P = \n", P);
				output_aligned(cout << "Q = \n", Q);
			}
		}
		else if(command == "clear")
		{
			vars.clear();
		}
		else if(command.length())
		{
			std::cout << "Error. Unknown command.";
		}
	}

	{
		std::ofstream varsfile("easymath.vars.txt");

		for(Vars::iterator i = vars.begin(); i != vars.end(); ++i)
			varsfile << i->first << " " << i->second << "\n";
	}

}


template <typename A>
void norm_first_col (A& a)
{
	for(size_t i = 0; i < a.nrows(); ++i)
		a.div_row(i, safe_reference(a(i, 0)));
}


void test4_9 ()
{
	typedef big_int T;
	matrix<T> a = "((18, 0, 0), (0, 18, 0), (0, 0, 18), (37, 7, 6), (40, 1, -21), (41, -1, 12))",
		f, q, e;
	skeleton(a, f, q, e, ctrl::make_skeleton_slog(std::cout, false));
	matrix<rational<> > qq;

	qq.insert_col(0, q.copy_col(3));
	qq.insert_col(1, q.copy_col(1));
	qq.insert_col(2, q.copy_col(4));
	qq.insert_col(3, q.copy_col(5));
	qq.insert_col(4, q.copy_col(2));

	qq.insert_col(0, q.copy_col(0));
	
	norm_first_col(qq);
	output_aligned(cout, qq);
}


void test4_10 ()
{
	cout << "\n\n ******* Integer Ring ******** \n\n";

	{
		typedef int T;

		matrix<T> a = "((1, 2, 3), (4, 5, 6), (7, 8, 9))", b, q;
		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det);

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		cout << "\nis it valid RREF?: " << (b == q * a);
	}

	cout << "\n\n ******* Rational Field ******** \n\n";

	{
		typedef rational<int> T;

		matrix<T> a = "((1, 2, 3), (4, 5, 6), (7, 8, 9))", b, q;
		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det);

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		cout << "\nis it valid RREF?: " << (b == q * a);
	}

	cout << "\n\n ******* Finite Field ******** \n\n";

	{
		typedef residue<int> T;

		matrix<T> a = "((1, 2, 3), (4, 5, 6), (7, 8, 9))", b, q;
		
		for(matrix<T>::iterator i = a.begin(); i < a.end(); ++i)
		{
			i->module() = (1 << next_mersen_prime_degree(10)) - 1;//11;
			i->normalize();
		}

		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det);

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		cout << "\nis it valid RREF?: " << (b == q * a);
	}
}


void test4_11 ()
{
	vector<rational<> > a = "(1, 1/2, 1/3, 1/4,	1/5)";
	vector<int> index = "(1, 2, 3, 3, 0, 1)";
	output_list(cout << '\n', a);
	output_list(cout << '\n', index);
	output_list(cout << '\n', a[index]);

	index = "(0, 2)";
	a[index] = a[index + 1];

	output_list(cout << "\n\n", a);

	//output_list(cout << '\n', a[index][index]);
	//output_list(cout << '\n', a[index][index][index]);

	//a[index][2] = 100;

	//output_list(cout << "\n\n", a);
	//output_list(cout << "\n\n", a[index]);
	//output_list(cout << '\n', a[index][index]);
	//output_list(cout << '\n', a[index][index][index]);

}


void test4_12 ()
{
	typedef residue<int> T;
	typedef matrix<T, false> M;

	M qi =
		"((1,  0,  0,  0,  0,  0,  0,  0),"
		" (2,  1,  7, 11, 10, 12,  5, 11),"
		" (3,  6,  4,  3,  0,  4,  7,  2),"
		" (4,  3,  6,  5,  1,  6,  2,  3),"
		" (2, 11,  8,  8,  3,  1,  3, 11),"
		" (6, 11,  8,  6,  2,  7, 10,  9),"
		" (5, 11,  7, 10,  0, 11,  7, 12),"
		" (3,  3, 12,  5,  0, 11,  9, 12))";

	for(M::iterator i = qi.begin(); i < qi.end(); ++i)
	{
		i->module() = 13;
		i->normalize();
	}

	qi -= M(qi.nrows(), eye);

	output_aligned(cout << "Q - I=\n", qi);

	M rreftqi, invqi;
	vector<int> basis;

	rref(transpose(qi), rreftqi, invqi, basis);
	rreftqi.erase_rows(vector<int>("(5, 6, 7)"));

	output_aligned(cout << "\nRREF((Q - I)^T) =\n", rreftqi);

	M bm = rreftqi.take_cols(basis);
	rreftqi.opposite();

	output_aligned(cout << "\nbasis matrix =\n", bm);
	output_aligned(cout << "\nnonbasis matrix =\n", rreftqi);


	for(size_t i = 0; i < rreftqi.ncols(); ++i)
	{
		vector<T> x(rreftqi.ncols());
		x[i] = 1;
		cout << "\nxbasis = " << x;
		cout << "\nxnonbasis = " << rreftqi*x;
	}
}


void test4_13 ()
{
	cout
		<< "\n" << vector<int>("()")
		<< "\n" << vector<int>("(1)")
		<< "\n" << vector<int>("(1, 2, 3)")
		<< "\n" << vector<int>("(1:5, 100)")
		<< "\n" << vector<int>("(200, 5:-2)")
		<< "\n" << vector<int>("(100, 0:5:25, 200)")
		<< "\n" << vector<sparse_polynom<int> >("(0, x : x^2 : 3*x^2+x, 1)")
		<< "\n" << vector<sparse_polynom<int> >("(x:x^2:3*x^2+x)")
		<< "\n" << vector<sparse_polynom<int> >("(x-2:x+3)")
		<< "\n" << vector<sparse_polynom<int> >("(x : x)");
	cout << "\n";

	vector<rational<> > v;
	cout << "\n" << v;
	v.insert(0, "(3, 2, 1)");
	cout << "\n" << v;
	v.insert(1, vector<rational<> >("(4/5:-1/5:1/5)") + 2);
	cout << "\n" << v;
	v.insert(v.size(), 3, rational<big_int>(-1));
	cout << "\n" << v;
}


void test4_14 ()
{
	big_float::set_global_precision(100);
	big_float::set_round_mode(TO_NEAREST);

	big_float
		a = "1.1234567890987654321",
		b = "82736418265418217823000000.0000000000000000000000000000000001111111";

	std::cout.setf ( std::ios::fixed, std::ios::floatfield );
	cout << "\na = " << a << "\nb = " << b << "\na + b = " << a + b;

	//cout << big_int(std::numeric_limits<__int64>::min());
}


void test4_15 ()
{
	matrix<int> m(32, 3200), b, p, q;
	std::size_t rank;
	int det;

	m(0, 0) = 345;
	m(0, 1) = -23; 
	m(1, 0) = 77; 
	m(1, 199) = 31; 
	m(29, 310) = 11; 

	smith(m, b, p, q, rank, det);

	output_aligned(std::cout, b.copy_rows(vector<int>("(1, 2, 3, 4, 5)")-1).copy_cols(vector<int>("(1, 2, 3, 4, 5)")-1));
}


void test4_16 ()
{
	typedef sparse_polynom<big_int, big_int> P1; typedef sparse_polynom<big_int> P2;
	output_aligned(std::cout, sylvester(P1("3*x^2-1"), P2("x^4+10*x^2-7")));
	std::cout << "\nres = " << resultant(P1("3*x^2-1"), P2("x^4+10*x^2-7"));

	typedef sparse_polynom<rational<> > P3;
	vector<P3> f;
	cout << "\n" << squarefree_factorize_poly_rational(pow(P3("x^10-12*x^5+4*x^4-3*x^3-190"), 1), f);
	cout << "\n" << squarefree_factorize_poly_rational(pow(P3("x^10-12*x^5+4*x^4-3*x^3-190"), 2), f);
	cout << "\n" << squarefree_factorize_poly_rational(pow(P3("x^10-12*x^5+4*x^4-3*x^3-190"), 3), f);

	typedef sparse_polynom<P3> P4;

	P3 a = "2*x^3-x+17", b = "x^2+5";

	cout << "\n" << a.subs(P4("((x)-x)"));
	output_aligned(std::cout << "\n", sylvester(a.subs(P4("((x)-x)")), b));
	cout << resultant(a.subs(P4("((x)-x)")), b);


}


//template <typename P, typename Seg>
//double algebraic_to_double (const P& p, const Seg& seg)
//{
//	interval<double> fseg = seg;
//	interval_root_precise(p, fseg, 0.00000000001);
//	return fseg.first;
//}


void test4_17 ()
{
	typedef rational<big_int> T;
	typedef sparse_polynom<T> P;
	//typedef sparse_polynom<P> Pxy;
	typedef interval<T> Seg;
	//typedef vector<P, false> Polyvec;
	//typedef vector<Seg, false> Segvec;

	//Polyvec polyvec = "(x^2-2, x^2-2)";
	//Segvec segvec = "((-1, 2), (-2, 0))";
	//P p; Seg seg;
	//
	//P rslt = resultant(polyvec[0].subs(Pxy("((x)-x)")), polyvec[1]);

	//algebraic_func_rslt(polyvec, segvec, rslt, p, seg, my_func<Segvec>());

	//P p; Seg seg;

	//P ap = "x^2-2"; Seg as = "(1, 2)";
	//P bp = "x^3-3"; Seg bs = "(-2, -1)";

	//std::cout << std::setprecision(15);

	//algebraic_plus(ap, as, bp, bs, p, seg);
	//std::cout << "\n" << algebraic_to_double(p, seg);
	//algebraic_multiplies(p, seg, P("11*x-10"), Seg("10/11", "10/11"), p, seg);
	//std::cout << "\n" << algebraic_to_double(p, seg);
	//algebraic_divides(p, seg, P("x^5-12"), Seg(0, 12), p, seg);
	//std::cout << "\n" << algebraic_to_double(p, seg);

	std::time_t tm = time(0);
	
	algebraic<T, T>
		a("x^2-2", "(1, 2)"),
		b("x^3+3", "(-2, -1)"),
		c("11*x-10", "(10/11, 10/11)"),
		d("x^5-12", "(1, 12)");

	std::cout << "\na + b = " << a << " + " << b; 
	a += b;
	std::cout << "\na + b = " << a << " = " << double(a);

	std::cout << "\na * c = " << a << " * " << c;
	a *= c;
	std::cout << "\na * c = " << a << " = " << double(a);

	std::cout << "\na / d = " << a << " / " << d;
	a /= d;
	std::cout << "\na / d = " << a << " = " << double(a);

	std::cout << "\na / a = " << a << " / " << a;
	a /= a;
	std::cout << "\na / a = " << a << " = " << double(a);
	std::cout << "\nis_null(a) = " << a.is_null();

	std::cout << "\n\nTime: " << time(0) - tm;
}


void test4_18 ()
{
	std::cout << "\n7->" << next_mersen_prime_degree(7);
	std::cout << "\n6->" << next_mersen_prime_degree(6) << "\n";
	
	typedef residue<int, Arageli::_Internal::module_2pm1<unsigned int, int> > T;

	{

		matrix<T> a = "((1, 2, 3), (4, 5, 6), (7, 8, 9))", b, q;
		
		for(matrix<T>::iterator i = a.begin(); i < a.end(); ++i)
		{
			i->module() = next_mersen_prime_degree(10);
			i->normalize();
		}

		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det);

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		cout << "\nis it valid RREF?: " << (b == q * a);
	}

}

void test4_19 ()
{
	cout << "\n\n ******* Intervals on double ******** \n\n";

	{
		typedef interval<double> T;

		matrix<T> a = "(((0.999, 1.001), (1.999, 2.001), (2.999, 3.001)), ((3.999, 4.001), (4.999, 5.001), (5.999, 6.001)), ((6.999, 7.001), (7.999, 8.001), (8.999, 9.001)))", b, q;
		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det, ctrl::make_rref_slog(std::cout));

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		output_aligned(cout << "\nq * a =\n", q * a);
		output_aligned(cout << "\nb - q * a =\n", b - q * a);
		cout << "\nis it valid RREF?: " << (b == q * a);
	}

	cout << "\n\n ******* Intervals on rational ******** \n\n";

	{
		typedef interval<rational<> > T;

		matrix<rational<> > aa = "((1, 2, 3), (4, 5, 6), (7, 8, 9))";
		
		matrix<T> a = aa, b, q;

		for(matrix<T>::iterator i = a.begin(); i != a.end(); ++i)
		{
			i->first() -= rational<>(1, 1000);
			i->second() += rational<>(1, 1000);
		}

		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det, ctrl::make_rref_slog(std::cout));

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		output_aligned(cout << "\nq * a =\n", q * a);
		output_aligned(cout << "\nb - q * a =\n", b - q * a);
		cout << "\nis it valid RREF?: " << (b == q * a);
	}

	cout << "\n\n ******* Intervals on rational functions ******** \n\n";

	{
		typedef interval<rational<sparse_polynom<rational<> > > > T;

		matrix<double> aa = "((1, 2, 3), (4, 5, 6), (7, 8, 9))";
		
		matrix<T> a = aa, b, q;

		for(matrix<T>::iterator i = a.begin(); i != a.end(); ++i)
		{
			i->first() -= rational<sparse_polynom<rational<> > >("x");
			i->second() += rational<sparse_polynom<rational<> > >("x");
		}

		vector<size_t> basis;
		T det;

		rref(a, b, q, basis, det, ctrl::make_rref_slog(std::cout));

		output_aligned(cout << "a =\n", a);
		output_aligned(cout << "\nb =\n", b);
		output_aligned(cout << "\nq =\n", q);
		cout << "\nbasis = " << basis;
		cout << "\ndet = " << det;
		output_aligned(cout << "\nq * a =\n", q * a);
		output_aligned(cout << "\nb - q * a =\n", b - q * a);
		cout << "\nis it valid RREF?: " << (b == q * a);
	}
}


void test4_20 ()
{
	typedef algebraic<> T;

	vector<interval<rational<> > > segs;
	sparse_polynom<rational<> > p = "x^3+6*x^2+5*x-5";
	//sparse_polynom<rational<> > p = "x^2-2";
	sturm<rational<> >(p, segs);

	std::cout << "\np = " << p;
	std::cout << "\nthe number of roots = " << segs.size();

	vector<T> roots(segs.size());

	for(size_t i = 0; i < segs.size(); ++i)
		roots[i] = T(p, segs[i]);

	output_aligned(std::cout << "\nroots =\n", roots);

	vector<double> froots = roots;

	output_aligned(std::cout << "\ndouble(roots) =\n", froots);

	vector<double> frootvals = p.subs(froots);

	output_aligned(std::cout << "\np(double(roots)) =\n", frootvals);

	vector<T> rootvals = p.subs(roots);

	output_aligned(std::cout << "\np(roots) =\n", rootvals);

	vector<double> rootfvals = rootvals;

	output_aligned(std::cout << "\ndouble(p(roots)) =\n", rootfvals);

	std::cout << "\nis_null(p(roots)) = " << is_null(rootvals);


}


void test4_21 ()
{
	matrix<big_int> a = "((-2, 1, 1), (2, -1, -1))", f, q, e;
	skeleton(a, f, q, e);
	
	output_aligned(std::cout << "\na = \n", a);
	output_aligned(std::cout << "\nf = \n", f);
	output_aligned(std::cout << "\nq = \n", q);
	output_aligned(std::cout << "\ne = \n", e);
}


void test4_22 ()
{
	typedef big_int T;
	typedef matrix<T> MT;
	MT a = "((-1, 1, 1), (2, -1, -1), (0, 1, 0), (0, 0, 1))"; T res;
	intcount_barvinok(a, res);

	std::cout << "barvinok: " << res;
}


void test4_23 ()
{
	typedef sparse_polynom<big_int> P;
	P p = 1; P x("x");
	for(int a = 1; a <= 50; ++a)
		p *= x - a;

	std::cout << p;
	vector<interval<rational<> > > lims;
	sturm<rational<> >(p, lims);

	output_aligned(std::cout << "\nlims =\n", lims);
}


void test4_24 ()
{
	typedef sparse_polynom<big_int> P;
	typedef interval<rational<> > SR;
	vector<P> ss;
	P p = "2*x-1";
	sturm_diff_sys(p, ss);
	SR seg;

	seg = "(1, -1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, -1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(0, 1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, 0)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1, 2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1/2, 2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, 1/2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1/2, 1/2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);

	p *= P("x-10");
	
	seg = "(1, -1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, -1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(0, 1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, 0)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1, 2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1/2, 2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, 1/2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1/2, 1/2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);

	p *= P("x+10");
	
	seg = "(1, -1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, -1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(0, 1)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, 0)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1, 2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1/2, 2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(-1, 1/2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
	
	seg = "(1/2, 1/2)";
	std::cout << "\nseg = " << seg << ",  nr = " << sturm_number_roots(ss, seg);
}


int test4 () 
{
	//const string task = "../../../../samples/old-samples/Shevchenko_course-3_v-896.task.txt";	// ���������
	//const string task = "../../../../samples/old-samples/Shevchenko_course-3_v-880.task.txt";	// �����
	//const string task = "../../../../samples/old-samples/Shevchenko_course-3_v-932.task.txt";	// ��������
	//const string task = "../../../../samples/old-samples/Shevchenko_course-3_v-another-from-Borovkov1.task.txt";	// �����
	const string task = "../../../../samples/old-samples/Shevchenko_course-3_v-another-from-Borovkov2.task.txt";	// �����


	matrix<big_int> f;
	matrix<int> tr;
	vector<big_int> deltaBinvb;

	//test4_1(task);
	//test4_2();
	//test4_3();
	//test4_4();
	//test4_6();
	//test4_7();
	//test4_8();
	//test4_9();
	//test4_10 ();
	//test4_11 ();
	//test4_12 ();
	//test4_13 ();
	//test4_14();
	//test4_15();
	//test4_16();
	//test4_17();
	//test4_18();
	//test4_19();
	test4_20();
	//test4_21();
	//test4_22();
	//test4_23();
	//test4_24();

	//problem_1a_2term_Shevchenko(task, f, tr, deltaBinvb);
	//problem_2_2term_Shevchenko(f, tr);
	//problem_3a_2term_Shevchenko(task, deltaBinvb);

	//cout << "\n ********************** ������������ ������ ********************** \n";

	//problem_1b_2term_Shevchenko(task, f, tr);
	//problem_2_2term_Shevchenko(f, tr);
	//problem_3a_2term_Shevchenko(task/*, deltaBinvb*/);
	//matrix<big_int> curres;
	//solve_mod_2(vector<big_int>("(1, 11)"), 2, 18, curres); 

	return 0;
}
