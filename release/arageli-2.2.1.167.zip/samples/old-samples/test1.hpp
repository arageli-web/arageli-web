/*****************************************************************************
	
	test1.hpp -- �����

	���� ���� �������� ������ ���������� Arageli.

	Copyright (C) Nikolai Yu. Zolotykh, 2005
	Copyright (C) Sergey S. Lyalin, 2005
	Copyright (C) University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

#ifndef _ARAGELI_test1_hpp_
#define _ARAGELI_test1_hpp_

#include <iostream>
#include <ctime>

#include <arageli/arageli.hpp>

//****************************************************************************

int test3 ();	// see test3.cpp
int test4 ();	// see test4.cpp
int test5 ();	// see test5.cpp

namespace Arageli
{

template <typename T>
void random_int_matrix (matrix<T>& m, size_t rows, size_t cols)
{
	m.assign_fromsize(rows, cols);
	std::generate(m.begin(), m.end(), std::rand);
}


void test1 (std::ostream& report);
int test2 ();	// see test2.cpp
void test_vector (std::ostream& report);


class Timing
{
public:
	
	Timing (bool on_a = true) : on_m(on_a), time_m(0)
	{ if(on_m)start_m = std::clock(); }
	
	bool is_on () const { return on_m; }
	
	void on (bool on_a = true)
	{
		if(on_m)return;
		start_m = std::clock();
		on_m = true;
	}
	
	void off ()
	{
		if(!on_m)return;
		time_m += double(std::clock() - start_m)/CLOCKS_PER_SEC;
		on_m = false;
	}

	double time () const
	{
		if(on_m)
			return time_m + double(std::clock() - start_m)/CLOCKS_PER_SEC;
		else
			return time_m;
	}

private:

	bool on_m;
	std::clock_t start_m;
	double time_m;
};





} // namespace Arageli


#endif  //  #ifndef _ARAGELI_sparse_polynom_test_hpp_
