#include <iostream>
#include <iomanip>
#include <fstream>
#include "arageli/arageli.hpp"
#include "arageli/hermite.hpp"
#include "arageli/smithpoly.hpp"

typedef unsigned long long tick_t;
extern "C" tick_t GetTick(void);

using namespace Arageli;

const std::string itemSeparator = ";";

typedef struct SSmithRunStat
{
    counter_t maxInt;
    counter_t gcdMaxDeg;
    counter_t gcdCount;
    counter_t time;
    counter_t sumCount;
    counter_t mulCount;
    counter_t divCount;
} SSmithRunStat;

std::ostream& SSmithRunsStat_outHeading(std::ostream & s, const std::string& prefix)
{
    s << 
        prefix << "time" << itemSeparator << 
        prefix << "max" << itemSeparator << 
//        prefix << "gcdcount" << itemSeparator << 
//        prefix << "gcddeg" << itemSeparator << 
        prefix << "sumcount" << itemSeparator << 
        prefix << "mulcount" << itemSeparator << 
        prefix << "divcount";
    return s;
}

std::ostream& operator << (std::ostream & s, const SSmithRunStat &v)
{
    s 
        << v.time
        << itemSeparator << v.maxInt 
//        << itemSeparator << v.gcdCount 
//        << itemSeparator << v.gcdMaxDeg
        << itemSeparator << v.sumCount
        << itemSeparator << v.mulCount
        << itemSeparator << v.divCount;
    return s;
}

typedef struct SSmithRunsStat
{
    SSmithRunStat stdAlg;
    SSmithRunStat polyAlg;
//    SSmithRunStat polyCoeffAlg;
    SSmithRunStat randAlg;
    counter_t polyAlgGCSum;
    counter_t polyAlgGCMul;
    counter_t polyAlgGCDiv;
} SSmithRunsStat;

std::ostream& SSmithRunsStat_outHeading(std::ostream & s)
{
    SSmithRunsStat_outHeading(s, "stdAlg_"); s << itemSeparator;
    SSmithRunsStat_outHeading(s, "polyAlg_"); s << itemSeparator;
//    SSmithRunsStat_outHeading(s, "polyCoeffAlg_"); s << itemSeparator;
    SSmithRunsStat_outHeading(s, "randAlg_"); s << itemSeparator;
    s << "sumGC" << itemSeparator << "mulGC" << itemSeparator << "divGC";
    return s;
}

std::ostream& operator << (std::ostream & s, const SSmithRunsStat &v)
{
    s   << v.stdAlg 
        << itemSeparator << v.polyAlg 
//        << itemSeparator << v.polyCoeffAlg 
        << itemSeparator << v.randAlg
        << itemSeparator << v.polyAlgGCSum
        << itemSeparator << v.polyAlgGCMul
        << itemSeparator << v.polyAlgGCDiv;
    return s;
}

template <class T>
void permute(matrix<T> &m, const T& maxRandom, size_t steps)
{
    size_t i, j;
//    tout << det(m) << " = det before permute\n";
    while (steps != 0)
    {
        i = rand() % m.nrows();
        j = rand() % m.nrows();
        if (i == j)
        {
            if (j == m.nrows()-1)
                j--;
            else
                j++;
        }
        m.addmult_rows(i, j, rand(maxRandom));
        i = rand() % m.ncols();
        j = rand() % m.ncols();
        if (i == j)
        {
            if (j == m.ncols()-1)
                j--;
            else
                j++;
        }
        m.addmult_cols(i, j, rand(maxRandom));
        steps--;
    }
//    tout << det(m) << " = det after permute\n";
}


typedef rational<big_int> coeff_type;
typedef sparse_polynom<coeff_type> el_type;

matrix<el_type> createRandomMatrix(size_t size, size_t maxPolyDeg, size_t maxPolyCoeff)
{
    size_t i, j;

    el_type p;
    for (i = 0; i < maxPolyDeg + 1; i++)
        p += el_type::monom(big_int(maxPolyCoeff), i);

    matrix<el_type> m(size, size);
    do {
        for (i = 0; i < m.nrows(); i++)
            for (j = 0; j < m.ncols(); j++)
                m(i, j) = rand(p);
    } while(el_type (factory<coeff_type>::null()) == det(m));

    return m;
}

matrix<el_type> createRandomMatrixLambda(size_t size, size_t maxPolyCoeff)
{
    matrix<el_type> res = createRandomMatrix(size, 0, maxPolyCoeff);
    return res - matrix<el_type>(size, el_type("x"), diag);
}

#define smithPolyTest_RESET_COUNTERS \
{ \
    counter_big_int.reset(); \
    counter_big_int_sum.reset(); \
    counter_big_int_mul.reset(); \
    counter_big_int_div.reset(); \
    counter_big_int_sum_GC.reset(); \
    counter_big_int_mul_GC.reset(); \
    counter_big_int_div_GC.reset(); \
}
//    counter_polygcd_maxdeg.reset();
//    counter_polygcd_count.reset();

#define smithPolyTest_ADD_STAT(alg, n) \
{ \
    addStat(stat.alg.maxInt, counter_big_int.getMax(), n+1); \
    addStat(stat.alg.sumCount, counter_big_int_sum.getSum(), n+1); \
    addStat(stat.alg.mulCount, counter_big_int_mul.getSum(), n+1); \
    addStat(stat.alg.divCount, counter_big_int_div.getSum(), n+1); \
    addStat(stat.alg.time, endTime-startTime, n+1); \
}
//        addStat(stat.randAlg.gcdCount, counter_polygcd_count.get(), n+1);
//        addStat(stat.randAlg.gcdMaxDeg, counter_polygcd_maxdeg.get(), n+1);

void addStat(counter_t& stat, counter_t runStat, counter_t nTry)
{
    if (1 == nTry)
        stat = runStat;
    else
    {
        if (stat < runStat)
            stat += (runStat-stat)/nTry;
        else
            stat -= (stat-runStat)/nTry;
    }
}

SSmithRunsStat smithTestRun(size_t size, size_t maxDeg, size_t maxCoeff, 
                            size_t nTry)
{
    SSmithRunsStat stat;
    tick_t startTime;
    tick_t endTime;

    size_t n = 0;
    while (n < nTry)
    {
        std::cout << "createRandomMatrix(" << 
            "size=" << size << 
            ", maxDeg=" << maxDeg << 
            ", maxCoeff=" << maxCoeff << ")\n";
        matrix<el_type> m = createRandomMatrix(size, maxDeg, maxCoeff);
//        matrix<el_type> m = createRandomMatrixLambda(size, maxCoeff);
        output_aligned(std::cout, m, "|| ", " ||", "  ");
        std::cout << "\n";
        std::cout.flush();

/*
        smithPolyTest_RESET_COUNTERS;
//        startTime = GetTick();
        matrix< el_type > spt = smithPoly_GC_T(m);
//        endTime = GetTick();
        smithPolyTest_ADD_STAT(polyCoeffAlg, n);
*/

        smithPolyTest_RESET_COUNTERS;
        startTime = GetTick();
        matrix< el_type > spr = smithPoly_rand(m);
        endTime = GetTick();
        smithPolyTest_ADD_STAT(randAlg, n);
        std::cout << "SMITH SPR:\n";
        output_aligned(std::cout, spr, "|| ", " ||", "  ");
        std::cout << "\n";
        std::cout.flush();

        smithPolyTest_RESET_COUNTERS;
        startTime = GetTick();
        matrix< el_type > s = smithPoly_std(m);
        endTime = GetTick();
        smithPolyTest_ADD_STAT(stdAlg, n);
        std::cout << "SMITH S:\n";
        output_aligned(std::cout, s, "|| ", " ||", "  ");
        std::cout << "\n";
        std::cout.flush();

        smithPolyTest_RESET_COUNTERS;
        startTime = GetTick();
        matrix< el_type > sp = smithPoly_GC(m);
        endTime = GetTick();
        smithPolyTest_ADD_STAT(polyAlg, n);
        addStat(stat.polyAlgGCSum, counter_big_int_sum_GC.getSum(), n+1);
        addStat(stat.polyAlgGCMul, counter_big_int_mul_GC.getSum(), n+1);
        addStat(stat.polyAlgGCDiv, counter_big_int_div_GC.getSum(), n+1);
        std::cout << "SMITH SP:\n";
        output_aligned(std::cout, sp, "|| ", " ||", "  ");
        std::cout << "\n";
        std::cout.flush();

/*
        for (size_t i = 0; i < spr.ncols(); i++)
            spr(i, i) = normalize(spr(i, i));
*/
        for (size_t i = 0; i < s.ncols(); i++)
        {
            s(i, i) = normalize(s(i, i));
            sp(i, i) = normalize(sp(i, i));
            spr(i, i) = normalize(spr(i, i));
//            spt(i, i) = normalize(spt(i, i));
        }

        if (s != spr || spr != sp /*|| st != spt*/)
        {
//            std::cout << "SMITH SPT:" << spt;
            std::cout << "SMITH SPR:\n";
            output_aligned(std::cout, spr, "|| ", " ||", "  ");
            std::cout << "\n";
            std::cout << "SMITH STD:\n";
            output_aligned(std::cout, s, "|| ", " ||", "  ");
            std::cout << "\n";
            std::cout << "SMITH POLY:\n";
            output_aligned(std::cout, sp, "|| ", " ||", "  ");
            std::cout << "\n";

            std::cout << "compatibility check failed";
//            throw "compatibility check failed";
        }

        std::cout << n << " ";
        n++;
    }
    std::cout << "\n";

    return stat;
}

int run()
{
    size_t n, maxDeg, maxCoeff, nTry;

    std::ofstream ofs;
    
    std::string name;
    FILE *stream;

/*
    name = "algebra,try1,n3-20,deg1,coef5,prob1000";
    ofs.open(std::string(name+std::string(".csv")).c_str());
    if (!ofs.is_open())
    {
        std::cout << "error opening log file";
        return 1;
    }
    stream = freopen( std::string(name+std::string(".out")).c_str(), "w", stdout );
    if( stream == NULL )
    {
        fprintf( stdout, "error on freopen\n" );
        return 1;
    }
    ofs << "n" << itemSeparator;
    SSmithRunsStat_outHeading(ofs);
    ofs << "\n";
    n = 3;
    maxDeg = 2;
    maxCoeff = 5;
    nTry = 1;
    for (n = 3; n < 20; n++)
    {
        SSmithRunsStat stat = smithTestRun(n, maxDeg, maxCoeff, nTry);
        ofs << n << itemSeparator << stat << "\n";
        ofs.flush();
    }
    ofs.close();

    return 0;
*/

/*
    name = "algebra,try3,n3,deg2-7,coef5";
    ofs.open(std::string(name+std::string(".csv")).c_str());
    if (!ofs.is_open())
    {
        std::cout << "error opening log file";
        return 1;
    }
    stream = freopen( std::string(name+std::string(".out")).c_str(), "w", stdout );
    if( stream == NULL )
    {
        fprintf( stdout, "error on freopen\n" );
        return 1;
    }
    ofs << "maxDeg" << itemSeparator;
    SSmithRunsStat_outHeading(ofs);
    ofs << "\n";
    n = 3;
    maxDeg = 3;
    maxCoeff = 5;
    nTry = 3;
    for (maxDeg = 2; maxDeg < 8; maxDeg++)
    {
        SSmithRunsStat stat = smithTestRun(n, maxDeg, maxCoeff, nTry);
        ofs << maxDeg << itemSeparator << stat << "\n";
        ofs.flush();
    }
    ofs.close();
*/

    
/*
    name = "algebra,try3,n3,deg3,coef2-32";
    ofs.open(std::string(name+std::string(".csv")).c_str());
    if (!ofs.is_open())
    {
        std::cout << "error opening log file";
        return 1;
    }
    stream = freopen( std::string(name+std::string(".out")).c_str(), "w", stdout );
    if( stream == NULL )
    {
        fprintf( stdout, "error on freopen\n" );
        return 1;
    }
    ofs << "maxCoeff" << itemSeparator;
    SSmithRunsStat_outHeading(ofs);
    ofs << "\n";
    n = 4;
    maxDeg = 4;
    maxCoeff = 5;
    nTry = 3;
    for (maxCoeff = 1<<2; maxCoeff < 1<<31; maxCoeff=maxCoeff<<1)
    {
        SSmithRunsStat stat = smithTestRun(n, maxDeg, maxCoeff, nTry);
        ofs << maxCoeff << itemSeparator << stat << "\n";
        ofs.flush();
    }
    ofs.close();
*/


    name = "algebra,try3,n2-20,deg3,coef5";
    ofs.open(std::string(name+std::string(".csv")).c_str());
    if (!ofs.is_open())
    {
        std::cout << "error opening log file";
        return 1;
    }
    stream = freopen( std::string(name+std::string(".out")).c_str(), "w", stdout );
    if( stream == NULL )
    {
        fprintf( stdout, "error on freopen\n" );
        return 1;
    }
    ofs << "n" << itemSeparator;
    SSmithRunsStat_outHeading(ofs);
    ofs << "\n";
    n = 3;
    maxDeg = 3;
    maxCoeff = 5;
    nTry = 3;
    for (n = 2; n < 20; n++)
    {
        SSmithRunsStat stat = smithTestRun(n, maxDeg, maxCoeff, nTry);
        ofs << n << itemSeparator << stat << "\n";
        ofs.flush();
    }
    ofs.close();

}

int main ()
{
    run();

    return 0;

    big_int a = 1064;
    big_int b= rand(a);
    // create matrix with rational elements from string
    matrix<rational<> > A = "((21, 3, 4), (3335, 6, 75), (81, 9, 10))";
    std::cout << "A = \n";
    output_aligned(std::cout, A, "|| ", " ||", "  ");
    std::cout << "\ninversion of A = \n";
    // calculate inverse matrix
    matrix<rational<> > Ainv(inverse(A));
    output_aligned(std::cout, Ainv, "|| ", " ||", "  ");
    // check inverse operation result
    std::cout
        << "\n\nthe inversion is valid: "
        << std::boolalpha << (A*Ainv).is_unit();

    // create identity matrix
    matrix<sparse_polynom<rational<> > > E(3, eye);
    // permute
    for (int i = 0; i < E.nrows(); i++)
        E.el(i, i) = monom<rational<> >(rand()%5, rand()%3);
    std::cout << "\nE = \n";
    output_aligned(std::cout, E, "|| ", " ||", "  ");
    // permute
    for (int i = 0; i < 3; i++)
    {
        E.addmult_rows(rand() % E.nrows(), rand() % E.nrows(), monom<rational<> >(rand()%5, rand()%3));
        E.addmult_cols(rand() % E.nrows(), rand() % E.nrows(), monom<rational<> >(rand()%5, rand()%3));
    }
/*
    E.el(1, 1) = monom<rational<> >(5, 2);
    E.el(2, 2) = monom<rational<> >(1, 3);
    E.addmult_rows(0, 1, monom<rational<> >(1, 2));
    E.addmult_rows(0, 2, monom<rational<> >(2, 3));
    E.addmult_rows(2, 0, monom<rational<> >(3, 2));
    E = transpose(E);
    E.swap_rows(0, 1);
    E = transpose(E);
*/
    std::cout << "\npermuted E = \n";
    output_aligned(std::cout, E, "|| ", " ||", "  ");
    // calculate Hermite normal form
    matrix<sparse_polynom<rational<> > > Eu;
    matrix<sparse_polynom<rational<> > > Ehermite = hermite(E);
    matrix<sparse_polynom<rational<> > > Esmith = smithPoly_std(E);
    std::cout << "\nEsmith = \n";
    output_aligned(std::cout, Esmith, "|| ", " ||", "  ");
    std::cout << "\nEhermite = \n";
    output_aligned(std::cout, Ehermite, "|| ", " ||", "  ");
//    std::cout << "\nE*Eu = \n";
//    output_aligned(std::cout, E*Eu, "|| ", " ||", "  ");
    // check hermite operation result
    sparse_polynom<rational<> > det = 1;
    for (int i = 0; i < Ehermite.nrows(); i++)
        det *= Ehermite.el(i, i);
    std::cout << "\nhermite det = " << det;
    sparse_polynom<rational<> > detS = 1;
    for (int i = 0; i < Esmith.nrows(); i++)
        detS *= Esmith.el(i, i);
    std::cout << "\nsmith det = " << detS;
/*
    std::cout
        << "\n\nthe hermite is valid: "
        << std::boolalpha << Ehermite == E*Eu;
*/


    return 0;
}
