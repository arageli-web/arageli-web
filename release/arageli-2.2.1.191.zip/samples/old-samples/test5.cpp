#include <iostream>
#include <ctime>

#include <arageli/rational.hpp>
#include <arageli/sparse_polynom.hpp>


using namespace Arageli;
using namespace std;
using Arageli::vector;
using std::rand;

namespace Arageli
{
	int _my_counter_1 = 0, _my_counter_2 = 0;
}


class Timing
{
public:
	
	Timing (bool on_a = true) : on_m(on_a), time_m(0)
	{ if(on_m)start_m = std::clock(); }
	
	bool is_on () const { return on_m; }
	
	void on (bool on_a = true)
	{
		if(on_m)return;
		start_m = std::clock();
		on_m = true;
	}
	
	void off ()
	{
		if(!on_m)return;
		time_m += double(std::clock() - start_m)/CLOCKS_PER_SEC;
		on_m = false;
	}

	double time () const
	{
		if(on_m)
			return time_m + double(std::clock() - start_m)/CLOCKS_PER_SEC;
		else
			return time_m;
	}

private:

	bool on_m;
	std::clock_t start_m;
	double time_m;
};



rational<> rand_rational (size_t len)
{
	return rational<>
	(
		big_int::random_with_length_or_less(len),
		big_int::random_with_length_or_less(len) + 1
	);
}


sparse_polynom<rational<> > rand_polynom (size_t maxdegree, size_t nummons, size_t lencoef)
{
	sparse_polynom<rational <> > res;
	for(size_t i = 0; i < nummons; ++i)
		res += monom<rational<> >(rand_rational(lencoef), rand()%(maxdegree+1));
	return res;
}


void test5_1 ()
{
	for(size_t i = 0; i < 10; ++i)
		cout << "\n" << rand_polynom(5, 3, 3);
}


void test5_2 ()
{
	for(size_t maxdegree = 1; maxdegree < 100; maxdegree *= 4)
		for(size_t lencoef = 3; lencoef < 100; lencoef *= 4)
		{
			Timing tm(false);
			for(size_t j = 0; j < 10; ++j)
			{
				sparse_polynom<rational <> > a, b;
				while(a.is_null())
					a = rand_polynom(maxdegree, maxdegree/3 + 1, lencoef);
				while(b.is_null())
					b = rand_polynom(maxdegree, maxdegree/3 + 1, lencoef);

				size_t repmax = 1000 / (a.size() + b.size());
				tm.on();
				for(size_t i = 0; i < repmax; ++i)
					a / b;
				tm.off();
			}

			cout
				<< "\nmaxdegree = " << maxdegree
				<< ", lencoef = " << lencoef
				<< ", time = " << tm.time();
		}
}


void test5_3 ()
{
	for(big_int i = -500; i < 500; ++i)
		for(big_int j = -500; j < 500; ++j)
			if(euclid(i, j) != euclid_binary(i, j))
				cout
					<< "\ni = " << i << ", j = " << j
					<< ", euclid(i, j) = " << euclid(i, j)
					<< ", euclid_binary(i, j) = " << euclid_binary(i, j);

}


int test5 () 
{
	test5_2();

	return 0;
}
