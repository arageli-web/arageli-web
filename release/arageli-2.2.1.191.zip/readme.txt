********************************************************************

              The Arageli Library Readme File.

********************************************************************

Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
Copyright (C) Sergey S. Lyalin, 2005--2006
University of Nizhni Novgorod, Russia.

Arageli is the C++ library and the package of programs for
computations in arithmetic, algebra, geometry, linear and integer
linear programming.  Arageli is a library for dealing with precise,
i.e. symbolic or algebraic, computations.  It contains a definition
to model basic algebraic structures such as integer numbers with
arbitrary precision, rational numbers, vectors, matrices,
polynomials etc.  Arageli is written in C++ and use power and
expressiveness of the language.

The home page: http://www.unn.ru/cs/arageli

********************************************************************


1. Software Requirements

To build the library and create documentation you need several
applications to be installed. Without some of them you will not
able to create some parts of the documentation or the library
itself.

In particular, you need:
	
1.1 To compile the library --- one of the C++ standard
compilers. We have checked compilation with
GCC 4.0.4 (Linux), GCC 3.2.2 (Linux),
Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 13
for 80x86 (included in Visual Studio .NET 2003),
Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 14
for 80x86 (included in Visual Studio .NET 2005),
Intel(R) C++ Compiler for 32-bit applications, Version 9.0
(Windows). Without this you cannot compile the library but can
compile the documentation.
	
1.2 To create all guides (tex-files) --- LaTeX installation.
We use MiKTeX. Note, some documentation files are written
in Russian.

1.3 To create guides with using lgrind --- lgrind installation.
Without this you cannot create some guide files with lgrind
directives.

1.4 To create references to sources --- doxygen installation.
Without this you cannot extract documented items from sources.

1.5 To create Arageli User's Guide --- 1.1, 1.2, 1.3 requirements,
Windows environment. Without windows shell you need to compile
a lot of files manually.

To create all parts of the distributive you should have all
programs referenced at 1.1--1.4. If you plan to contribute into
the library, we recommend you to have all this programs.

If you need some part of the library compiled (both library or
documentation), you can download it at the home page of Arageli
http://www.unn.ru/cs/arageli.


2. Building

All build scripts are located in build directory of
the distributive.  Choose proper platform directory for your
system and build all or a particular part of the distributive.

If you use Microsoft Visual Studio .NET 2003 you can build
solution that located at projects/vc7.1/arageli-all. Note if
you want to use tests project you should build ts system.
It�s located at tools/ts, build scripts: tools/ts/build/vc7.1
and VS2003 solution: tools/ts/projects/vc7.1/ts-all.

If you use Microsoft Visual Studio .NET 2005 you can build
solution that located at projects/vc8/arageli-all. Note if
you want to use tests project you should build ts system.
It�s located at tools/ts, VS2005 solution:
tools/ts/projects/vc8/ts-all.

If you are in some Linux system you can build the library,
test system and test set by the make utility. To make only
Arageli library go to build/linux-gcc directory and type:

    make arageli

or just

    make

After that, libarageli.a file appears in the bin directory
of the package. To make test set, type:

    make tests

After that, tests executive file appears in the bin directory
of the package. Note, while executing the last command
arageli and ts systems have being built. To make tests and
run them, type:

    make runtests

After that, tests.log file appears in the status directory
of the package. You can use CXXFLAGS, ARAGELICXXFLAGS and
TESTSCXXFLAGS variables to set specific command line parameters.


3. Additional documentation and feedback

Some ready-to-use documentation files already present in doc
directory of the distributive. Go to http://www.unn.ru/cs/arageli
for updates and news; mail questions, comments and suggestions on
support.arageli@gmail.com.
