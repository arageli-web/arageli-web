/*****************************************************************************
	
	io.cpp -- �������� ��. � ����� io.hpp.

	���� ���� �������� ������ ���������� Arageli.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005
	University of Nizhni Novgorod, Russia

*****************************************************************************/

#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_IO)

#include <iomanip>

#include "io.hpp"
#include "exception.hpp"
#include "cmp.hpp"


namespace Arageli
{


template <typename T, typename Ch, typename ChT>
std::basic_ostream<Ch, ChT>& output_polynom_internal_default
(std::basic_ostream<Ch, ChT>& out, const T& x)
{
	std::ios_base::fmtflags old_opts = out.flags();
	
	try { out << std::showpos << x; }
	catch(...)
	{
		out.flags(old_opts);
		throw;
	}

	out.flags(old_opts);
	return out;
}


template <typename T, typename Ch, typename ChT>
std::basic_ostream<Ch, ChT>& output_pow_default
(std::basic_ostream<Ch, ChT>& out, const T& x)
{
	// ��������������. ������ ��� ��� T, ��� ������� �������� is_negative.
	
	if(is_negative(x))out << "(" << x << ")";
	else out << x;
	return out;
}


template <typename T, typename Ch, typename ChT>
std::basic_istream<Ch, ChT>& input_polynom_internal_default
(std::basic_istream<Ch, ChT>& in, T& x)
{
	char ch;
	in >> ch;
	if(!in)return in;

	// WARNING. The following implementation is restricted.
	
	bool minus = false;
	
	if(ch == '-')
	{// aligne minus sign to the next non-space characters
		char ch1;
		in >> ch1;	// pass spaces and read next character
		if(!in)return in;
		in.putback(ch1);
		
		if(ch1 == '(')
			minus = true;
		else
			in.putback(ch);
	}
	else if(ch != '+')
	{
		in.putback(ch);
		in.clear(std::ios_base::failbit);
	}

	T res;
	in >> res;
	if(!in && !in.eof())return in;
	if(minus)opposite(&res);

	x = res;
	return in;
}


template <typename T, typename Ch, typename ChT>
std::basic_istream<Ch, ChT>& input_polynom_first_default
(std::basic_istream<Ch, ChT>& in, T& x)
{
	char ch;
	in >> ch;
	if(!in)return in;

	// WARNING. The following implementation is restricted.
	
	bool minus = false;
	
	if(ch == '-')
	{// aligne minus sign to the next non-space characters
		char ch1;
		in >> ch1;	// pass spaces and read next character
		if(!in)return in;
		in.putback(ch1);
		
		if(ch1 == '(')
			minus = true;
		else
			in.putback(ch);
	}
	else if(ch != '+')
		in.putback(ch);

	T res;
	in >> res;
	if(!in && !in.eof())return in;
	if(minus)opposite(&res);

	x = res;
	return in;
}


} // namespace Arageli


#endif // #ifndef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE

