/*****************************************************************************
	
	big_float.hpp -- Big Float Numbers implementation.

	This file is a part of the Arageli library.

	Copyright (C) Alexander Pshenichnikov, 2005--2006
	Copyright (C) Nikolay Santalov, 2005--2006
	
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
    \file
    Big Float Numbers implementation.

    This module implements a class big_float for representing
    Big Float Numbers, i.e. unlimited precision real numbers with
    floating point.

	Implementation of a Big Float Number.
    An instance of the data type big_float is
    a number of the form s*2^e where s is
    the significant and e is the exponent.
    Both are instances of type big_int.
    There are the special big_float values
    NaN (not a number), pZero, nZero (+0, -0),
    pInf, mInf (+infinity, -infinity).

    Arithmetic on big_float numbers uses two
    parameters: precision and rounding mode
*/

#include "config.hpp"

#include <iostream>
#include "std_import.hpp"
#include "big_int.hpp"

#ifndef _ARAGELI_big_float_h_
#define _ARAGELI_big_float_h_

#undef NAN

#pragma warning ( disable : 4018 )

namespace Arageli
{
 
/** \name Rounding Modes for big_float*/
//@{

// WARNING! Names are too simple and general.
// TODO: Rename or incapsulate them!
// WARNING! How does it combine with ISO C++ 18.2.1.3?

const int EXACT = 1; ///< Rounds to the closest value
const int ROUND = 2; ///< Uses rules of `'manual'' computations
const int TO_NEAREST = 3; ///< Rounds towards the nearest number
const int TO_ZERO = 4; ///< Rounds towards zero
const int TO_P_INF = 5; ///< Rounds towards +infinity
const int TO_M_INF = 6; ///< Rounds towards -infinity
const int TO_INF = 7;   ///< Rounds outwards zero
//@}

/** \name Special big_float numbers */
//@{

const int NAN = 1;
const int PINF = 2;
const int M_INF= 3;
const int P_ZERO = 4;
const int M_ZERO = 5;

//@}

const int PREC_MIN = 2;
const unsigned long PREC_MAX = _Internal::max_digit;
const unsigned long D_PREC_MAX = ( long ) (_Internal::max_digit * log ( 2.0l ) / log ( 10.0l )); 
 
class big_float
{

 public:

  big_float();                    ///< Constructor
  big_float(const char *str);           ///< Converts str to a big_float
  big_float(const big_float & b); ///< Makes a copy of a number
  big_float( const big_int &s, const big_int &e);
  big_float(double b );        ///< Converts b to a big number
  big_float(int i);				  ///< Converts b to a big number			
  ~big_float();                   ///< Destructor

  big_float & operator = (const big_float & b);     ///< Assignment
  big_float & operator = ( const double d );          ///< Assignment
  big_float & operator = ( const char *str );		  ///< Assignment
  big_float & operator = ( const int i );                ///< Assignment
  /// Returns the exponent
  big_int get_exponent() const;

  /// Returns the significant
  big_int get_significant() const;

  /// Reads a number
  friend std::ostream & operator << (std::ostream & s, const big_float & x);
  /// Writes a number
  friend std::istream & operator >> (std::istream & s, big_float & x);
  /// Formated output 
  void out ( std::ostream & os, char c = 'd' ) const ;
  /// Formated input
  void in ( std::istream &ins, char c = 'd' );

  /// Sets the global precision to p
  static void set_global_precision(long p); 
  /// Sets the global rounding mode
  static void set_round_mode (int m = TO_NEAREST);

  /// Compares two numbers
  /**
     Returns
      -  0  if a = b,
      - -1  if a < b,
      -  1  if a > b
   */
  friend int cmp(const big_float & a, const big_float & b);
  /// Test for equality
  friend int operator ==(const big_float & a, const big_float & b);
  /// Test for inequality
  friend int operator !=(const big_float & a, const big_float & b);
  /// Test for greater
  friend int operator > (const big_float & a, const big_float & b);
  /// Test for greater than or equal to
  friend int operator >=(const big_float & a, const big_float & b);
  /// Test for less
  friend int operator < (const big_float & a, const big_float & b);
  /// Test for less than or equal to
  friend int operator <=(const big_float & a, const big_float & b);

  friend big_float operator + (const big_float & a);       ///< Unary plus
  friend big_float operator - (const big_float & a);       ///< Unary minus

  /** Addition. Up to prec binary digits in rounding mode mode.
      The parameters prec and mode are optional and have the global defult
      values which can be set by set_global_precision and set_rounding_mode.*/
  friend big_float add(const big_float & b, const big_float & c, long prec, int mode);
  friend big_float add(const big_float & b, const big_float & c, long prec);
  friend big_float add(const big_float & b, const big_float & c);

  /** Subtraction. Up to prec binary digits in rounding mode mode
      The parameters prec and mode are optional and have the global defult
      values which can be set by set_global_precision and set_rounding_mode.*/
  friend big_float sub(const big_float & b, const big_float & c, long prec, int mode);
  friend big_float sub(const big_float & b, const big_float & c, long prec);
  friend big_float sub(const big_float & b, const big_float & c);

  /** Multiplication. Up to prec binary digits in rounding mode mode
      The parameters prec and mode are optional and have the global defult
      values which can be set by set_global_precision and set_rounding_mode.*/
  friend big_float mul(const big_float & b, const big_float & c, long prec, int mode);
  friend big_float mul(const big_float & b, const big_float & c, long prec);
  friend big_float mul(const big_float & b, const big_float & c);

  /** Divizion. Up to prec binary digits
      The parameters prec and mode are optional and have the global defult
      values which can be set by set_global_precision */
  friend big_float div(const big_float & b, const big_float & c, long prec, int mode);
  friend big_float div(const big_float & b, const big_float & c, long prec);
  friend big_float div(const big_float & b, const big_float & c);
  friend big_float divnu(const big_float & b, const big_float & c, long prec, int mode);
  friend big_float div_i ( const big_int & c );
  /** Square rooting. Up to prec binary digits
      The parameters prec and mode are optional and have the global defult
      values which can be set by set_global_precision.*/
  friend big_float fsqrt(const big_float & b,/* const big_float & c,*/ long prec, int mode);
  friend big_float fsqrt(const big_float & b,/* const big_float & c,*/ long prec);
  friend big_float fsqrt(const big_float & b/*, const big_float & c*/);
  friend big_float nfsqrt(const big_float & b,/* const big_float & c,*/ long prec, int mode);

  /// Binary plus. It is equivalent to add(b, c)
  friend big_float operator + (const big_float & b, const big_float & c);
  /// Binary minus. It is equivalent to sub(b, c)
  friend big_float operator - (const big_float & b, const big_float & c);
  /// Multiplication. It is equivalent to mul(b, c)
  friend big_float operator * (const big_float & b, const big_float & c);
  /// Divizion. It is equivalent to div(b, c)
  friend big_float operator / (const big_float & b, const big_float & c);
  /// Combined assignment-addition operator
  friend big_float & operator += (big_float & b, const big_float & c);
  /// Combined assignment-subtraction operator
  friend big_float & operator -= (big_float & b, const big_float & c);
  /// Combined assignment-multiplication operator
  friend big_float & operator *= (big_float & b, const big_float & c);
  /// Combined assignment-division operator
  friend big_float & operator /= (big_float & b, const big_float & c);

  /// Returns the next bigger integer
  friend big_float ceil  (const big_float & a);
  /// Returns the next smaller integer
  friend big_float floor (const big_float & a);
  /// Returns the fractal part of the number
  friend big_float frac  (const big_float & a);
  /// Returns the next bigger integer
  friend big_int iceil (const big_float & a);
  /// Returns the next smaller integer
  friend big_int ifloor(const big_float & a);
    
  /// Returns random number in the interval 0 <=x < 1 with prec lenght of mantissa
  friend big_float frandom  (long bits);
  /// Returns random number in the interval 0 <=x < 1 with prec lenght of mantissa
  friend big_float frandom  ( );
  /// Returns random number with prec lenght of mantissa and with exp as exponent 
  friend big_float frandom1 (long bits, const big_int & exp = 0 );

  int is_NaN();     ///< returns 1 iff the number is NaN
  int is_pInf();    ///< returns 1 iff the number is +Infinity
  int is_mInf();    ///< returns 1 iff the number is -Infinity
  int is_Inf();     ///< returns 1 iff the number is +Infinity or -Infinity
  int is_pZero();   ///< returns 1 iff the number is +0
  int is_mZero();   ///< returns 1 iff the number is -0
  int is_Zero();    ///< returns 1 iff the number is +0 or -0
  int is_Special(); ///< returns 1 iff the number is Nan, Infinity or 0
   	
 private:
  void normalize_1 ( long prec = big_float::prec, long mode = big_float::mode );
  
  // the following type is used inside the bigfloat unit and implements
  // the storage for a Big Float Number

  big_int e; ///< exponent
  big_int s; //< significant

  int special;  
  
  static long prec; ///< Global bits precision for big_float numbers
  static long mode; ///< Global big_float rounding mode
};


inline big_float abs (const big_float& x)
{ return is_negative(x) ? -x : x; }


template <typename Outiter>
inline void generate_range_helper (big_float& t1, const big_float& t2, Outiter outiter)
{ generate_range_helper_wo_inc(t1, t2, outiter); }


inline big_float & operator+= (big_float & b, const big_float & c)
{ return b = b + c; }

inline big_float & operator-= (big_float & b, const big_float & c)
{ return b = b - c; }

inline big_float & operator*= (big_float & b, const big_float & c)
{ return b = b * c; }

inline big_float & operator/= (big_float & b, const big_float & c)
{ return b = b / c; }



}

#endif
