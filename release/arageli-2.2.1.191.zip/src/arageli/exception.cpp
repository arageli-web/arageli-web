/*****************************************************************************
	
	exception.cpp -- See declarations in exception.hpp.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	See description for exception.hpp file.
*/


#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_exception)

// REFERENCE ADDITIONAL HEADERS HERE


namespace Arageli
{

// PLACE ALL TEMPLATE NOT INLINE IMPLEMENTATIONS HERE

}


#else	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...


#include "exception.hpp"


namespace Arageli
{


void exception::add_location
(
	const std::string& src,
	std::size_t line,
	const std::string& desc
)
{
	std::ostringstream buf;

	buf
		<< "Location:"
		<< "\n\tSource: " << src
		<< "\n\tLine: " << line;

	if(!desc.empty())
		buf << "\n\tDescription: " << desc;

	add_description(buf.str());
}


std::string exception::msg () const
{
	std::string res = std::string("Arageli exception \"") + typeid(*this).name() + "\"";
	for
	(
		descriptions_type::const_iterator i = descriptions_m.begin();
		i != descriptions_m.end();
		++i
	)
		(res += "\n") += *i;

	return res;
}


void assert_failed::output (std::ostream& out) const
{
	out
		<< "Arageli assertion failed."
		<< "\n\tSource: " << source()
		<< "\n\tLine: " << line ()
		<< "\n\tExpression: " << expr()
		<< "\nAdditional information:\n"
		<< exception::msg();
}



}


#endif	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...
