/*****************************************************************************
	
	io.hpp

	���� ���� �������� ������ ���������� Arageli.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005
	University of Nizhni Novgorod, Russia

*****************************************************************************/


#ifndef _ARAGELI_io_hpp_
#define _ARAGELI_io_hpp_

#include "config.hpp"

#include <iostream>


namespace Arageli
{

	
/// Default ouputting method for subexpression as the first coefficient in a polynomial.
template <typename T, typename Ch, typename ChT>
inline std::basic_ostream<Ch, ChT>& output_polynom_first_default
(std::basic_ostream<Ch, ChT>& out, const T& x)
{ return out << x; }

/// Default ouputting method for subexpression as an internal coefficient in a polynomial.
template <typename T, typename Ch, typename ChT>
std::basic_ostream<Ch, ChT>& output_polynom_internal_default
(std::basic_ostream<Ch, ChT>& out, const T& x);

/// Default ouputting method for subexpression as a degree of variable in a polynomial.
template <typename T, typename Ch, typename ChT>
std::basic_ostream<Ch, ChT>& output_pow_default
(std::basic_ostream<Ch, ChT>& out, const T& x);

/// Default inputting method for subexpression as the first coefficient in a polynomial.
template <typename T, typename Ch, typename ChT>
std::basic_istream<Ch, ChT>& input_polynom_first_default
(std::basic_istream<Ch, ChT>& in, T& x);

/// Default inputting method for subexpression as an internal coefficient in a polynomial.
template <typename T, typename Ch, typename ChT>
std::basic_istream<Ch, ChT>& input_polynom_internal_default
(std::basic_istream<Ch, ChT>& in, T& x);

/// Default inutting method for subexpression as a degree of variable in a polynomial.
template <typename T, typename Ch, typename ChT>
inline std::basic_istream<Ch, ChT>& input_pow_default
(std::basic_istream<Ch, ChT>& in, T& x)
{ return in >> x; }


template <typename T, typename Ch, typename ChT>
inline std::basic_ostream<Ch, ChT>& output_polynom_first
(std::basic_ostream<Ch, ChT>& out, const T& x)
{ return output_polynom_first_default(out, x); }

template <typename T, typename Ch, typename ChT>
inline std::basic_ostream<Ch, ChT>& output_polynom_internal
(std::basic_ostream<Ch, ChT>& out, const T& x)
{ return output_polynom_internal_default(out, x); }

template <typename T, typename Ch, typename ChT>
inline std::basic_ostream<Ch, ChT>& output_pow
(std::basic_ostream<Ch, ChT>& out, const T& x)
{ return output_pow_default(out, x); }

template <typename T, typename Ch, typename ChT>
inline std::basic_istream<Ch, ChT>& input_polynom_first
(std::basic_istream<Ch, ChT>& in, T& x)
{ return input_polynom_first_default(in, x); }

template <typename T, typename Ch, typename ChT>
inline std::basic_istream<Ch, ChT>& input_polynom_internal
(std::basic_istream<Ch, ChT>& in, T& x)
{ return input_polynom_internal_default(in, x); }

template <typename T, typename Ch, typename ChT>
inline std::basic_istream<Ch, ChT>& input_pow
(std::basic_istream<Ch, ChT>& in, T& x)
{ return input_pow_default(in, x); }


} // namespace Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_IO
	#include "io.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_IO
#endif


#endif  //  #ifndef _ARAGELI_io_hpp_
