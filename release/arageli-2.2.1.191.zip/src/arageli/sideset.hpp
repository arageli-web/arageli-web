/*****************************************************************************
	
	sideset.hpp -- A representation of polyhedron side set with iterators 
		for ordered enumeration and other routines.

	This file is a part of the Arageli library.

	Copyright (C) Sergey S. Lyalin, 2006

*****************************************************************************/

/**
	\file
	This file contains a representation of polyhedron side set with iterators
	for ordered enumeration and other miscellaneous routines.

	WARINING! Definitions in this file is temporary. Don't use them!
*/


#ifndef _ARAGELI_sideset_hpp_
#define _ARAGELI_sideset_hpp_

#include <cstddef>

#include "config.hpp"

#include "vector.hpp"


namespace Arageli
{


/// WARNING! Temporary implimentation. Only facets with vertices indexes.
/** Don't use it! */
class sideset
{
	typedef vector<vector<std::size_t> > VVs;
	VVs indices;

public:

	typedef VVs::const_iterator const_iterator;
	typedef VVs::element_type vertex_indices_set;

	sideset (const VVs& x) : indices(x) {}

	VVs::const_iterator begin () const { return indices.begin(); }
	VVs::const_iterator end () const { return indices.end(); }
	
};



} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_sideset
	#include "sideset.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_sideset
#endif

#endif	// #ifndef _ARAGELI_sideset_hpp_
