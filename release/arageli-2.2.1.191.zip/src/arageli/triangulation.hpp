/*****************************************************************************
	
	triangulation.hpp -- routines for triangulation of polyhedral cone and
		general polyhedron.

	This file is a part of the Arageli library.

	Copyright (C) Sergey S. Lyalin, 2006

*****************************************************************************/

/**
	\file
	This file contains a set of function for triangulation polyhedral cone
	and general polyhedron.
*/


#ifndef _ARAGELI_triangulation_hpp_
#define _ARAGELI_triangulation_hpp_

#include "config.hpp"

// REFERENCE ADDITIONAL HEADERS HERE


namespace Arageli
{


namespace ctrl
{

struct triangulate_simple_1_idler
{
	class abort : public ctrl::abort {};

	template <typename Q>
	void preamble (const Q& q) const {}

	template <typename Row, typename Q>
	void select_vertex (const Row& row, const Q& q) const {}

	template <typename Row, typename Vs, typename Q>
	void select_vertex
	(const Row& row, const Vs& newvertices, const Q& q) const {}

	template <typename Row, typename Vs, typename Q>
	void finish_vertex
	(const Row& row, const Vs& vertices, const Q& q) const {}

	template <typename Col, typename Vs, typename Q>
	void select_col
	(const Col& col, const Vs& vertices, const Q& q) const {}

	template <typename Col, typename Vs, typename Q>
	void select_side
	(const Col& col, const Vs& newvertices, const Q& q) const {}

	template <typename Sm, typename Vs, typename Q, typename Tr>
	void new_simplex
	(
		const Sm& simplex, const Vs& vertices,
		const Q& q, const Tr& tr
	) const {}

	template <typename Q, typename Tr>
	void conclusion (const Q& q, const Tr& tr) const {}
};

} // namespace ctrl


/// Triangulates a cone with structure matrix q.
/** Triangulates a polyhedral cone. q is matrix of the structure of a cone.
	In particular this matrix is obtained from Motzkin-Burger algorithm as
	q-matrix. Values itself in that matrix is not matter, only equality
	with zero is valuable. Output matrix tr contains dim columns and several
	rows, number of which is equal to number of simpixes founded in
	the polyhedral cone. Matrix tr contains indexes of vertexes that include
	in each simplex according to an order in q matrix.
	TEMPORARY LIMITATION: All subspace generators should'n be included
	to q matrix. */
template
<
	typename Q,
	typename Dim1,
	typename TR,
	typename Dim2,
	typename Ctrler
>
void triangulate_simple_1
(
	const Q& q,
	const Dim1& dim,
	TR& tr,
	const Dim2& subspdim,
	Ctrler ctrler
);


/// Triangulates a cone with the relations matrix q.
/** See full version of this function. */
template
<
	typename Q,
	typename Dim1,
	typename TR,
	typename Dim2
>
inline void triangulate_simple_1 (const Q& q, const Dim1& dim, TR& tr, const Dim2& subspdim)
{ triangulate_simple_1(q, dim, tr, subspdim, ctrl::triangulate_simple_1_idler()); }


/// Triangulates a pointed cone with the relations matrix q.
/**	See full version of this function. */
template
<
	typename Q,
	typename Dim1,
	typename TR
>
inline void triangulate_simple_1 (const Q& q, const Dim1& dim, TR& tr)
{ triangulate_simple_1(q, dim, tr, 0, ctrl::triangulate_simple_1_idler()); }



} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_triangulation
	#include "triangulation.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_triangulation
#endif

#endif	// #ifndef _ARAGELI_triangulation_hpp_
