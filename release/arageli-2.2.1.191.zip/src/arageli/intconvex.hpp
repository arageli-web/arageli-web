/*****************************************************************************
	
	intconvex.hpp -- routines to find convex hull of integer points of
		a polyhedron.

	This file is a part of the Arageli library.

	Copyright (C) Sergey S. Lyalin, 2006
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	This file contains the primitive algorithm to find convex hull of integer
	points of a polyhedron.
*/


#ifndef _ARAGELI_intconvex_hpp_
#define _ARAGELI_intconvex_hpp_

#include "config.hpp"

// REFERENCE ADDITIONAL HEADERS HERE


namespace Arageli
{


/// A convex hull of integer points of a polyhedron.
/** This function takes a set of generatrices of the base cone of a polyhedron.
	And it returns a set of generatrices of the base cone of convex hull of
	integer pointes of that polyhedron. This function implements a primitive
	algorithm and finds the convex hull	very slow. It's deathly algorithm!
	Source of the idea: Emelichev V.A., Kovalev M.M., Kravcov M.K.
	Mnogogranniki, grafy, optimizacija (Nauka, 1981)(Russian), pp. 107--110.
	System of generatrices in gen is not necessarily minimal; and retrieved
	system intgen is not necessarily minimal (actually it's very big).
	WARINING! Type of elements of gen should be integer. */
template <typename Gen, typename IntGen>
void intconvex_simple (const Gen& gen, IntGen& intgen);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_intconvex
	#include "intconvex.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_intconvex
#endif

#endif	// #ifndef _ARAGELI_intconvex_hpp_
