/*****************************************************************************
	
	hermite.hpp -- the Hermite form of a matrix.

	This file is a part of the Arageli library.

	Created:    2005/10/18    23:48

	Copyright (C) Andrey Somsikov, 2005--2006
	Copyright (C) Anna Bestaeva, 2006

*****************************************************************************/

/**
	\file
	This file contains a set of functions for producing the Hermite form H of
	a matrix.
*/


#ifndef _ARAGELI_hermite_hpp_
#define _ARAGELI_hermite_hpp_

#include <cstddef>

#include "config.hpp"

#include "hermite/storjohann.hpp"
#include "hermite/classic.hpp"
#include "hermite/hafner.hpp"
#include "hermite/domich.hpp"
#include "vector.hpp"
#include "matrix.hpp"

namespace Arageli
{


// WARNING! Explicit matrix type.
/// The old original function for producing Hermite form.
template <class T>
matrix<T> hermite_old (const matrix<T> &m_);


///	Produces the upper Hermite form H of an integer matrix A.
/**
	Returns H, U:
	U is unimodular princpal left transform such that H = U * A;
 */
template
<
	typename MA,
	typename MH,
	typename MU
>
inline void hermite_upper
(
	const MA &A,
	MH &H,
	MU &U
)
{
	typedef typename MA::element_type T_A;
	
	vector<std::size_t, false> basis;
	T_A det; 
	hermite_storjohann(A, H, U, basis, det);
	//classic_hermite(A, H, U, basis, det);
	
	ARAGELI_ASSERT_1(H == U*A);
}


///	Produces the lower Hermite form H of an integer matrix A.
/**
	Returns H, U:
	U is unimodular princpal rigth transform such that H = A * U;
 */
template
<
	typename MA,
	typename MH,
	typename MU
>
inline void hermite_lower
(
	const MA &A,
	MH &H,
	MU &U
)
{
	typedef typename MA::element_type T_A;
	
	matrix<T_A, false> A2 = A;
	A2.transpose();
	hermite_upper(A2, H, U);
	H.transpose();
	U.transpose();

	ARAGELI_ASSERT_1(H == A*U);
}


///	Produces the upper Hermite form H of an integer matrix A.
template <typename M>
inline M hermite (const M& A)
{
	typedef typename M::element_type T;
	
	vector<std::size_t, false> basis;
	matrix<T, false> Q;
	matrix<T, true> B;
	T det;
    
	hermite_storjohann(A, B, Q, basis, det); 
	//classic_hermite(A, B, Q, basis, det);
	return B;
}


///	Produces the unimodular princpal left transform U such that U*A is a Hermite form of an integer matrix A.
template <typename M>
inline M hermite_transform_matrix (const M& A)
{
	typedef typename M::element_type T;
	
	matrix<T, false> B;
	matrix<T, true> Q;
	vector<std::size_t, false> basis;
	T det;
	
    hermite_storjohann(A, B, Q, basis, det); 
	// classic_hermite(A, B, Q, basis, det);
    return Q;
}


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite
	#include "hermite.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite
#endif

#endif	// #ifndef _ARAGELI_hermite_hpp_
