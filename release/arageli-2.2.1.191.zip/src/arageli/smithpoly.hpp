/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       smithpoly.hpp
//  Created:    2005/10/18    0:50
//
//  Author: Andrey Somsikov
*/

#ifndef __ARAGELI_smithpoly_hpp__
#define __ARAGELI_smithpoly_hpp__

#include "config.hpp"
#include <stdlib.h>

namespace Arageli
{

/*
template <typename T>
matrix<T> smithPoly_rand(const matrix<T>& m);
*/

} // namespace Arageli

#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_smithpoly
	#include "smithpoly.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_smithpoly
#endif

#endif /*__ARAGELI_smithpoly_hpp__*/
/* End of file smithpoly.hpp */
