/*****************************************************************************
	
	bareiss.hpp -- Gauss-Jordan and Gauss forms of an interger matrix.

	This file is a part of the Arageli library.

	Copyright (C) Anna Bestaeva, 2006

*****************************************************************************/

/**
	\file
	Gauss-Jordan and Gauss forms of an interger matrix. Rank and determinant
	calculation based on those functions.
*/


#ifndef _ARAGELI_bareiss_hpp_
#define _ARAGELI_bareiss_hpp_

#include "config.hpp"


namespace Arageli
{


///	Produces the Gauss-Jordan form B of an integer matrix A.
/**
	Returns B, Q, basis, det:
	- Q is such that B = Q * A;
	- r = basis.size() is a rank of A;
	- B.sumbatrix(mesh_grid(1,r), basis) is the r-by-r non-singular
	diagonal matrix;
	- det is the basis minor of A.
 */
template
<
	typename MA,
	typename MB,
	typename MQ,
	typename Basis,
	typename T_det
>
void bareiss
(
	const MA& A,
	MB& B,
	MQ& Q,
	Basis& basis,
	T_det& det
);


///	Produces the Gauss form B of an integer matrix A.
/**
	Returns P, Q, rank, det:
	- P, Q permutation matrices: (P * A * Q).sumbatrix(mesh_grid(1,r), mesh_grid(1,r))
	is the r-by-r non-singular matrix;
	- rank is a rank of A;
	- det is the basis minor of A.
 */
template
<
	typename MA,
	typename MP,
	typename MQ,
	typename Rank,
	typename T_det
>
void bareiss_pq
(	const MA& A,
	MP& P,
	MQ& Q,
	Rank& rank,	// WARNING! Maybe just templated typename will be better.
	T_det& det
);


template <typename MA> MA adjoint (const MA& A);


template 
<
	typename MA,
	typename MP,
	typename T_det
>
void adjoint 
(
	const MA& A,
	MP& P,
	T_det& det
);


template <typename MA>
typename MA::element_type det_brs (const MA& A);


template <typename MA>
typename MA::size_type rank_brs (const MA& A);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_bareiss
	#include "bareiss.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_bareiss
#endif

#endif	// #ifndef _ARAGELI_bareiss_hpp_
