/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       auto_link.hpp
//  Created:    2005/10/10    21:18
//
//  Author: Andrey Somsikov
*/

#ifndef __ARAGELI_auto_link_hpp__
#define __ARAGELI_auto_link_hpp__

#define ARAGELI_STRINGIZE(macro) ARAGELI_DO_STRINGIZE(macro)
#define ARAGELI_DO_STRINGIZE(name) #name

namespace Arageli
{

#ifndef ARAGELI_SOURCE
	#pragma comment(lib, ARAGELI_STRINGIZE(ARAGELI_LIB_NAME) ".lib")
#endif
    
// undef any macros we have defined
#undef ARAGELI_LIB_NAME

} // namespace Arageli

#endif /*__ARAGELI_auto_link_hpp__*/
/* End of file auto_link.hpp */
