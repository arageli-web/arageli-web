/*****************************************************************************
	
	function_traits.hpp -- additional information about functions
		and operators.

	This file is part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005--2006
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/** \file

	This file contains some structures to represent additional
	information about functions and operators. That information likes that:
	argument types, result type, side effect, etc.
	That infrormation is used by some parts of the library. Note that
	here is only general implementation of the structures, it is
	not specialized for concrete types and makes some assumptions for
	specialized types. If function for your types doesn't fit to this
	implementaion you need to implement own specialization of one or all
	forms of function_traits templates.
*/


#ifndef _ARAGELI_function_traits_hpp_
#define _ARAGELI_function_traits_hpp_

#include "config.hpp"
#include "type_opers.hpp"
#include "type_traits.hpp"


//****************************************************************************


namespace Arageli
{

/// Holds additional information about unary function.
/** Use it to build your own function_traits. */
template
<
	typename TAG,
	typename ARG,
	typename RETTYPE,
	bool ALARG,
	bool SE
>
struct unary_function_traits_base
{
	static const bool is_specialized = true;
	typedef RETTYPE result_type;
	typedef ARG argument_type;
	typedef TAG tag;
	static const bool alternates_argument = ALARG;
	static const bool has_side_effect = SE;
};


template
<
	typename TAG,
	typename ARG1, typename ARG2,
	typename RETTYPE, 
	bool ALARG1, bool ALARG2,
	bool SE
>
struct binary_function_traits_base
{
	static const bool is_specialized = true;
	typedef RETTYPE result_type;
	typedef ARG1 first_argument_type;
	typedef ARG2 second_argument_type;
	typedef TAG tag;
	static const bool alternates_first_argument = ALARG1;
	static const bool alternates_second_argument = ALARG2;
	static const bool has_side_effect = SE;
};


template
<
	typename TAG,
	typename ARG1, typename ARG2, typename ARG3,
	typename RETTYPE, 
	bool ALARG1, bool ALARG2, bool ALARG3,
	bool SE
>
struct ternary_function_traits_base
{
	static const bool is_specialized = true;
	typedef RETTYPE result_type;
	typedef ARG1 first_argument_type;
	typedef ARG2 second_argument_type;
	typedef ARG3 third_argument_type;
	typedef TAG tag;
	static const bool alternates_first_argument = ALARG1;
	static const bool alternates_second_argument = ALARG2;
	static const bool alternates_third_argument = ALARG3;
	static const bool has_side_effect = SE;
};


namespace function_tag
{

// Function classes (categories).
	
class function {};

class unary : public virtual function {};
class binary : public virtual function {};
class ternary : public virtual function {};

class arithmetic : public virtual function {};
class logical : public virtual function {};
class bitwise : public virtual function {};

class compare : public virtual function {};
class each_compare : public binary, public compare {};
class all_compare : public binary, public compare {};

// Concrete functions.

class indirection : public unary {};
class address : public unary {};

class unary_plus : public unary, public arithmetic {};
class unary_minus : public unary, public arithmetic {};
class logical_not : public unary, public logical {};
class bitwise_not : public unary, public bitwise {};
class prefix_increment : public unary, public arithmetic {};
class prefix_decrement : public unary, public arithmetic {};
class postfix_increment : public unary, public arithmetic {};
class postfix_decrement : public unary, public arithmetic {};

class parentheses_0 : public unary {};
class parentheses_1 : public binary {};
class parentheses_2 : public ternary {};
class subscript : public binary {};

// TODO: CLASSIFY THE FOLLOWING TAGS!

class plus {};
class minus {};
class multiplies {};
class divides {};
class modulus {};
class logical_or {};
class logical_and {};
class equal_to : public binary, public compare {};
class not_equal_to : public binary, public compare {};
class greater : public binary, public compare {};
class less : public binary, public compare {};
class greater_equal : public binary, public compare {};
class less_equal : public binary, public compare {};
class bitwise_or {};
class bitwise_and {};
class bitwise_xor {};
class shift_left {};
class shift_right {};

class assign {};
class assign_plus {};
class assign_minus {};
class assign_multiplies {};
class assign_divides {};
class assign_modulus {};
class assign_bitwise_or {};
class assign_bitwise_and {};
class assign_bitwise_xor {};
class assign_shift_left {};
class assign_shift_right {};

typedef assign_plus right_assign_plus;
typedef assign_minus right_assign_minus;
typedef assign_multiplies right_assign_multiplies;
typedef assign_divides right_assign_divides;
typedef assign_modulus right_assign_modulus;
typedef assign_bitwise_or right_assign_bitwise_or;
typedef assign_bitwise_and right_assign_bitwise_and;
typedef assign_bitwise_xor right_assign_bitwise_xor;
typedef assign_shift_left right_assign_shift_left;
typedef assign_shift_right right_assign_shift_right;

class left_assign_plus {};
class left_assign_minus {};
class left_assign_multiplies {};
class left_assign_modulus {};
class left_assign_bitwise_or {};
class left_assign_bitwise_and {};
class left_assign_bitwise_xor {};
class left_assign_shift_left {};
class left_assign_shift_right {};

class cmp : public binary, public compare {};

class each_cmp : public each_compare {};

class each_equal_to : public each_compare {};
class each_not_equal_to : public each_compare {};
class each_greater : public each_compare {};
class each_less : public each_compare {};
class each_greater_equal : public each_compare {};
class each_less_equal : public each_compare {};
class all_equal_to : public all_compare {};
class all_not_equal_to : public all_compare {};
class all_greater : public all_compare {};
class all_less : public all_compare {};
class all_greater_equal : public all_compare {};
class all_less_equal : public all_compare {};

template <typename T>
struct omit_each;

#define ARAGELI_FUNCTION_TAG_AG2EL(NAME, PREFIX)	\
	template <>										\
	struct omit_each<PREFIX##_##NAME>				\
	{ typedef NAME type; };

ARAGELI_FUNCTION_TAG_AG2EL(cmp, each)
ARAGELI_FUNCTION_TAG_AG2EL(equal_to, each)
ARAGELI_FUNCTION_TAG_AG2EL(not_equal_to, each)
ARAGELI_FUNCTION_TAG_AG2EL(less, each)
ARAGELI_FUNCTION_TAG_AG2EL(greater, each)
ARAGELI_FUNCTION_TAG_AG2EL(less_equal, each)
ARAGELI_FUNCTION_TAG_AG2EL(greater_equal, each)
ARAGELI_FUNCTION_TAG_AG2EL(equal_to, all)
ARAGELI_FUNCTION_TAG_AG2EL(not_equal_to, all)
ARAGELI_FUNCTION_TAG_AG2EL(less, all)
ARAGELI_FUNCTION_TAG_AG2EL(greater, all)
ARAGELI_FUNCTION_TAG_AG2EL(less_equal, all)
ARAGELI_FUNCTION_TAG_AG2EL(greater_equal, all)


template <typename T> struct compare_category
{ typedef function type; };

#define ARAGELI_FUNCTION_TAG_CMPCAT(TAG, CATEGORY)	\
	template <> struct compare_category<TAG>		\
	{ typedef CATEGORY type; };

ARAGELI_FUNCTION_TAG_CMPCAT(each_equal_to, each_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(each_not_equal_to, each_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(each_greater, each_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(each_less, each_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(each_greater_equal, each_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(each_less_equal, each_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(all_equal_to, all_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(all_not_equal_to, all_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(all_greater, all_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(all_less, all_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(all_greater_equal, all_compare)
ARAGELI_FUNCTION_TAG_CMPCAT(all_less_equal, all_compare)


}


// TODO: IMPLEMENT is_subcategory_of for ALL OTHER COMBINATIONS OF FUNCTION TAGS

//#define ARAGELI_FUNCTION_TAG_SUBCLASSING(SUBCLASS, CLASS)		\
//	template <>													\
//	struct is_subcategory_of									\
//		<function_tag::SUBCLASS, function_tag::CLASS>			\
//	{															\
//		static const bool bvalue = true;						\
//		typedef true_type value_type;							\
//		static const true_type value;							\
//	};

//ARAGELI_FUNCTION_TAG_SUBCLASSING(less, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(greater, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(less_equal, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(greater_equal, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(equal_to, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(not_equal_to, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(cmp, compare)
//
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_equal_to, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_not_equal_to, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_greater, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_less, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_greater_equal, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_less_equal, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_equal_to, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_not_equal_to, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_greater, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_less, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_greater_equal, compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_less_equal, compare)
//
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_equal_to, each_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_not_equal_to, each_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_greater, each_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_less, each_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_greater_equal, each_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(each_less_equal, each_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_equal_to, all_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_not_equal_to, all_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_greater, all_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_less, all_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_greater_equal, all_compare)
//ARAGELI_FUNCTION_TAG_SUBCLASSING(all_less_equal, all_compare)


template <typename TAG, typename ARG>
struct unary_function_traits
{
	static const bool is_specialized = false;
	typedef void result_type;
	typedef ARG argument_type;
	typedef TAG tag;
	static const bool alternates_argument = false;
	static const bool has_side_effect = false;
};


template <typename TAG, typename ARG1, typename ARG2>
struct binary_function_traits
{
	static const bool is_specialized = false;
	typedef void result_type;
	typedef ARG1 first_argument_type;
	typedef ARG2 second_argument_type;
	typedef TAG tag;
	static const bool alternates_first_argument = false;
	static const bool alternates_second_argument = false;
	static const bool has_side_effect = false;
};


template <typename TAG, typename ARG1, typename ARG2, typename ARG3>
struct ternary_function_traits
{
	static const bool is_specialized = false;
	typedef void result_type;
	typedef ARG1 first_argument_type;
	typedef ARG2 second_argument_type;
	typedef ARG3 third_argument_type;
	typedef TAG tag;
	static const bool alternates_first_argument = false;
	static const bool alternates_second_argument = false;
	static const bool alternates_third_argument = false;
	static const bool has_side_effect = false;
};


// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// WARNING! PROBLEM: In this implementaion we have argument types the same
// as type of paramenter of the template. Actually it is not true.
// For example unary_function_traits<prefix_increment, T>::argument_type is
// just 'T', but need 'T&' if T is not in the form 'P&' for some P.

#define ARAGELI_UNARY_FUNCTION_TRAITS(MNEM, RETTYPE, ALARG, SE)	\
	template <typename Arg>										\
	struct unary_function_traits<function_tag::MNEM, Arg> :		\
		public unary_function_traits_base						\
		<function_tag::MNEM, Arg, RETTYPE, ALARG, SE>			\
	{};


#define ARAGELI_BINARY_FUNCTION_TRAITS(MNEM, RETTYPE, ALARG1, ALARG2, SE)	\
	template <typename Arg1, typename Arg2>									\
	struct binary_function_traits<function_tag::MNEM, Arg1, Arg2> :			\
		public binary_function_traits_base									\
		<function_tag::MNEM, Arg1, Arg2, RETTYPE, ALARG1, ALARG2, SE>		\
	{};

#define ARAGELI_TERNARY_FUNCTION_TRAITS(MNEM, RETTYPE, ALARG1, ALARG2, ALARG3, SE)	\
	template <typename Arg1, typename Arg2, typename Arg3>							\
	struct ternary_function_traits<function_tag::MNEM, Arg1, Arg2, Arg3> :			\
		public ternary_function_traits_base											\
		<function_tag::MNEM, Arg1, Arg2, Arg3, RETTYPE, ALARG1, ALARG2, ALARG3, SE>	\
	{};

#define ARAGELI_EACH_CMP_FUNCTION_TRAITS(MNEM, ALARG1, ALARG2, SE)	\
	template <typename Arg1, typename Arg2>							\
	struct binary_function_traits<function_tag::MNEM, Arg1, Arg2> :	\
		public binary_function_traits_base							\
		<															\
			function_tag::MNEM, Arg1, Arg2,							\
			typename type_traits<Arg1>::							\
				template other_element_type_refcnt<bool, true>::type,	\
			ALARG1, ALARG2, SE										\
		>															\
	{};



ARAGELI_UNARY_FUNCTION_TRAITS
	(indirection, typename omit_asterisk<Arg>::type, false, false);
ARAGELI_UNARY_FUNCTION_TRAITS(address, Arg*, false, false);
ARAGELI_UNARY_FUNCTION_TRAITS(unary_plus, typename omit_ref<Arg>::type, false, false);
ARAGELI_UNARY_FUNCTION_TRAITS(unary_minus, typename omit_ref<Arg>::type, false, false);
ARAGELI_UNARY_FUNCTION_TRAITS(logical_not, bool, false, false);
ARAGELI_UNARY_FUNCTION_TRAITS(bitwise_not, typename omit_ref<Arg>::type, false, false);
ARAGELI_UNARY_FUNCTION_TRAITS(prefix_increment, Arg&, true, false);
ARAGELI_UNARY_FUNCTION_TRAITS(prefix_decrement, Arg&, true, false);
ARAGELI_UNARY_FUNCTION_TRAITS
	(postfix_increment, typename omit_ref<Arg>::type, true, false);
ARAGELI_UNARY_FUNCTION_TRAITS
	(postfix_decrement, typename omit_ref<Arg>::type, true, false);

ARAGELI_UNARY_FUNCTION_TRAITS(parentheses_0, Arg, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(parentheses_1, Arg1, false, false, false);
ARAGELI_TERNARY_FUNCTION_TRAITS(parentheses_2, Arg1, false, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS
	(subscript, typename omit_asterisk<Arg1>::type, false, false, false);

ARAGELI_BINARY_FUNCTION_TRAITS(plus, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(minus, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(multiplies, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(divides, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(modulus, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(logical_or, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(logical_and, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(equal_to, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(not_equal_to, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(greater, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(less, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(greater_equal, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(less_equal, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(bitwise_or, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(bitwise_and, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(bitwise_xor, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(shift_left, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(shift_right, typename omit_ref<Arg1>::type, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(all_equal_to, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(all_not_equal_to, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(all_greater, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(all_less, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(all_greater_equal, bool, false, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(all_less_equal, bool, false, false, false);
ARAGELI_EACH_CMP_FUNCTION_TRAITS(each_equal_to, false, false, false);
ARAGELI_EACH_CMP_FUNCTION_TRAITS(each_not_equal_to, false, false, false);
ARAGELI_EACH_CMP_FUNCTION_TRAITS(each_greater, false, false, false);
ARAGELI_EACH_CMP_FUNCTION_TRAITS(each_less, false, false, false);
ARAGELI_EACH_CMP_FUNCTION_TRAITS(each_greater_equal, false, false, false);
ARAGELI_EACH_CMP_FUNCTION_TRAITS(each_less_equal, false, false, false);


ARAGELI_BINARY_FUNCTION_TRAITS(assign, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_plus, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_minus, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_multiplies, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_divides, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_modulus, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_bitwise_or, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_bitwise_and, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_bitwise_xor, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_shift_left, Arg1&, true, false, false);
ARAGELI_BINARY_FUNCTION_TRAITS(assign_shift_right, Arg1&, true, false, false);

//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_plus, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_minus, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_multiplies, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_divides, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_modulus, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_bitwise_or, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_bitwise_and, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_bitwise_xor, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_shift_left, Arg1&, true, false, false);
//ARAGELI_BINARY_FUNCTION_TRAITS(right_assign_shift_right, Arg1&, true, false, false);

ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_plus, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_minus, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_multiplies, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_modulus, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_bitwise_or, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_bitwise_and, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_bitwise_xor, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_shift_left, Arg2&, false, true, false);
ARAGELI_BINARY_FUNCTION_TRAITS(left_assign_shift_right, Arg2&, false, true, false);


} // namespace Arageli



//#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
//	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_FUNCTION_TRAITS
//	#include "function_traits.cpp"
//	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_FUNCTION_TRAITS
//#endif


#endif  //  #ifndef _ARAGELI_function_traits_hpp_
