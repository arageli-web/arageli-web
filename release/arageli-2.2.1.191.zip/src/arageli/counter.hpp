/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       counter.hpp
//  Created:    2005/10/24    2:10
//
//  Author: Andrey Somsikov
*/

#ifndef __ARAGELI_counter_hpp__
#define __ARAGELI_counter_hpp__

#include "config.hpp"
#include <string>

namespace Arageli
{
class CCounter;
typedef unsigned long long counter_t;


class CCounter
{
public:
    void add(counter_t a)
    {
        if (suspended)
            return;
        sum += a;
        if (max < a) max = a;
        if (min > a) min = a;
        counter++;
    }
    counter_t getMax() { return max; }
    counter_t getMin() { return min; }
    counter_t getSum() { return sum; }
    counter_t getAverage() { return sum/counter; }
    std::string getName() { return name; }
    void reset()
    {
        max = 0;
        min = 0;
        sum = 0;
        counter = 0;
    }
    void suspend() { suspended = true; }
    void resume() { suspended = false; }
public:
    CCounter& operator += (counter_t a)
    {
        add(a);
        return *this;
    }
    CCounter& operator ++ ()
    {
        return *this += 1;
    }
public:
    CCounter()
    {
        max = 0;
        min = 0;
        sum = 0;
        counter = 0;
        suspended = false;
    }
    CCounter(std::string _name)
    {
        max = 0;
        min = 0;
        sum = 0;
        counter = 0;
        name = _name;
        suspended = false;
    }
    CCounter(const CCounter& c)
    {
        max = c.max;
        min = c.min;
        sum = c.sum;
        counter = c.counter;
        name = c.name;
        suspended = false;
    }
protected:
    std::string name;
    counter_t max;
    counter_t min;
    counter_t sum;
    counter_t counter;
    bool suspended;
};

extern CCounter counter_big_int_sum_GC;
extern CCounter counter_big_int_mul_GC;
extern CCounter counter_big_int_div_GC;

} // namespace Arageli

/*
#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_counter
	#include "counter.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_counter
#endif
*/

#endif /*__ARAGELI_counter_hpp__*/
/* End of file counter.hpp */
