/*****************************************************************************
	
	lll.hpp -- LLL basis reduction.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006

*****************************************************************************/

/**
	\file
	LLL basis reduction.
*/


#ifndef _ARAGELI_lll_hpp_
#define _ARAGELI_lll_hpp_

#include "config.hpp"


#include "std_import.hpp"


namespace Arageli
{

/// LLL basis reduction.
/** @param B should be a matrix
	@param H should be a matrix */
template <typename B_type, typename H_type>
bool lll_reduction (B_type& B, H_type& H);

}


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_LLL
	#include "lll.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_LLL
#endif


#endif  //  #ifndef _ARAGELI_lll_hpp_

