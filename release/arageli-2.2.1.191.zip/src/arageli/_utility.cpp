#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE__UTILITY)

#include "_utility.hpp"

namespace Arageli { namespace _Internal
{

template <typename A, typename B, typename Store_A, typename Store_B>
void swap_help_1
(A& a, B& b, Store_A& sa, Store_B& sb, false_type)
{
	A t;
	a.swap(t);
	a = b;
	b = t;
}


template <typename In_a, typename In_b>
int aggregate_cmp (In_a ai, In_a aend, In_b bi, In_b bend)
{
	for(; ai != aend && bi != bend; ++ai, ++bi)
	{
		int lres = cmp(*ai, *bi);
		if(lres < 0)return -1;
		else if(lres > 0)return +1;
	}

	if(ai == aend)
		if(bi == bend)return 0;
		else return -1;
	else
	{ // ai != aend
		ARAGELI_ASSERT_1(bi == bend);
		return +1;
	}
}


}}


#else


#include <cctype>
#include "_utility.hpp"


namespace Arageli { namespace _Internal
{


bool is_not_contains_spaces (const char* s)
{
	while(*s)if(std::isspace(*s++))return false;
	return true;
}


bool read_literal (std::istream& in, const char* s)
{
	const char* s_beg = s;
	if(!*s)return true;
	if(!in)return false;
	
	char ch;
	in >> ch;
	if(!in)return false;
	if(*s != ch)
	{
		in.putback(ch);
		return false;
	}

	Auto_stream_state ass(in, in.flags() & ~std::istream::skipws);

	while(*++s)
	{
		ch = in.get();
		if(!in)
		{
			in.clear();
			do in.putback(*--s); while(s != s_beg);
			return false;
		}
		if(*s != ch)
		{
			in.clear();
			in.putback(*s);
			do in.putback(*--s); while(s != s_beg);
			return false;
		}
	}

	return true;
}




}}

#endif
