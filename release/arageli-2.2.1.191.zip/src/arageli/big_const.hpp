/*****************************************************************************
	
	big_const.hpp -- functions that calculates several constants.

	This file is a part of the Arageli library.

	Copyright (C) Alexander Pshenichnikov, 2005--2006
	Copyright (C) Nikolay Santalov, 2005--2006
	
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	All fuctions return integer result.
	But the sought value equal result / 2 ^ (nbits + 1) 
	Functions terminating by _o return result with 
	0 <= error <= (1/2) ^ ( nbits ). 
	Functions terminating by _u return result with   
	-(1/2 )^ ( nbits ) <= error <=0 
	Functions without termination return result with
	-(1/2 )^ ( nbits + 1 ) <= error <= -(1/2 )^ ( nbits + 1 )	
	It means that (sought value) * 2 ^ ( nbits + 1) is in range [ res, res + 2 ]
	where res is result returned by "_u"  function. 
*/

#ifndef _ARAGELI_big_const_h_
#define _ARAGELI_big_const_h_

#include <cstddef>

#include "config.hpp"
#include "big_int.hpp"
#include "std_import.hpp"

namespace Arageli
{
/// Returns ln(1.25) with nbits significant bits  
big_int ln1_25(std::size_t nbits); 

/// Returns ln(1.25) with nbits significant bits with overflow
big_int ln1_25_o(std::size_t nbits);

/// Returns ln(1.25) with nbits significant bits with imperfection
big_int ln1_25_u(std::size_t nbits);

/// Returns ln(2) with nbits significant bits  
big_int ln2 (std::size_t nbits);

/// Returns ln(2) with nbits significant bits with imperfection
big_int ln2_u(std::size_t nbits);

/// Returns ln(2) with nbits significant bits with oveflow
big_int ln2_o(std::size_t nbits);

/// Returns lg2 with nbits significant bits  
big_int lg_2( std::size_t nbits ); 

/// Returns lg2 with nbits significant bits with imperfection
big_int lg_2_u( std::size_t nbits );

/// Returns lg2 with nbits significant bits with oveflow
big_int lg_2_o( std::size_t nbits );

/// Returns log2_10 with nbits significant bits  
big_int log2_10( std::size_t nbits ) ;//Returnslog2_10

/// Returns log2_10 with nbits significant bits with oveflow
big_int log2_10_o( std::size_t nbits ) ;//Returnslog2_10 with nbits significant bits with overflow  

/// Returns log2_10 with nbits significant bits with imperfection
big_int log2_10_u( std::size_t nbits ) ;//Returnslog2_10 with nbits significant bits with imperfection 

/// Returns exp(arg/2^factor) with nbits significant bits  
big_int exp ( big_int arg, std::size_t nbits,   int factor = 0 );

/// Returns exp(arg/2^factor) with nbits significant bits with imperfection
big_int exp_u ( big_int arg, std::size_t nbits, int factor = 0 );

/// Returns exp(arg/2^factor) with nbits significant bits with oveflow
big_int exp_o ( big_int arg, std::size_t nbits, int factor = 0 );

/// Returns 2^(arg/2^factor) with nbits significant bits  
big_int exp_2 ( big_int arg, std::size_t nbits,   int factor = 0 );

/// Returns 2^(arg/2^factor) with nbits significant bits with imperfection
big_int exp_2_u ( big_int arg, std::size_t nbits, int factor = 0 );

/// Returns 2^(arg/2^factor) with nbits significant bits with oveflow
big_int exp_2_o (big_int arg, std::size_t nbits,  int factor = 0 );

/// Returns e number with nbits significant bits  
big_int e (std::size_t nbits  );

/// Returns e number with nbits significant bits with imperfection
big_int e_u (std::size_t nbits  );

/// Returns e number with nbits significant bits with oveflow
big_int e_o ( std::size_t nbits  );

/// Returns ln10 with nbits significant bits  
big_int ln10 (std::size_t nbits);

/// Returns ln10 with nbits significant bits with imperfection
big_int ln10_u(std::size_t nbits);

/// Returns ln10 with nbits significant bits with oveflow
big_int ln10_o(std::size_t nbits);
}

#endif 