/*****************************************************************************
	
	sideset.cpp -- See declarations in sideset.hpp.

	This file is a part of the Arageli library.

	Copyright (C) Sergey S. Lyalin, 2006

*****************************************************************************/

/**
	\file
	See description for sideset.hpp file.
*/


#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_sideset)

// REFERENCE ADDITIONAL HEADERS HERE

#include "sideset.hpp"


namespace Arageli
{

// PLACE ALL TEMPLATE NOT INLINE IMPLEMENTATIONS HERE

}


#else	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...


namespace Arageli
{

// PLACE ALL NOT TEMPLATE NOT INLINE IMPLEMENTATIONS HERE

}


#endif	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...
