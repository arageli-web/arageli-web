/*****************************************************************************
	
	logarithm.hpp

	This file is a part of the Arageli library.

	Copyright (C) Alexander Pshenichnikov, 2005--2006
	Copyright (C) Nikolay Santalov, 2005--2006
	
	University of Nizhni Novgorod, Russia

*****************************************************************************/


#ifndef _ARAGELI_logarithm_h_
#define _ARAGELI_logarithm_h_

#include "config.hpp"

#include <cstddef>

#include "big_int.hpp"
#include "std_import.hpp"

namespace Arageli
{

std::size_t lg10 (std::size_t b);

void do_bin_convert
(
	const big_int& dm,
	const big_int& de,
	std::size_t p,
	big_int& bm,
	big_int& be
);

std::size_t do_dec_convert
(
	big_int& dm,
	big_int& de,
	std::size_t p,
	const big_int& bm,
	const big_int& be
);

}

#endif
