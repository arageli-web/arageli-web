/*****************************************************************************
	
	solve_linsys.cpp -- See declarations in solve_linsys.hpp.
		ADD ADDITIONAL FILE DESCRIPTION HERE

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2006
	Copyright (C) Anna Bestaeva, 2006
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	See description for solve_linsys.hpp file.
*/


#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_solve_linsys)

#include "gauss.hpp"

#include "solve_linsys.hpp"


namespace Arageli
{


template <typename A, typename B, typename X>
solve_linsys_result solve_linsys (const A& a, const B& b, X& x)
{
	// WARNING! Slow and temporary implementation.
	
	ARAGELI_ASSERT_0(a.is_square());

	try
	{
		x = inverse(a)*b;
		return SLR_UNIQUE;
	}
	catch(const matrix_is_singular& e)
	{ return SLR_MULTIPLE; }
}


/// Solve a heterogeneous linear system.
/** Solve linear system a*x = b. If the system have only one point x as
	a solution, that solution is returned. If the system doesn't have a solution
	or have a multiple solution, the function throws exception
	no_unique_solution.

	WARNING! This function has slow and temporary limited implementation. */
template <typename A, typename B>
B solve_linsys (const A& a, const B& b)
{
	// WARNING! Slow and temporary implementation.
	
	ARAGELI_ASSERT_0(a.is_square());

	try { return inverse(a)*b; }
	catch(const matrix_is_singular& e)
	{ throw no_unique_solution(); }
}


}


#else	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...


namespace Arageli
{

// PLACE ALL NOT TEMPLATE NOT INLINE IMPLEMENTATIONS HERE

}


#endif	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...
