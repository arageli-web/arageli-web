/*****************************************************************************
	
	arageli.hpp -- root header file for the Arageli library.
	
	Common information and others.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

#ifndef _ARAGELI_arageli_hpp_
#define _ARAGELI_arageli_hpp_

/** \file Root header file of the Arageli.
	
	This file contains includes for all public headers of the library.

*/

/**

\mainpage

This is a documentation for library
<a href="http://www.unn.ru/cs/arageli">Arageli</a>
founded by
<a href="http://www.uic.nnov.ru/~zny">Nikolai Yu. Zolotykh</a>
and maintaining by
<a href="http://www.unn.ru/cs/arageli/people.html">Arageli Project Team</a>.

Arageli is a C++ library for computations in <b>AR</b>ithmetic,
<b>A</b>lgebra, <b>GE</b>ometry,
<b>L</b>inear and <b>I</b>nteger linear programming.
Arageli is a library for
dealing with precise, i.e. symbolic or algebraic, computations.  It contains a definition
to model basic algebraic structures such as integer numbers with arbitrary precision,
rational numbers, vectors, matrices, polynomials etc.  Arageli is written in C++ and
use power and expressiveness of the language.

This software is free for non-profit-making uses.
You can use, copy, and distribute this software and its documentation for
any purpose wihtout commercial profit with or without fee, provided
copyrights notice appear in all copies and that both that copyright notice and
this permission notice appear in supporting documentation.

This software is provided "as is" without warranty.

Any comments and suggestions are welcome.
Please send it to <a href="mailto:support.arageli@gmail.com">Arageli Support Service</a>.

*/

// This file contains include directives for all general files of the library.
// Do not place here any other definitions.

#include "config.hpp"

#include "type_opers.hpp"
#include "type_traits.hpp"
#include "function_traits.hpp"
#include "type_pair_traits.hpp"

#include "exception.hpp"

#include "std_import.hpp"
#include "basefuncs.hpp"
#include "mixcomp.hpp"
#include "misc.hpp"

#include "std_import.hpp"

#include "factory.hpp"
#include "cmp.hpp"
#include "powerest.hpp"
#include "gcd.hpp"	// WARNING! Conflict: gcd.hpp needs vector.hpp
#include "intalg.hpp"
#include "prime.hpp"

#include "functional.hpp"

#include "gauss.hpp"
#include "intcount_barvinok.hpp"
#include "bareiss.hpp"

#include "subvector/indexed.hpp"
#include "submatrix/hpair.hpp"

#include "hermite/classic.hpp"
#include "hermite/hafner.hpp"
#include "hermite/storjohann.hpp"
#include "hermite/domich.hpp"
#include "hermite.hpp"

#include "smith/classic.hpp"
#include "smith/storjohann.hpp"
#include "smith/near_optimal.hpp"
#include "smith.hpp"

#include "io.hpp"
#include "iomanip.hpp"

//#include "random.hpp"
#include "solve_linsys.hpp"
#include "simplex_method.hpp"
#include "motzkin_burger.hpp"
#include "skeleton.hpp"
#include "triangulation.hpp"
#include "lll.hpp"
#include "intconvex.hpp"
#include "ctrl_slog.hpp"
#include "texout.hpp"
#include "ctrl_latexlog.hpp"
#include "polyalg.hpp"
#include "sturm.hpp"
#include "resultant.hpp"
#include "algebrslt.hpp"

#include "frwrddecl.hpp"

#include "big_int.hpp"
#include "big_const.hpp"
#include "logarithm.hpp"
#include "big_float.hpp"

#include "residue.hpp"
#include "rational.hpp"
#include "vector.hpp"
#include "matrix.hpp"
#include "sparse_polynom.hpp"
#include "interval.hpp"
#include "algebraic.hpp"
#include "cone.hpp"
#include "polyhedron.hpp"
//#include "polynom.hpp"

#include "subvector/indexed.hpp"
#include "submatrix/hpair.hpp"
#include "submatrix/indexed.hpp"


#endif // #ifndef _ARAGELI_arageli_hpp_
