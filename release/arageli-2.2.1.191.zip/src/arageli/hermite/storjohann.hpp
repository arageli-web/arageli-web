/*****************************************************************************
	
	hermite/storjohann.hpp -- an algorithm for the Hermite form of
		an integer matrix.

	This file is a part of the Arageli library.

	Copyright (C) Anna Bestaeva, 2006

*****************************************************************************/

/**
	\file
	This file contains a declaration of a function that produce the Hermite
	form of an integer matrix.
*/


#ifndef _ARAGELI_hermite_storjohann_hpp_
#define _ARAGELI_hermite_storjohann_hpp_

#include "../config.hpp"


namespace Arageli
{


///	Produces the Hermite form B of an integer matrix A.
/**
	Returns B, Q, basis, det:
	- P is unimodular princpal left transform such that B = Q * A;
	- rank is a rank of A;
	- B.sumbatrix(mesh_grid(1,r), basis) is the r-by-r non-singular
	upper triangular matrix;
	- det is the basis minor of A.
 */
template
<
	typename MA,
	typename MB,
	typename MQ,
	typename Basis,
	typename T_det
>
void hermite_storjohann
(
	const MA &A,
	MB &B,
	MQ &Q,
	Basis& basis,
	T_det& det
);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite_storjohann
	#include "storjohann.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite_storjohann
#endif

#endif	// #ifndef _ARAGELI_hermite_storjohann_hpp_
