/*****************************************************************************
	
	hermite/hafner.hpp -- the Hermite form H of an integer matrix A over Z/Z(N).

	This file is a part of the Arageli library.

	Copyright (C) Anna Bestaeva, 2006

*****************************************************************************/

/**
	\file
	This file contains a function for producing the Hermite form H of
	an integer matrix A over Z/Z(N).
*/


#ifndef _ARAGELI_hermite_hafner_hpp_
#define _ARAGELI_hermite_hafner_hpp_

#include "../config.hpp"


namespace Arageli
{


///	Produces the Hermite form H of an integer matrix A over Z/Z(N).
/**
	Returns H, U, basis:
	- U is unimodular princpal left transform such that H = U*A mod N;
	- rank is a rank of A;
	- H.sumbatrix(mesh_grid(1,r), basis) is the r-by-r non-singular
	upper triangular matrix.
	
 */
template
<
	typename MA,
	typename MH,
	typename MU,
	typename Basis,
	typename T_N
>
void hermite_hafner
(
	const MA &A,
	MH &H,
	MU &U,
	Basis &basis,
	T_N N
);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite_hafner
	#include "hafner.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite_hafner
#endif

#endif	// #ifndef _ARAGELI_hermite_hafner_hpp_
