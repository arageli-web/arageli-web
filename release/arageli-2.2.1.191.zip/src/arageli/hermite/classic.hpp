/*****************************************************************************
	
	hermite/classic.hpp -- the classic algorithm for the Hermite form of
		an integer matrix.

	This file is a part of the Arageli library.

	Copyright (C) Anna Bestaeva, 2006

*****************************************************************************/

/**
	\file
	This file contains a declaration of a function that implement the classic
	algorithm for the Hermite form of an integer matrix.
*/


#ifndef _ARAGELI_hermite_classic_hpp_
#define _ARAGELI_hermite_classic_hpp_

#include "../config.hpp"


namespace Arageli
{


///	Produces the Hermite form B of an integer matrix A.
/**
	Returns B, P, basis, det:
	- P is unimodular princpal left transform such that B = P * A;
	- rank is a rank of A;
	- B.sumbatrix(mesh_grid(1,r), basis) is the r-by-r non-singular
	upper triangular matrix;
	- det is the basis minor of A.
 */
template
<
	typename MA,
	typename MB,
	typename MP,
	typename Basis,
	typename T_det
>
void hermite_classic
(
	const MA &A,
	MB &B,
	MP &P,
	Basis &basis,
	T_det &det
);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite_classic
	#include "classic.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_hermite_classic
#endif

#endif	// #ifndef _ARAGELI_hermite_classic_hpp_
