/*****************************************************************************
	
	misc.hpp -- miscellaneous features

	This file is part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/** \file

	Miscellaneous features, routines, classes etc.
*/


#ifndef _ARAGELI_misc_hpp_
#define _ARAGELI_misc_hpp_

#include "config.hpp"


namespace Arageli
{


/// Makes and returns a temporary copy of the argument.
/**	This function is useful to dealing with our container-liked
	structures when an element of structure is used in operation
	with whole its owner.  For example, such operations are
	the dividing a row of a matrix by the element in that row,
	the dividing a polynomial by the leading coefficient and so on. */
template <typename T>
T safe_reference (const T& x) { return x; }


template <typename T1, typename T2, typename Outiter>
void generate_range_helper (T1& t1, const T2& t2, Outiter outiter)
{
	//std::cerr << "\nt1 = " << t1 << ", t2 = " << t2 << ":\n\t";

	if(t1 < t2)
		for(; t1 != t2; ++t1/*, std::cerr << t1 << "  "*/)
			*outiter++ = t1;
	else
		for(; t1 != t2; --t1/*, std::cerr << t1 << "  "*/)
			*outiter++ = t1;

	*outiter = t1;
}


template <typename T1, typename T2, typename T3, typename Outiter>
void generate_range_helper (T1& t1, const T2& t2, const T3& t3, Outiter outiter)
{
	for(; t1 != t3; t1 += t2, ++outiter)
		*outiter = t1;

	*outiter = t1;
}


template <typename T1, typename T2, typename Outiter>
void generate_range_helper_wo_inc (T1& t1, const T2& t2, Outiter outiter)
{
	//std::cerr << "\nt1 = " << t1 << ", t2 = " << t2 << ":\n\t";

	if(t1 < t2)
		for(; t1 != t2; t1 += unit(t1)/*, std::cerr << t1 << "  "*/)
			*outiter++ = t1;
	else
		for(; t1 != t2; t1 -= unit(t1)/*, std::cerr << t1 << "  "*/)
			*outiter++ = t1;

	*outiter = t1;
}


template <typename Outiter>
inline void generate_range_helper (bool& t1, bool t2, Outiter outiter)
{ generate_range_helper_wo_inc(t1, t2, outiter); }

template <typename Outiter>
inline void generate_range_helper (float& t1, float t2, Outiter outiter)
{ generate_range_helper_wo_inc(t1, t2, outiter); }

template <typename Outiter>
inline void generate_range_helper (double& t1, double t2, Outiter outiter)
{ generate_range_helper_wo_inc(t1, t2, outiter); }

template <typename Outiter>
inline void generate_range_helper (long double& t1, long double t2, Outiter outiter)
{ generate_range_helper_wo_inc(t1, t2, outiter); }


template <typename T> struct cnc_value_type
{ typedef typename T::value_type type; };

template <typename T> struct cnc_value_type<const T>
{ typedef typename T::value_type const type; };


template <typename T> struct cnc_reference
{ typedef typename T::reference type; };

template <typename T> struct cnc_reference<const T>
{ typedef typename T::const_reference type; };


template <typename T> struct cnc_pointer
{ typedef typename T::pointer type; };

template <typename T> struct cnc_pointer<const T>
{ typedef typename T::const_pointer type; };


template <typename T> struct cnc_iterator
{ typedef typename T::iterator type; };

template <typename T> struct cnc_iterator<const T>
{ typedef typename T::const_iterator type; };


} // namespace Arageli



//#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
//	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_MISC
//	#include "misc.cpp"
//	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_MISC
//#endif


#endif  //  #ifndef _ARAGELI_misc_hpp_
