/*****************************************************************************
	
	smith/classic.hpp -- the classic algirithm for the Smith Normal Diagonal
		Form of a matrix.

	This file is a part of the Arageli library.

	Copyright (C) Anna Bestaeva, 2006

*****************************************************************************/

/**
	\file
	This file contains declaration of the classic algirithm for the Smith
	Normal Diagonal Form of a matrix.
*/


#ifndef _ARAGELI_smith_classic_hpp_
#define _ARAGELI_smith_classic_hpp_

#include "../config.hpp"


namespace Arageli
{


///	Produces normal diagonal form B of integer matrix A.
/**
	Produces normal diagonal form B of integer matrix A.
	Returns B, P, Q, rank, det:
	- P, Q are unimodular such that B = P * A * Q;
	- rank is a rank of A;
	- det is the basis minor of A
 */
template
<
	typename MA,
	typename MB,
	typename MP,
	typename MQ,
	typename Rank,
	typename T_det
>
void smith_classic
(
	const MA &A,
	MB &B,
	MP &P,
	MQ &Q,
	Rank &rank,
	T_det &det
);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_smith_classic
	#include "classic.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_smith_classic
#endif

#endif	// #ifndef _ARAGELI_smith_classic_hpp_
