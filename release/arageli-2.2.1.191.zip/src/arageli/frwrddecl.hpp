/*****************************************************************************
	
	frwrddecl.hpp -- Some forward declaration.

	���� ���� �������� ������ ���������� Arageli.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/** \file
	Forward declaration for some Arageli structures.
*/


#ifndef _ARAGELI_frwrddecl_hpp_
#define _ARAGELI_frwrddecl_hpp_

#include "config.hpp"


namespace Arageli
{

class big_int;
template <typename T> class rational;
template <typename T, bool REFCNT = true> class vector;
template <typename T, bool REFCNT = true> class matrix;
template <typename F, typename I = int> class monom;
template <typename F, typename I = int, bool REFCNT = true> class sparse_polynom;


template <typename T, typename M> class cone_default_config;

template
<
	typename T = big_int,
	typename M = matrix<T>,
	typename CFG = cone_default_config<T, M>
>
class cone;


template
<
	typename Base,
	typename Index = vector<typename Base::size_type, true>
>
class indexed_subvector;


template
<
	typename Base,
	typename RowIndex = vector<typename Base::size_type, true>,
	typename ColIndex = RowIndex
>
class indexed_submatrix;


} // namespace Arageli


#endif  //  #ifndef _ARAGELI_frwrddecl_hpp_
