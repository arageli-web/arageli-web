/*****************************************************************************
	
	type_opers.cpp -- File description see in type_opers.hpp.

	This file is part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2005--2006
	University of Nizhni Novgorod, Russia

*****************************************************************************/

#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_TYPE_OPERS)

#include "type_opers.hpp"


namespace Arageli
{

template <typename T1, typename T2>
const false_type equal_types<T1, T2>::value = false_type();

template <typename T>
const true_type equal_types<T, T>::value = true_type();

//template <typename T1, typename T2>
//const false_type is_subcategory_of<T1, T2>::value = false_type();

} // namespace Arageli


#else


#include "type_opers.hpp"

namespace Arageli
{

const false_type bool_type<false>::value = false_type();
const true_type bool_type<true>::value = true_type();

}


#endif
