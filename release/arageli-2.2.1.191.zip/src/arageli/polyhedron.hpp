/*****************************************************************************
	
	polyhedron.hpp -- a representation of a convex polyhedron and operations on it.

	This file is a part of the Arageli library.

	Copyright (C) Sergey S. Lyalin, 2006
	University of Nizhni Novgorod, Russia, 2005--2006

*****************************************************************************/

/**
	\file
	This file contains a template class for representing of a convex polyhedron
	as the corresponding cone, operations such as intersection, sum etc,
	way for access to sides any dimention like iterator access to a containter
	and other.
*/


#ifndef _ARAGELI_polyhedron_hpp_
#define _ARAGELI_polyhedron_hpp_

#include "config.hpp"

#include "gcd.hpp"
#include "big_int.hpp"
#include "rational.hpp"
#include "cone.hpp"
#include "sideset.hpp"
#include "vector.hpp"
#include "matrix.hpp"


namespace Arageli
{

struct fromempty_t {};
const fromempty_t fromempty = fromempty_t();

struct fromivert_t {};
const fromivert_t fromivert = fromivert_t();

struct fromvert_t {};
const fromvert_t fromvert = fromvert_t();


template <typename T, typename M, typename C> class polyhedron_default_config {};


/// The polyhedron representation as the base cone.
/** The polyhedron in n-dimetion space is represented as a cone Ax >= 0
	in (n+1) dimention space and hyperplane	x[0] = 1, so the polyhedra is
	{x : Ax >= 0 & x[0] = 1}. In other words, polyhedron that is completely
	defined by system Ax >= b, represented as a cone (-b|A)x' >= 0, where
	x is n-vector and x' is (n+1)-vector. */
template
<
	typename T = big_int,
	typename M = matrix<big_int>,
	typename C = cone<T, M>,
	typename CFG = polyhedron_default_config<T, M, C>
>
class polyhedron
{
public:

	//typedef matrix<R> vertices_type;

	typedef C cone;

	typedef typename C::inequation_element_type inequation_element_type;
	typedef typename C::equation_element_type equation_element_type;
	typedef typename C::generatrix_element_type generatrix_element_type;
	typedef typename C::basis_element_type basis_element_type;

	typedef typename C::inequation_type inequation_type;
	typedef typename C::equation_type equation_type;
	typedef typename C::generatrix_type generatrix_type;
	typedef typename C::basis_type basis_type;

	typedef typename C::size_type size_type;
	typedef typename C::dim_type dim_type;
	typedef typename C::difference_type difference_type;


	/// Creates an empty polyhedron in 0-space.
	/** After creating the base cone is x[0] = 0 and
		only parametric representation is valid and normal. */
	polyhedron () : cone_m(1, fromnull) {}

	
	/// Creates an empty polyhedron in the space with specified dimention.
	/** After creating only parametric representation is valid and normal. */
	template <typename D>
	polyhedron (const D& dim, const fromempty_t&)
	:	cone_m(dim + 1, fromnull)
	{}
		 

	/// Creates polyhedron as all space with specified dimention.
	/** After creating only implicit representation is valid and normal. */
	template <typename D>
	polyhedron (const D& dim, const fromspace_t&);


	/// Creates polyhedron as a solution of specified inequations set with extended matrix.
	/**	Matrix ineqmat = (-b|A).
		After creating only implicit representation is valid but
		not necessarily normal. */
	template <typename M1>
	polyhedron (const M1& ineqmat, const fromineq_t&);


	/// Creates a poytope from vertices each element of which is representable as T.
	template <typename M1>
	polyhedron (const M1& vert, const fromivert_t&);


	/// Creates a poytope from vertices set.
	/** The vertices can be have not only T-compatible values.
		In this case we multiply each vertex by the particular multiplier
		so make them representable as element of type T and take the
		multiplier out of real vertices elements to x[0].
		<br><bold>WARNING! Now it works only for rational elements.</bold> */
	template <typename M1>
	polyhedron (const M1& vert, const fromvert_t&);


	//////////////////////////////////////////////////////////////////////////////////
	/// WARNING! TEMPORARY IMPLEMENTATION! ONLY FACETS AND ONLY FOR BODILY POLYTOPE.
	sideset sides () const;
	//////////////////////////////////////////////////////////////////////////////////


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	/// @name Access to valid/normal flags.

	//@{


	/// If it returns true than implicit representation (inequations and equations) is actual.
	bool is_implicit_valid () const
	{ return cone_m.is_implicit_valid(); }

	/// If it returns true than parametric representation (generatrices and basis) is actual.
	bool is_parametric_valid () const
	{ return cone_m.is_parametric_valid(); }

	/// If it returns true than implicit and parametric representations are both valid.
	bool is_all_valid () const
	{ return cone_m.is_all_valid(); }

	/// If it returns true than representation (inequations and equations) is in normal form.
	/** The implicit representation is in normal form iff this representation is valid
		and maximum non-zero linear variety (if any) represented only as a set of equations
		and there are no negligible inequations or negligible equations.
		Note, this form is not a single form. */
	bool is_implicit_normal () const
	{ return cone_m.is_implicit_normal(); }

	/// If it returns true than parametric representation (generatrices and basis) is in normal form.
	/** The parametric representation is in normal form iff this representation is valid
		maximum non-zero linear variety (if any) represented only as its corresponding
		basis and there are no negligible generatrix.
		Note, this form is not a single form. */
	bool is_parametric_normal () const
	{ return cone_m.is_parametric_normal(); }

	/// If it returns true than implicit and parametric representations are both in normal form.
	bool is_all_normal () const
	{ return cone_m.is_all_normal(); }


	//@}


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	/// @name Validation and normalization of the representations.

	//@{


	/// Make the implicit representation valid.
	/** This is based on the parametric representation.
		Actual validation is performed only if is_implicit_valid() == false. */
	void validate_implicit () const
	{ cone_m.validate_implicit(); }

	/// Make the parametric representation valid.
	/** This is based on the implicit representation.
		Actual validation is performed only if is_parametric_valid() == false. */
	void validate_parametric () const
	{ cone_m.validate_parametric(); }

	/// Make invalid representation valid.
	void validate_all () const
	{ cone_m.validate_all(); }
	
	/// Normalize the implicit representation.
	/** This is based on the implicit representation itself (if it's valid) or/and
		on the parametric representation. */
	void normalize_implicit () const
	{ cone_m.normalize_implicit(); }

	/// Normalize the parametric representation.
	/** This is based on the parametric representation itself (if it's valid) or/and
		on the parametric representation. */
	void normalize_parametric () const
	{ cone_m.normalize_parametric(); }
	
	/// Normalize both implicit and parametric representations.
	void normalize_all () const
	{ cone_m.normalize_all(); }


	//@}


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	/// @name Explicit set of valid/normal flags.

	//@{

	
	/// Set the valid implicit flag without an actual valid test or validation.
	/** Be careful! If you have set valid flags for both implicit and parametric
		representations but they don't represent the same polyhedron base cone,
		the future behaviour is undefined. */
	void set_valid_implicit ()
	{ cone_m.set_valid_implicit(); }

	/// Set the valid parametric flag without an actual valid test or validation.
	/** Be careful! If you have set valid flags for both implicit and parametric
		representations but they don't represent the same polyhedron base cone,
		the future behaviour is undefined. */
	void set_valid_parametric ()
	{ cone_m.set_valid_parametric(); }

	/// Set the valid both implicit and parametric flags without an actual valid test or validation.
	/** Be careful! If you have set valid flags for both implicit and parametric
		representations but they don't represent the same polyhedron base cone,
		the future behaviour is undefined. */
	void set_valid_all ()
	{ cone_m.set_valid_all(); }

	/// Set the normal implicit flag without an actual normal test or normalization.
	/** Be careful! If you have set normal flags for both implicit and parametric
		representations but one of them or both aren't normal or they don't represent
		the same polyhedron base cone, the future behaviour is undefined. */
	void set_normal_implicit ()
	{ cone_m.set_normal_implicit(); }

	/// Set the normal parametric flag without an actual normal test or normalization.
	/** Be careful! If you have set normal flags for both implicit and parametric
		representations but one of them or both aren't normal or they don't represent
		the same polyhedron base cone, the future behaviour is undefined. */
	void set_normal_parametric ()
	{ cone_m.set_normal_parametric(); }

	/// Set the normal both implicit and parametric flags without an actual normal test or normalization.
	/** Be careful! If you have set normal flags for both implicit and parametric
		representations but one of them or both aren't normal or they don't represent
		the same polyhedron base cone, the future behaviour is undefined. */
	void set_normal_all ()
	{ cone_m.set_normal_all(); }

	//@}


	// Brrrrr!
	template <typename M1>
	M1 vertices () const
	{
		normalize_parametric();
		M1 res = cone_m.generatrix_matrix();

		for(std::size_t i = 0; i < res.nrows();)
			if(Arageli::is_null(res(i, 0)))
				res.erase_row(i);
			else
			{
				res.div_row(i, safe_reference(res(i, 0)));
				++i;
			}

		res.erase_col(0);

		return res;
	}

	// Brrrrr!
	const T& inequation_matrix (std::size_t i, std::size_t j) const
	{ return cone_m.inequation_matrix()(i, j); }

	// Brrrrr!
	vector<T> facet_normal (std::size_t i) const
	{
		vector<T> res = cone_m.inequation_matrix().copy_row(i);
		res.pop_front();
		return res;
	}

	std::size_t space_dim () const { return cone_m.space_dim() - 1; }

private:

	C cone_m;

};


/// VRML Output. WARNING! The view will be correct only in wired mode.
template
<
	typename Out, 
	typename T,
	typename R,
	typename M,
	typename CFG
>
void output_vrml (Out& out, const polyhedron<T, R, M, CFG>& p);


class pstricks_color_map
{
public:

	pstricks_color_map
	(
		double rstart_a,
		double gstart_a,
		double bstart_a,
		double rend_a,
		double gend_a,
		double bend_a,
		std::size_t n_a,
		const std::string& name_a
	);

	/// x in [0, 1]
	const std::string& name (double x) const;

};


/// PostScript LaTeX Output with pstricks package. WARNING! Only for 3-dim polytopes.
/** This function produces command chain for pstricks package in LaTex that draw
	given polytope. You should place this chain into \pspicture environment. */
template
<
	typename Out,
	typename P,
	typename X1, typename Y1, typename X2, typename Y2,
	typename Viewdir,
	typename Colormap
>
void output_polytope_pstricks_3d
(
	Out& out,
	const P& p,
	double x1,
	double y1,
	double x2,
	double y2,
	double linewidth,
	const Viewdir& viewdir,
	const Colormap& colormap
);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_polyhedron
	#include "polyhedron.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_polyhedron
#endif

#endif	// #ifndef _ARAGELI_polyhedron_hpp_
