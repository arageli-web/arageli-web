/*****************************************************************************
	
	solve_linsys.hpp -- solving of linear systems of equations over
		different structures.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2006
	Copyright (C) Anna Bestaeva, 2006
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	This file contains routines to solve of linear systems of equations over
	different structures.

	WARNING! This file containes partially not yet implemented functions.
	The implementation is in progress.
*/


#ifndef _ARAGELI_solve_linsys_hpp_
#define _ARAGELI_solve_linsys_hpp_

#include "config.hpp"

#include "exception.hpp"


namespace Arageli
{


/// An exception for non-one-point solution for a linear system.
/** This exception is generated when one of the solve functions cannot
	represent a solution as one point. */
class no_unique_solution : public exception {};


enum solve_linsys_result { SLR_EMPTY, SLR_UNIQUE, SLR_MULTIPLE };


/// Solve heterogeneous linear system.
/** Solve linear system a*x = b. If the system doesn't have a solution,
	the function returns SLR_EMPTY. If the system have a solution(s),
	gx is a matrix of generators: any x is uniquely represented as
		x = offset + sum(a[i]*gx.col(i), i = 0..gx.ncols()-1),
	where a[i], i = 0..gx.ncols()-1 are some coefficients.
	
	WARNING! It isn't implemented yet. */
template <typename A, typename B, typename GX, typename Offset>
solve_linsys_result solve_linsys (const A& a, const B& b, Offset& offset, GX& gx);


/// Solve a heterogeneous linear system.
/** Solve linear system a*x = b. If the system have only one point x as
	a solution, that solution is stored	as x argument and the function
	returns SLR_UNIQUE. If the system doesn't have a solution, x isn't changed
	and the function returns SLR_EMPTY. If the system have a multiple solution,
	x is set equal to the one of them and the function returns SLR_MULTIPLE.

	WARNING! This function has a slow and temporary limited implementation. */
template <typename A, typename B, typename X>
solve_linsys_result solve_linsys (const A& a, const B& b, X& x);


/// Solve a heterogeneous linear system.
/** Solve linear system a*x = b. If the system have only one point x as
	a solution, that solution is returned. If the system doesn't have a solution
	or have a multiple solution, the function throws exception
	no_unique_solution.

	WARNING! This function has a slow and temporary limited implementation. */
template <typename A, typename B>
B solve_linsys (const A& a, const B& b);


/// Solve a homogeneous linear system.
/** Solve linear system a*x = 0. Returns matrix of generators.
	Each x is represented as x = sum(a[i]*gx.col(i), i = 0..gx.ncols()-1)
	where gx is returned matrix and a[i], i = 0..gx.ncols()-1 are some
	coefficients.

	WARNING! It isn't implemented yet. */
template <typename A>
A solve_linsys (const A& a);


} // namesapce Arageli


#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_solve_linsys
	#include "solve_linsys.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_solve_linsys
#endif

#endif	// #ifndef _ARAGELI_solve_linsys_hpp_
