/*****************************************************************************
	
	skeleton.hpp -- algorithms for double-description of a convex polyhedron.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	Copyright (C) Sergey S. Lyalin, 2006
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	Algorithms for double-description of a convex polyhedron.
	Implementation of skeleton function. Now this function just calls
	skeleton_motzkin_burger function.
*/

#ifndef _ARAGELI_skeleton_hpp_
#define _ARAGELI_skeleton_hpp_

#include "config.hpp"
#include "motzkin_burger.hpp"


namespace Arageli
{


namespace ctrl
{

struct skeleton_idler
{
	class abort : public ctrl::abort {};

	skeleton_motzkin_burger_idler motzkin_burger_ctrl () const
	{ return skeleton_motzkin_burger_idler(); }
};

}


/// The algorithm for double-description of a polyhedal cone.
/** Finds extreme rays f and basis e of a cone ax >= 0
	returns also an incidence matrix q = f * transpose(a). */
template
<
	typename A, typename F,
	typename Q, typename E,
	typename Ctrler
>
inline void skeleton
(
	A& a, F& f, Q& q, E& e,	// WARNING!!! Is matrix 'a' really mutable?
	const Ctrler& ctrler
)
{ skeleton_motzkin_burger(a, f, q, e, ctrler.motzkin_burger_ctrl()); }


/// The algorithm for double-description of a polyhedal cone.
/** Just calls full version of the function. */
template <typename A, typename F, typename Q, typename E>
inline void skeleton (A& a, F& f, Q& q, E& e)
{ return skeleton (a, f, q, e, ctrl::skeleton_idler()); }


} // namesapce Arageli


//#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
//	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_SKELETON
//	#include "skeleton.cpp"
//	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_SKELETON
//#endif

#endif
