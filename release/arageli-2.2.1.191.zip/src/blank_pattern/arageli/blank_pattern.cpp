/*****************************************************************************
	
	blank_pattern.cpp -- See declarations in blank_pattern.hpp.
		ADD ADDITIONAL FILE DESCRIPTION HERE

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	REFERENCE ADDITIONAL COPYRIGHTS HERE
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	See description for blank_pattern.hpp file.
*/


#include "config.hpp"

#if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || \
	defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_blank_pattern)

// REFERENCE ADDITIONAL HEADERS HERE

#include "blank_pattern.hpp"


namespace Arageli
{

// PLACE ALL TEMPLATE NOT INLINE IMPLEMENTATIONS HERE

}


#else	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...


namespace Arageli
{

// PLACE ALL NOT TEMPLATE NOT INLINE IMPLEMENTATIONS HERE

}


#endif	// #if !defined(ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE) || ...
