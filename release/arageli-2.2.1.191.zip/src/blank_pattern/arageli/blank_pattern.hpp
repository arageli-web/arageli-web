/*****************************************************************************
	
	blank_pattern.hpp -- ADD HEADER DESCRIPTION HERE.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	REFERENCE ADDITIONAL COPYRIGHTS HERE
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	ADD WHOLE FILE DESCRIPTION HERE
*/


#ifndef _ARAGELI_blank_pattern_hpp_
#define _ARAGELI_blank_pattern_hpp_

#include "config.hpp"

// REFERENCE ADDITIONAL HEADERS HERE


namespace Arageli
{


// PLACE ALL DECLARATIONS AND INLINE IMPLEMENTATIONS HERE


} // namesapce Arageli


// UNCOMMENT THE FOLLOWING FIVE LINES IF THERE IS blank_pattern.cpp FILE
//#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
//	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_blank_pattern
//	#include "blank_pattern.cpp"
//	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_blank_pattern
//#endif

#endif	// #ifndef _ARAGELI_blank_pattern_hpp_
