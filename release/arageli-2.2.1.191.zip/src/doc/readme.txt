In this folder only the next files are for publication:
	Algorithm_controller.tex
	Arageli_overview.dtx
	Mixed_computations.dtx
	Objects_comparison.tex
	Reference_count.tex
	Test_creating.tex
	Vector_matrix.dtx
	Arageli_overview_announce_preprint.tex

All others are old or very incomplete versions or auxiliary.
