/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       tstcontainer.cpp
//  Created:    2005/7/3    10:03
//
//  Author: Andrey Somsikov
//  Modification: Sergey S. Lyalin
*/

#include <ctime>

#include "tstcontainer.h"
#include "tsstream.h"

#ifndef TS_WITHOUT_BOOST
	#include <boost/regex.hpp>
#endif

#include <cstdlib>

//using namespace std;
#ifndef TS_WITHOUT_BOOST
	using namespace boost;
#endif

int CTestCollection::seed(0);
CTestCollection::CTestFunctions *CTestCollection::testsPtr(NULL);

CTestCollection::CTestFunctions& CTestCollection::getTests()
{
    if (NULL == testsPtr)
        testsPtr = new CTestFunctions();
    return *testsPtr;
}

bool CTestCollection::registerTest(FTestFunction testFunction, 
                                   const std::string& className,
                                   const std::string& functionName,
                                   const std::string& description)
{
    CTestFunctions& tests = getTests();
    tests.push_back(STest(testFunction, className, functionName, description));
    return true;
}

void CTestCollection::runTest(std::ostream& os, const STest& test, SRunStatistic& rstat)
{
    TestResult result;
	double duration = 0;	// test function work duration, sec

    srand(CTestCollection::seed);
#ifndef TS_DONT_CATCH_EXCEPTIONS_FROM_TEST
    try
    {
#endif //TS_DONT_CATCH_EXCEPTIONS_FROM_TEST
        rstat.totalCount++;
		std::clock_t start_time = std::clock(); 
        result = test.testFunction();
		std::clock_t end_time = std::clock();
		duration = double(end_time - start_time)/CLOCKS_PER_SEC;
#ifndef TS_DONT_CATCH_EXCEPTIONS_FROM_TEST
    }
    catch(...)
    {
        result = resEXCEPT;
    }
#endif //TS_DONT_CATCH_EXCEPTIONS_FROM_TEST
    os << "<TEST";
    os << " class=\"" << test.className << "\"";
    os << " function=\"" << test.functionName << "\"";
	os << " duration=\"" << duration << "\"";
    os << " result=\"";
    switch(result) {
    case resOK:
        os << "PASSED";
        rstat.passCount++;
        break;
    case resFAIL:
        os << "FAILED";
        rstat.failCount++;
        break;
    case resHANG:
        os << "HANGED";
        rstat.hangCount++;
        break;
    default: // resEXCEPT:
        os << "EXCEPTION";
        rstat.exceptCount++;
    }
    os << "\"";
    os << ">\n";
    os << "\t<DSCR>" << test.description << "</DSCR>";
    if(!tout.str().empty())os << "\n" << tout.str();
    os << "\n</TEST>\n\n";

    tout.str(""); // reset tout
}

#ifndef TS_WITHOUT_BOOST

SRunStatistic CTestCollection::run(std::ostream& os,
                                   const std::string& className,
                                   const std::string& functionName)
{
    SRunStatistic rstat;

    CTestFunctions& tests = getTests();

    cmatch what;
    regex classNameRegex(className);
    regex functionNameRegex(functionName);

    for (CTestFunctions::iterator it = tests.begin();
        it != tests.end();
        it++)
    {
        if (regex_match(it->className.c_str(), what, classNameRegex) && 
            regex_match(it->functionName.c_str(), what, functionNameRegex)) 
            runTest(os, *it, rstat);
    }

    TS_ASSERT(rstat.passCount+rstat.failCount+rstat.exceptCount+rstat.hangCount == rstat.totalCount);    

    return rstat;
}

#endif

SRunStatistic CTestCollection::runAll(std::ostream& os)
{
    SRunStatistic rstat;

    CTestFunctions& tests = getTests();

    for (CTestFunctions::iterator it = tests.begin();
        it != tests.end();
        it++)
        runTest(os, *it, rstat);

    TS_ASSERT(rstat.passCount+rstat.failCount+rstat.exceptCount+rstat.hangCount == rstat.totalCount);    

    return rstat;
}

/* End of file tstcontainer.cpp */
