/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       tsstream.h
//  Created:    2005/11/8    23:52
//
*/

#ifndef __tsstream_h__
#define __tsstream_h__

#include "config.hpp"
#include <sstream>

extern TS_DECL std::ostringstream tout;

#endif /*__tsstream_h__*/
/* End of file tsstream.h */
