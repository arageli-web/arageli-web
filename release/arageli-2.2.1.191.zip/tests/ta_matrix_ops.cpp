/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       ta_matrix_ops.cpp
//  Created:    2005/4/7    8:10
//
//  Author: Andrey Somsikov
//  Modified by Sergey S. Lyalin, 2006-08-30
*/

#include "ts_stdafx.hpp"
#include "ta_matrix_ops.hpp"

using namespace Arageli;

template <typename T, bool REFCNT>
matrix<T, REFCNT> rand_matrix(size_t m, size_t n, const T& max)
{
    matrix<T, REFCNT> res(m, n, fromsize);
    for (typename matrix<T>::size_type i = 0; i < res.nrows(); i++)
        for (typename matrix<T>::size_type j = 0; j < res.ncols(); j++)
            res.el(i, j) = rand(max);
    return res;
}

template <typename T, bool REFCNT>
matrix<T, REFCNT> rand_matrix_upper_diagonal(size_t n, const T& max)
{
    matrix<T, REFCNT> res(n, eye);
    for (typename matrix<T>::size_type i = 0; i < res.nrows(); i++)
        for (typename matrix<T>::size_type j = i+1; j < res.ncols(); j++)
            res.el(i, j) = rand(max);
    return res;
}

template <typename T, bool REFCNT>
void shuffle(matrix<T, REFCNT> &m, const T& max)
{
    m *= rand_matrix_upper_diagonal(m.ncols(), max);
}

/* End of file ta_matrix_ops.cpp */
