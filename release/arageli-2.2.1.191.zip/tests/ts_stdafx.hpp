// ts_stdafx.hpp : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <cstdlib>
#include <iostream>
#include <sstream>
#include <strstream>	// non standard feature
#include <ctime>
#include <iomanip>
#include <string>
#include <map>

#include <arageli/arageli.hpp>
#include <arageli/random.hpp>
//#include <arageli/lll.hpp>

#include <ts/ts.h>

// TODO: reference additional headers your program requires here



#define ARAGELI_TS_ALLEXCEPT_CATCH_REGION_BEGIN	\
	{											\
		try										\
		{										\
			ARAGELI_EXCEPT_LOCCTRL_REGION_BEGIN	\


#define ARAGELI_TS_ALLEXCEPT_CATCH_REGION_END				\
			ARAGELI_EXCEPT_LOCCTRL_REGION_END				\
		}													\
		catch(const ::std::exception& e)					\
		{													\
			::tout											\
				<< "Exception from the standard library:"	\
				<< "\n\twhat() = " << e.what();				\
			return resEXCEPT;								\
		}													\
		catch(const ::Arageli::exception& e)				\
		{													\
			::tout << "Exception from Arageli:\n" << e;		\
			return resEXCEPT;								\
		}													\
		catch(...)											\
		{													\
			::tout << "Unknown exception.";					\
			return resEXCEPT;								\
		}													\
	}														\


////////////////////////////////////////////////////////////////

#pragma warning(disable : 4018)
#pragma warning(disable : 4800)
