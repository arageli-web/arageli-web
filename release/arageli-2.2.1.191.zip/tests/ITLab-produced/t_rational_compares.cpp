// Author : Sidnev Alexey
// Tester :
// Creation date : 25.01.2006
// Modification date: 22.02.2006
// Testing date: 
// Description : Test compare functions: >, <, ==, !=, >=, <=, cmp.
//		Be used: t_compares.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;

bool rational_compares_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int per1, per2;
		big_int bper1=gen.Rand(), bper2=gen.Rand();

		while(!( per2=gen.Rand() ));
		while(!( bper2=gen.Rand() ));

		//rational<int> ri1(per1,per2);
		rational<big_int> rbi1(bper1,bper2);

		per1=gen.Rand(), bper1=gen.Rand();

		while(!( per2=gen.Rand() ));
		while(!( bper2=gen.Rand() ));

		//rational<int> ri2(per1,per2);
		rational<big_int> rbi2(bper1,bper2);

		//fail |=t_compares< rational<int> >(&ri1, &ri2);
		fail |=t_compares< rational<big_int> >(&rbi1, &rbi2);

		while(!( per1=gen.Rand() ));
		while(!( per2=gen.Rand() ));
		//rational<int> ri3(per1,per2);

		while(!( per1=gen.Rand() ));
		while(!( per2=gen.Rand() ));
		//rational<int> ri4(per1,per2);

		//rational<rational<int> > rri1(ri1, ri3), rri2(ri2, ri4);
		//fail |=t_compares< rational<rational<int> > >(&rri1, &rri2);

		while(!( bper1=gen.Rand() ));
		while(!( bper2=gen.Rand() ));
		rational<big_int> rbi3(bper1,bper2);

		while(!( bper1=gen.Rand() ));
		while(!( bper2=gen.Rand() ));
		rational<big_int> rbi4(bper1,bper2);

		//rational<rational<big_int> > rrbi1(rbi1, rbi3), rrbi2(rbi2, rbi4);
		//fail |=t_compares< rational<rational<big_int> > >(&rrbi1, &rrbi2);
	
		if(fail) 
		{
			tout<<"Function rational_compares_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,compares,"Test compare functions.")
{ 
	bool fail=rational_compares_test(824,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}