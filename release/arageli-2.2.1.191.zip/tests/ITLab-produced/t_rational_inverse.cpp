// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Test of inverse(). 
//		Be used: t_inverse.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;

bool rational_inverse_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int per1=gen.Rand(), per2=gen.Rand();
		big_int bper1=gen.Rand(), bper2=gen.Rand();

		while(!( per1=gen.Rand() ));
		while(!( per2=gen.Rand() ));
		while(!( bper1=gen.Rand() ));
		while(!( bper2=gen.Rand() ));

		rational<int> ri(per1,per2);
		rational<big_int> rbi(bper1,bper2);

		fail |=t_inverse< rational<int> >(ri);
		fail |=t_inverse< rational<big_int> >(rbi);
	
		if(fail) 
		{
			tout<<"Function rational_inverse_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,inverse,"Test inverse() function.")
{ 
	bool fail=rational_inverse_test(5284,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}