// Author : Aleksandrov Vladimir
// Tester : Sidnev Alexey 
// Creation date : 20.01.2006
// Modification date: 30.01.2006
// Testing date: 12.02.2006
// Description : + -


#include "../ts_stdafx.hpp"
#include "rand.hpp"

#include <time.h>
#include <strstream>

using namespace Arageli;

template <class T>
bool big_int_plus_minus (const T A,const T B)
{
	try
	{	
		big_int a=A, b=B, d=a+b;
	
		T x=A, y=B;
		big_int z=x+y;
	
		if (z!=d)
		{
			tout<<"function plus_minus failed on 1 check with A="<<A<<", B="<<B<<'\n';
			return true;
		}

		if ((b!=d-a)||(a!=d-b))
		{
			tout<<"function plus_minus failed on 2 check with A="<<A<<", B="<<B<<'\n';
			return true;
		}
		return false;
	}
	catch(Arageli::exception& e)
	{
		tout << "EXCEPTION: ";
		e.output(tout); tout << '\n';
		return true;
	}
}

bool big_int_plus_minus_test(int param, int count)
{
	bool fail=false;
	RNG gen(param,1<<16);

		fail |= big_int_plus_minus(0,0);
	
		char x=3;
		char y=4;
		fail |= big_int_plus_minus((signed char) (x),(signed char) (y));
		fail |= big_int_plus_minus((unsigned char) (x),(unsigned char) (y));
		fail |= big_int_plus_minus(x,y);

		if(fail) 
		{
			tout<<"Function big_int_plus_minus_test failed on first step.\n";
			return fail;
		}

	
		for (int k=0; k<count; k++)
		{
			int a=gen.Rand();
			int b=gen.Rand();
			fail |= big_int_plus_minus(a,b);
			fail |= big_int_plus_minus(double (a),double (b));
			fail |= big_int_plus_minus(float (a),float (b));
			fail |= big_int_plus_minus(long (a),long (b));
			fail |= big_int_plus_minus((long double) (a),(long double) (b));
			fail |= big_int_plus_minus((signed short) (a),(signed short) (b));
			fail |= big_int_plus_minus((unsigned short) (a),(unsigned short) (b));
			fail |= big_int_plus_minus((unsigned int) (a),(unsigned int) (b));
			fail |= big_int_plus_minus((signed int) (a),(signed int) (b));

			if(fail) 
			{
				tout<<"Function big_int_plus_minus_test failed on "<<k+1<<" step.\n";
				return fail;
			}
		}
	
		bool a1=1;
		bool a2=1;
		fail |= big_int_plus_minus(a1,a2);

		if(fail) 
		{
			tout<<"Function big_int_plus_minus_test failed on last step.\n";
			return fail;
		}


	return false;
}




TEST(big_int,plus_minus,"Test")
{ 
	bool fail=big_int_plus_minus_test(100,1000);
	
	if(fail) return resFAIL;
	return resOK;

}
