// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Test of opposite(). 
//		Be used: t_opposite.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;

bool rational_opposite_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int per1=gen.Rand(), per2=gen.Rand();
		big_int bper1=gen.Rand(), bper2=gen.Rand();

		while(!( per2=gen.Rand() ));
		while(!( bper2=gen.Rand() ));

		rational<int> ri(per1,per2);
		rational<big_int> rbi(bper1,bper2);

		fail |=t_opposite< rational<int> >(ri);
		fail |=t_opposite< rational<big_int> >(rbi);
	
		if(fail) 
		{
			tout<<"Function rational_opposite_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,opposite,"Test opposite() function.")
{ 
	bool fail=rational_opposite_test(3426,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}