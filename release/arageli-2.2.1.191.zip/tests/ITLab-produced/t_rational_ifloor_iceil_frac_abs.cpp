// Author : Sidnev Alexey
// Tester :
// Creation date : 1.02.2006
// Modification date: 1.02.2006
// Testing date: 
// Description : Test of ifloor, iceil, frac, abs functions. 
//		Be used: t_rational_ifloor_iceil_frac.


#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;


bool rational_ifloor_iceil_frac_abs_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int iper1=gen.Rand(), iper2=gen.Rand();
		big_int biper1=gen.Rand(), biper2=gen.Rand();

		while(!( iper2=gen.Rand() ));
		while(!( biper2=gen.Rand() ));

		rational<int> ri(iper1,iper2);
		rational<big_int> rbi(biper1,biper2);

		fail |=t_rational_ifloor_iceil_frac_abs<int>(ri);
		fail |=t_rational_ifloor_iceil_frac_abs<big_int>(rbi);
			
		if(fail) 
		{
			tout<<"Function rational_ifloor_iceil_frac_abs_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}


TEST(rational,ifloor_iceil_frac_abs,"Test ifloor, iceil, frac, abs functions.")
{ 
	bool fail=rational_ifloor_iceil_frac_abs_test(4272,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}
