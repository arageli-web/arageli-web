// File : t_matrix_mult_row.cpp
// Author : Zaitsev Mikhail
// Tester : Aleksandrov Vladimir
// Date of creation: 2006/01/27
// Date of modification : 2006/01/31
// Testing date :
// Description : Test for function mult_row
/* I check the correction of work of this function dividing row on the same value that
   I use in multiplication
*/
// Using functions : mult_row(),div_row(),nrows()
// Errors :


#include "../ts_stdafx.hpp"
#include "rand.hpp"


using namespace Arageli;


template <class T>
bool m_mult_row(const char* s,T val)
{
  if(!val) return false;
  matrix<T> A(s);
  matrix<T> X=A;

  for(int i=0;i<A.nrows();i++)
   {
	  A.mult_row(i,val);
      A.div_row(i,val);    
   }

  if(A!=X)
   {
     tout<<"function failed with"<<s;
	 return true;
   }

 return false;

}


TEST(matrix,mult_row,"Tets for mult_row function")
{
  
  bool fail=false;
  RNG element(2,16);

  for(int k=0;k<10;k++)
 {
	 int cols=1+element.Rand()%5;
	 int rows=1+element.Rand()%5;
	 std::strstream buff;
	 buff<<'(';
	 for(int i=0; i<rows; i++)
	 {
		buff<<'(';
		for(int j=0; j<cols-1; j++)
			// 1: buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()<<',';
			// buff<<(element.Rand()-(1<<14))<<',';
			 buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
		// 1: buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()<<')';
		// buff<<(element.Rand()-(1<<14))<<')';
		 buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		if(i!=rows-1) buff<<',';
	 }
	 buff<<')';
	 buff<<'\x0';
     
	 //fail |=m_mult_row<rational<> >(buff.str(),element.Rand());
	 //fail |=m_mult_row<int>(buff.str(),element.Rand());
	 fail |=m_mult_row<big_int>(buff.str(),element.Rand());

 }

 if(fail) return resFAIL;

 return resOK;

}

/* End of file t_matrix_mult_row.cpp */