// Author : Sidnev Alexey
// Tester :
// Creation date : 03.02.2006
// Modification date: 18.02.2006
// Testing date: 
// Description : Test of *, / operations. 
//		Be used: t_mul_div, t_vector_scalar_mul_div, t_vector_shlr.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_vector.hpp"

using namespace Arageli;

bool vector_mul_div_test(int param, int count)
{
	bool fail=false;
	RNG gen(param,1<<15);

	for(int k=0;k<count;k++)
	{
		int vsize=gen.Rand()%30;

		Arageli::vector<rational<int> > vri1(vsize), vri2(vsize);

		for(int i=0; i<vsize; i++)
			vri1[i]=(rational<int>)gen.Rand()+1;

		for(int i=0; i<vsize; i++)
			vri2[i]=(rational<int>)gen.Rand()+1;

		Arageli::vector<rational<big_int> > vrbi1(vsize), vrbi2(vsize);

		for(int i=0; i<vsize; i++)
			vrbi1[i]=(rational<big_int>)gen.Rand()+1;

		for(int i=0; i<vsize; i++)
			vrbi2[i]=(rational<big_int>)gen.Rand()+1;

		fail |=t_mul_div< Arageli::vector<rational<int> >, Arageli::vector<rational<int> > >(vri1, vri2);
		fail |=t_mul_div< Arageli::vector<rational<big_int> >, Arageli::vector<rational<big_int> > >(vrbi1, vrbi2);

		Arageli::vector<int> vi(vsize);
		int i=gen.Rand();

		for(int i=0; i<vsize; i++)
			vi[i]=gen.Rand();

		Arageli::vector<big_int> vbi(vsize);
		big_int bi=gen.Rand();

		for(int i=0; i<vsize; i++)
			vbi[i]=gen.Rand();

		fail |=t_vector_scalar_mul_div< rational<int> >(vri1, (rational<int>)gen.Rand());
		fail |=t_vector_scalar_mul_div< rational<big_int> >(vrbi1, (rational<big_int>)gen.Rand());

		fail |=t_vector_shlr< int >(vi, i%8);
		fail |=t_vector_shlr< big_int >(vbi, bi%100);

		if(fail) 
		{
			tout<<"Function vector_mul_div_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
} 

TEST(vector,mul_div,"Test *, /, shl, shr, scalar *, scalar / functions.")
{ 
	bool fail=vector_mul_div_test(4901,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}