// File ; t_matrix_matrix_add.cpp
// Author : Zaitsev Mikhail
// Tester : Aleksandrov Vladimir
// Date of creation : 2005/12/16
// Dateof modification : 2006/01/31
// Testing date :
// Description : Test for function operator+=(const matrix<T,REFCNT>& x)
/*
   I check that testing function works correctly subtracting from the result of addition
   the previuos matrix
*/
// Using functions : operator-=(const matrix<T,REFCNT>& x)
// Attention : first uncomment the need strings of generation examples and specification
// of template testing function

// Errors : test shows that testing function works incorrectly with double matrixes

#include "../ts_stdafx.hpp"
#include "rand.hpp"

using namespace Arageli;

template <typename T>
bool matrix_add(const char* s,const char* m)
{
  matrix<T> A(s);
  matrix<T> B(m);
  matrix<T> X=A;

  (A+=B)-=B;
  for(int i=0;i<X.nrows();i++)
	  for(int j=0;j<X.ncols();j++)
		  if(A(i,j)!=X(i,j))
		   {
		     tout<<"function failed with"<<s<<"    "<<m;
			 return true;
		   }

  return false;
}


TEST(matrix,matrix_add,"Test operator+= function")
{
  
  bool fail=false;
  RNG element(2,16);

 for(int k=0;k<20;k++)
 {
	int cols=1+element.Rand()%5;
	int rows=1+element.Rand()%5;

	std::strstream buffA,buffB;
    
	//generation of matrix A
	buffA<<'(';
	for(int i=0; i<rows; i++)
	{
		buffA<<'(';
		for(int j=0; j<cols-1; j++)
			// 1: buffA<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<',';
			// 2: buffA<<(element.Rand()-(1<<14))<<'.'<<abs(element.Rand())<<',';
			// 3: buffA<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
		// 1: buffA<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<')';
		// 2: buffA<<(element.Rand()-(1<<14))<<'.'<<abs(element.Rand())<<')';
		// 3: buffA<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		if(i!=rows-1) buffA<<',';
	}
	buffA<<')';
	buffA<<'\x0';
	
    //generation of matrix B
    buffB<<'(';
	for(int i=0; i<rows; i++)
	{
		buffB<<'(';
		for(int j=0; j<cols-1; j++)
			// 1: buffB<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<',';
			// 2: buffB<<(element.Rand()-(1<<14))<<'.'<<abs(element.Rand())<<',';
			// 3: buffB<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
		// 1: buffB<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<')';
		// 2: buffB<<(element.Rand()-(1<<14))<<'.'<<abs(element.Rand())<<')';
		// 3: buffB<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		if(i!=rows-1) buffB<<',';
	}
	buffB<<')';
	buffB<<'\x0';

	// 1: fail |=matrix_add<rational<> >(buffA.str(),buffB.str());
	// 2: fail |=matrix_add<double>(buffA.str(),buffB.str());
	// 3: fail |=matrix_add<big_int>(buffA.str(),buffB.str());
	
 }
 
 if(fail) return resFAIL;
 return resOK;

}

/* End of file t_matrix_matrix_add.cpp */