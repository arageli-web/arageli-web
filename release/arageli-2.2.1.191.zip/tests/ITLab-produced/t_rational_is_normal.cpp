// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Test of is_normal(). 
//		Be used: t_rational_is_normal.

#include "../ts_stdafx.hpp"

#include "t_universal.hpp"
#include "t_rational.hpp"
#include "rand.hpp"

using namespace Arageli;


bool rational_is_normal_test(int param, int count)
{
	bool fail=false;
	RNG gen(param,1<<8);

	for(int k=0;k<count;k++)
	{
		int per1=gen.Rand(), per2=gen.Rand();
		big_int bper1=gen.Rand(), bper2=gen.Rand();

		while(!( per2=gen.Rand() ));
		while(!( bper2=gen.Rand() ));

		rational<int> ri(per1,per2);
		rational<big_int> rbi(bper1,bper2);

		fail |=t_rational_is_normal<int>(ri);
		fail |=t_rational_is_normal<big_int>(rbi);
	
		if(fail) 
		{
			tout<<"Function rational_is_normal_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,is_normal,"Test is_normal() function.")
{ 
	bool fail=rational_is_normal_test(2451,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}

