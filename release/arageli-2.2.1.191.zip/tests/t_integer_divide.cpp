/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_integer_divide.cpp
//  Created:    20.03.2006
//
//  Author: Sergey Lyalin
*/


#include "ts_stdafx.hpp"


using namespace Arageli;

TEST_FUNCTION(integer_divide_prdivide, "Test division of integers with mathematically correct and Fortran-like sign of reminder for big_int and builtin numbers.")
{                                               
	const int test_amount = 100;
	const int max_fails = 10;
	int fail = 0;
	
	for(int i = -test_amount; i < test_amount; ++i)
		for(int j = -test_amount; j < test_amount; ++j)
		{
			int stage = 0;
			try
			{
				if(!j)continue;

				big_int bi = i, bj = j;

				if(bi != i || bj != j)
				{
					tout
						<< "Conversion from int to big_int failed:"
						<< "\n\ti = " << i
						<< "\n\tj = " << j
						<< "\n\tbi = " << bi
						<< "\n\tbj = " << bj << '\n';
					if(++fail == max_fails)return resFAIL;
				}

				stage = 1;

				int i_div_j = i/j, i_rem_j = i%j;
				big_int bi_div_bj = bi/bj, bi_rem_bj = bi%bj;

				if(i_div_j != bi_div_bj || i_rem_j != bi_rem_bj)
				{
					tout
						<< "Int vs. big_int standard division mismatch:"
						<< "\n\ti = " << i
						<< "\n\tj = " << j
						<< "\n\ti/j = " << i_div_j
						<< "\n\tbi/bj = " << bi_div_bj
						<< "\n\ti%j = " << i_div_j
						<< "\n\tbi%bj = " << bi_div_bj << '\n';
					if(++fail == max_fails)return resFAIL;
				}

				stage = 2;

				int i_prdiv_j, i_prrem_j;
				big_int bi_prdiv_bj, bi_prrem_bj;

				stage = 3;
				prdivide(i, j, i_prdiv_j, i_prrem_j);
				stage = 4;
				prdivide(bi, bj, bi_prdiv_bj, bi_prrem_bj);

				if(i_prdiv_j != bi_prdiv_bj)
				{
					tout
						<< "Int vs. big_int pr-division mismatch:"
						<< "\n\ti = " << i
						<< "\n\tj = " << j
						<< "\n\ti/j = " << i_prdiv_j
						<< "\n\tbi/bj = " << bi_prdiv_bj
						<< "\n\ti%j = " << i_prdiv_j
						<< "\n\tbi%bj = " << bi_prdiv_bj << '\n';
					if(++fail == max_fails)return resFAIL;
				}
			}
			catch(const Arageli::exception& e)
			{
				tout << '\n' << e.msg();
				tout
					<< "\n\ti = " << i
					<< "\n\tj = " << j
					<< "\n\tstage = " << stage << '\n';
				if(++fail == max_fails)return resFAIL;
			}
		}


    return resOK;
}
