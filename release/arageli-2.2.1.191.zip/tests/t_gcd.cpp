/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_gcd.cpp
//  Created:    2005/4/7    8:10
//
//  Author: Andrey Somsikov
*/


#include "ts_stdafx.hpp"


using namespace Arageli;

bool gcd_int_test(int a, int b)
{
    int g = gcd<int>(a, b);
    int g1 = gcd<int>(-a, b);
    int g2 = gcd<int>(a, -b);
    int g3 = gcd<int>(-a, -b);
    
    if (0 != a%g || 0 != b%g)
    {
        tout << "GCD fails with" 
            << " gcd( " << a << ", " << b << ") = " << g << "\n";
        return true;
    }

    if (g != g1 || g != g2 || g != g3)
    {
        tout << "GCD fails with" 
            << " g != g1 || g != g2 || g != g3\n";
            return true;
    }

    return false;
}

TEST_FUNCTION(gcd, "Test gcd function")
{                                               
    bool fail = false;

    fail |= gcd_int_test(8, 8);
    fail |= gcd_int_test(8, 64);
    fail |= gcd_int_test(64, 8);
    fail |= gcd_int_test(0, 0);
    fail |= gcd_int_test(1, 0);
    fail |= gcd_int_test(0, 1);
    fail |= gcd_int_test(5, 7);
    fail |= gcd_int_test(14, 10);

    fail |= gcd_int_test(big_int(8), big_int(8));
    fail |= gcd_int_test(big_int(8), big_int(64));
    fail |= gcd_int_test(big_int(64), big_int(8));
    fail |= gcd_int_test(big_int(0), big_int(0));
    fail |= gcd_int_test(big_int(1), big_int(0));
    fail |= gcd_int_test(big_int(0), big_int(1));
    fail |= gcd_int_test(big_int(5), big_int(7));
    fail |= gcd_int_test(big_int(14), big_int(10));

	if (fail)
        return resFAIL;

    return resOK;
}

/*
TEST_FUNCTION(gcd_gauss)
{
    rational<int> aData[] = {-10, 10, 10, 0};
    rational<int> bData[] = {-5, -3, 0};
    polynom< rational<int> > a(aData, COUNT_OF(aData));
    polynom< rational<int> > b(bData, COUNT_OF(bData));

    polynom< rational<int> > g = gcd_gauss(a, b);

    tout << a << "\n";
    tout << b << "\n";
    tout << g << "\n";

    return resOK;
}
*/

/* End of file t_gcd.cpp */
