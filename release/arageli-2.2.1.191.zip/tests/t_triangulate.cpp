/*****************************************************************************
	
	t_triangulate.cpp -- test for triangulate functions.

	This file is a part of the Arageli library test base.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	REPLACE OR/AND REFERENCE ADDITIONAL COPYRIGHTS HERE
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	This file includes test for triangulate.
*/


#include "ts_stdafx.hpp"

using namespace Arageli;


namespace
{


template <typename Q, typename Tr, typename Dim>
bool concrete_test ()
{
	vector<Q, false> q =
		"(((1)),"
		" (),"
		" ((0, 1), (1, 0)),"
		" ((1, 0, 0), (0, 1, 0), (0, 0, 1)),"
		" ((0, 1, 0), (1, 0, 0), (0, 0, 1)),"
		" ((0, 1, 1, 0), (0, 0, 1, 1), (1, 0, 0, 1), (1, 1, 0, 0)),"
		" ((0, 1, 1, 1, 0), (0, 0, 1, 1, 1), (1, 0, 0, 1, 1), (1, 1, 0, 0, 1), (1, 1, 1, 0, 0))"
		")";

	vector<Tr, false> ctr =
		"(((0)),"
		" (()),"
		" ((0, 1)),"
		" ((0, 1, 2)),"
		" ((0, 1, 2)),"
		" ((0, 1, 2), (0, 2, 3)),"
		" ((0, 1, 2), (0, 2, 3), (0, 3, 4))"
		")";

	vector<Dim> dim   = "(1, 0, 2, 3, 3, 3, 3, 3, 3)";

	bool valid = true;

	for(std::size_t i = 0; i < q.size(); ++i)
	{
		Tr tr;
		triangulate_simple_1(q[i], dim[i], tr, 0);
		if(tr != ctr[i])
		{
			tout
				<< "\ntr != trcorrect:"
				<< "\n\tq = [" << q[i].nrows() << ", " << q[i].ncols() << "]" << q[i]
				<< "\n\ttr = [" << tr.nrows() << ", " << tr.ncols() << "]" << tr
				<< "\n\ttrcorrect = [" << ctr[i].nrows() << ", " << ctr[i].ncols() << "]" << ctr[i]
				<< "\n\tdim = " << dim[i]
				;

			valid = false;
		}
	}

	return valid;
}


}


TEST_FUNCTION(triangulate, "Description for triangulate functions test")
{                                               
	bool is_ok = true;

	try
	{
		is_ok &= concrete_test<matrix<big_int>, matrix<big_int>, big_int>();
	}
	catch(const Arageli::exception& e)
	{
		tout << e;
		return resEXCEPT;
	}
	catch(const std::exception& e)
	{
		tout << e.what();
		return resEXCEPT;
	}
	
	return is_ok ? resOK : resFAIL;
}
