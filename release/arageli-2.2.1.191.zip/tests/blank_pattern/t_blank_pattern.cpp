/*****************************************************************************
	
	t_blank_pattern.cpp -- ADD FILE DESCRIPTION HERE

	This file is a part of the Arageli library test base.

	Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
	REPLACE OR/AND REFERENCE ADDITIONAL COPYRIGHTS HERE
	University of Nizhni Novgorod, Russia

*****************************************************************************/

/**
	\file
	This file includes test for blank_pattern.
*/


#include "ts_stdafx.hpp"

using namespace Arageli;


namespace
{

// PLACE AUXILIARY CODE HERE

}


// CHOOSE ONE OF THE FOLLOWING THREE HEADERS

TEST(/*CLASS NAME*/, /*FUNCTION NAME*/, "Description for blank_pattern test")
TEST_FUNCTION(/*FUNCTION NAME*/, "Description for blank_pattern test")
TEST_CLASS(/*CLASS NAME*/, "Description for blank_pattern test")
{                                               
	bool is_ok = true;

	try
	{
		// PLACE TEST CODE HERE

		// FOR EXAMPLE:
		// is_ok &= your_test();
	}
	catch(const Arageli::exception& e)
	{
		tout << e;
		return resEXCEPT;
	}
	catch(const std::exception& e)
	{
		tout << e.what();
		return resEXCEPT;
	}
	
	return is_ok ? resOK : resFAIL;
	
	return resOK;
}
