/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_sparse_polynom_cmp.cpp
//  Created:    16.01.2005
//
//  Author: Sergey Lyalin
*/


#include "ts_stdafx.hpp"


using namespace Arageli;

template <typename P1, typename P2>
bool sparse_polynom_cmp_test ()
{
	bool res = false;
	std::ostringstream buftout;
	
	typedef rnd<P1> Random_P1;
	typedef rnd<P2> Random_P2;

	for(int i = 0; i < 100; ++i)try
	{
		P1 p11 = Random_P1::rand();
		
		try
		{
			if(cmp(p11, p11) != 0)
			{
				tout << "cmp(" << p11 << ", the same) != 0\n";
			}
		}
		catch(const Arageli::exception&)
		{
			buftout
				<< "\nWHEN: cmp(" << p11 << ", the same) != 0\n";
			throw;
		}

		//try
		//{
		//	if(!is_null(p11) && cmp(p11, -p11) != +1)
		//	{
		//		tout << "!is_null(" << p11 << ") && cmp(the same, " << -p11 << ") != +1\n";
		//	}
		//}
		//catch(const Arageli::exception&)
		//{
		//	buftout
		//		<< "\nWHEN: !is_null(" << p11 << ") && cmp(the same, " << -p11 << ") != +1\n";
		//	throw;
		//}

		//try
		//{
		//	if(!is_null(p11) && cmp(-p11, p11) != -1)
		//	{
		//		tout << "!is_null(" << p11 << ") && cmp(" << -p11 << ", the same) != -1\n";
		//	}
		//}
		//catch(const Arageli::exception&)
		//{
		//	buftout
		//		<< "\nWHEN: !is_null(" << p11 << ") && cmp(" << -p11 << ", the same) != -1\n";
		//	throw;
		//}
	
		try
		{
			if(!is_null(p11) && cmp(p11*P1("x"), p11) != +1)
			{
				tout << "!is_null(" << p11 << ") && cmp(" << p11*P1("x") << ", the same) == +1\n";
			}
		}
		catch(const Arageli::exception&)
		{
			buftout
				<< "\nWHEN: !is_null(" << p11 << ") && cmp(" << p11*P1("x") << ", the same) == +1\n";
			throw;
		}

		P2 p21 = Random_P2::rand();

		try
		{
			if(cmp(p11, p21) * cmp(p21, p11) > 0)
			{
				tout << "cmp(" << p11 << ", " << p21 << ") * cmp(" << p21 << ", " << p11 << ") <= 0\n";
			}
		}
		catch(const Arageli::exception&)
		{
			buftout
				<< "\nWHEN: cmp(" << p11 << ", " << p21 << ") * cmp(" << p21 << ", " << p11 << ") <= 0\n";
			throw;
		}

	}
	catch(const Arageli::exception& e)
	{
		tout << "EXCEPTION: ";
		e.output(tout); tout << '\n';
		tout
			<< "WITH:"
			<< "\n\tP1 = " << typeid(P1).name()
			<< "\n\tP2 = " << typeid(P2).name();
		std::string buf = buftout.str();
		if(!buf.empty())
			tout << buf;
		tout << '\n';
		res = true;
	}

	return res;
}

TEST_FUNCTION(sparse_polynom_cmp, "Test cmp function for sparse_polynom class.")
{                                               
    bool fail = false;

    fail |= sparse_polynom_cmp_test<sparse_polynom<int>, sparse_polynom<int> >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<int>, sparse_polynom<big_int> >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<int>, sparse_polynom<rational<> > >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<big_int>, sparse_polynom<int> >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<big_int>, sparse_polynom<big_int> >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<big_int>, sparse_polynom<rational<> > >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<rational<> >, sparse_polynom<int> >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<rational<> >, sparse_polynom<big_int> >();
    fail |= sparse_polynom_cmp_test<sparse_polynom<rational<> >, sparse_polynom<rational<> > >();

    if(fail)
        return resFAIL;

    return resOK;
}
