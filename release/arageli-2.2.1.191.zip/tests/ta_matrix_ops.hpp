/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       ta_matrix_ops.hpp
//  Created:    2005/11/11    18:53
//
*/

/** \file ta_matrix_ops.h
\brief Operations with the matrix.
Contains extended operations with matrix object that is necessary for testing
purposes.
*/

#ifndef __ta_matrix_ops_hpp__
#define __ta_matrix_ops_hpp__


#include "ts_stdafx.hpp"


using namespace Arageli;

/// Create matrix in \f$T^{n \times m}\f$ with random elements not grater than max
template <typename T, bool REFCNT>
matrix<T, REFCNT> rand_matrix(size_t m, size_t n, const T& max);

/** 
Create upper diagonal matrix \f$M \in T^{n \times n}\f$ with element 1 on the 
diagonal and with random elements the not grater than max on other 
positions.
Note that \f$M\f$ is in hermite form and \f$det(M)=1\f$.
*/
template <typename T, bool REFCNT>
matrix<T, REFCNT> rand_matrix_upper_diagonal(size_t n, const T& max);

/**
Shuffles input matrix \f$m\f$ by multiplying it on the upper diagonal 
random matrix acquired from rand_matrix_upper_diagonal(m.ncols(), max) call.
Note that this operation does not change determinant of the source matrix.
*/
template <typename T, bool REFCNT>
void shuffle(matrix<T, REFCNT> &m, const T& max);

#endif /*__ta_matrix_ops_hpp__*/
/* End of file ta_matrix_ops.hpp */
