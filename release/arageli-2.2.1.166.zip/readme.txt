********************************************************************

              The Arageli Library Readme File.

********************************************************************

Copyright (C) Nikolai Yu. Zolotykh, 1999--2006
Copyright (C) Sergey S. Lyalin, 2005--2006
University of Nizhni Novgorod, Russia.

Arageli is the C++ library and the package of programs for
computations in arithmetic, algebra, geometry, linear and integer
linear programming.  Arageli is a library for dealing with precise,
i.e. symbolic or algebraic, computations.  It contains a definition
to model basic algebraic structures such as integer numbers with
arbitrary precision, rational numbers, vectors, matrices,
polynomials etc.  Arageli is written in C++ and use power and
expressiveness of the language.

The home page: http://www.unn.ru/cs/arageli

********************************************************************


1. Software Requirements

To build the library and create documentation you need several
applications to be installed. Without some of them you will not
able to create some parts of the documentation or the library
itself.

In particular, you need:
	
1.1 To compile the library --- one of the C++ standard
compilers. We have checked compilation with GCC 3.3.3,
Microsoft Visual C++ Compiler 7.1 (included in
Visual Studio .NET 2003), Intel C++ Compiler 9.0
for Windows. Without this you cannot compile the library
but can compile the documentation.
	
1.2 To create all guides (tex-files) --- LaTeX installation.
We use MiKTeX. Note, some documentation files are written
in Russian.

1.3 To create guides with using lgrind (dtx-files) ---
lgrind installation. Without this you cannot create some guide
files with lgrind directives.

1.4 To create references to sources --- doxygen installation.
Without this you cannot extract documented items from sources.

To create all parts of the distributive you should have all
programs referenced at 1.1--1.4. If you plan to contribute into
the library we recommend you to have all this programs.

If you need some part of the library compiled (both library or
documentation), you can download it at the home page of Arageli
http://www.unn.ru/cs/arageli.


2. Building

All build scripts are located in build directory of
the distributive.  Choose proper platform directory for your
system and build all or a particular part of the distributive.

If you use Microsoft Visual Studio .NET 2003 you can build
solution that located at projects/vc7.1/arageli-all. Note if
you want to use tests project you should build ts system.
It�s located at tools/ts, build scripts: tools/ts/build and
VS2003 solution: tools/ts/projects/vc7.1/ts-all.


3. Additional documentation and feedback

Some ready-to-use documentation files already present in doc
directory of the distributive. Go to http://www.unn.ru/cs/arageli
for updates and news; mail questions, comments and suggestions on
support.arageli@gmail.com.
