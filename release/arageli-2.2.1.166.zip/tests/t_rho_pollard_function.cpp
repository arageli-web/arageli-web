/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_rho_pollard_function.cpp
//  Created:    17.01.2006
//
//  Author: Aleksey Bader
*/


#include "ts_stdafx.hpp"


TEST_FUNCTION(rho_pollard, "Test rho_pollard function")
{
    using namespace Arageli;
    srand( (unsigned)time( NULL ) );
	TestResult res = resOK;
    int i = 10;
    while(i)
    {
        big_int q1 = rand(INT_MAX);
        big_int q2 = rand(INT_MAX);
        big_int test = q1*q2;
        big_int result = rho_pollard(test);
        if(result == test) 
        {
            res = resFAIL;
            tout << "Test fail: " << test << " = " << q1 << '*' << q2 << '\n';
            tout << "Result: " << result << '\n';
        }
        --i;
    }
    return res;
}


/* End of file t_rho_pollard_function.cpp */
