// File : t_matrix_is_unit.cpp
// Author : Zaitsev Mikhail
// Tester : Aleksandrov Vladimir
// Date of creation : 2006/02/05
// Date of modification :
// Testing date :
// Using functions : is_unit(),is_opposite_unit()


#include "../ts_stdafx.hpp"
#include "rand.hpp"


using namespace Arageli;


template <class T,char s>
bool matrix_is_unit()
{
	
	 RNG element(2,16); 

  	 int size=1+element.Rand()%6;
	 
     	      
     std::strstream buff;
	 buff<<'(';

	 switch(s)
	 {
	 case 'r':
	   for(int i=0; i<size; i++)
	    {
		  buff<<'(';
         	   for(int j=0; j<size-1; j++)
	               buff<<element.Rand()-(1<<14)<<'/'<<element.Rand()+1<<',';
			  
			   buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<')';
		 if(i!=size-1) buff<<',';
	   }
     break;

	 case 'i':
	   for(int i=0; i<size; i++)
	    {
		  buff<<'(';
         	   for(int j=0; j<size-1; j++)
                   buff<<(element.Rand()-(1<<14))<<',';
              
			   buff<<(element.Rand()-(1<<14))<<')';
		 if(i!=size-1) buff<<',';
	   }
     break;

	 case 'b':
       for(int i=0; i<size; i++)
	    {
		  buff<<'(';
         	   for(int j=0; j<size-1; j++)
                   buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
              
			   buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		 if(i!=size-1) buff<<',';
	   }
     break;		 
	 }
	 buff<<')';
	 buff<<'\x0';
     
	 matrix<T> A(buff.str());//matrix constructor from string
	 matrix<T> B=A;

	 A.opposite();

	 if(B.is_unit()!=A.is_opposite_unit())
	   {
		   tout<<"function failed with"<<buff.str();
		   return true;
	   
	   }

     return false;
}


TEST(matrix,is_unit,"Test for function is_unit")
{
   bool fail=false;
   for(int i=0;i<100;i++)
   {
	  fail |=matrix_is_unit<rational<>,'r'>();
      fail |=matrix_is_unit<int,'i'>();
	  fail |=matrix_is_unit<big_int,'b'>();
   }

   if(fail) return resFAIL;
   return resOK;

}

/* End of file t_matrix_is_unit.cpp */