// Author : Sidnev Alexey
// Tester :
// Creation date : 03.02.2006
// Modification date: 16.02.2006
// Testing date: 
// Description : Test of is_null(). 
//		Be used: t_vector_is_null, t_vector_is_empty, t_vector_size.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_vector.hpp"

using namespace Arageli;

bool vector_is_null_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int vsize=gen.Rand()%30;
		fail |=t_vector_size<int>(vsize);
		fail |=t_vector_size<big_int>(vsize);
		fail |=t_vector_size<double>(vsize);
		fail |=t_vector_size<float>(vsize);
		fail |=t_vector_size<rational<int> >(vsize);
		fail |=t_vector_size<rational<big_int> >(vsize);

		Arageli::vector<int> vi(vsize);

		for(int i=0; i<vsize; i++)
			vi[i]=1+gen.Rand();

		Arageli::vector<big_int> vbi(vsize);

		for(int i=0; i<vsize; i++)
			vbi[i]=1+gen.Rand();

		Arageli::vector<double> vd(vsize);

		for(int i=0; i<vsize; i++)
			vd[i]=gen.Rand();

		Arageli::vector<float> vf(vsize);

		for(int i=0; i<vsize; i++)
			vf[i]=gen.Rand();

		fail |=t_vector_is_null< int >(&vi);
		fail |=t_vector_is_null< big_int >(&vbi);
		fail |=t_vector_is_null< double >(&vd);
		fail |=t_vector_is_null< float >(&vf);

		fail |=t_vector_is_empty< int >(&vi);
		fail |=t_vector_is_empty< big_int >(&vbi);
		fail |=t_vector_is_empty< double >(&vd);
		fail |=t_vector_is_empty< float >(&vf);

		Arageli::vector<rational<int> > vri(vsize);

		for(int i=0; i<vsize; i++)
			vri[i]=(rational<int>)(gen.Rand()+1);


		Arageli::vector<rational<big_int> > vrbi(vsize);

		for(int i=0; i<vsize; i++)
			vrbi[i]=(rational<big_int>)(gen.Rand()+1);

		fail |=t_vector_is_null< rational<int> >(&vri);
		fail |=t_vector_is_null< rational<big_int> >(&vrbi);

		fail |=t_vector_is_empty< rational<int> >(&vri);
		fail |=t_vector_is_empty< rational<big_int> >(&vrbi);
	
		if(fail) 
		{
			tout<<"Function vector_is_null_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(vector,is_null_is_empty_size,"Test is_null(), is_empty(), size()  functions.")
{ 
	bool fail=vector_is_null_test(295,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}