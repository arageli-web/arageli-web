// File : t_matrix_swap_row.cpp
// Author : Zaitsev Mikhail
// Tester : Aleksandrov Vladimir
// Date of creation : 2006/02/02
// Date of modification :
// Testing date :
// Using functions : swap_rows(),copy_row(),insert_row(),erase_row(),nrows()


#include "../ts_stdafx.hpp"
#include "rand.hpp"


using namespace Arageli;


template <class T,char s>
bool m_swap_row()
{
     RNG element(2,16);

	 int cols=1+element.Rand()%5;
	 int rows=2+element.Rand()%5;
     	      
     std::strstream buff;
	 buff<<'(';

	 switch(s)
	 {
	 case 'r':
	   for(int i=0; i<rows; i++)
	    {
		  buff<<'(';
         	   for(int j=0; j<cols-1; j++)
				   
                   buff<<element.Rand()-(1<<14)<<'/'<<element.Rand()+1<<',';
			  
			   buff<<(element.Rand()-(1<<14))<<'/'<<element.Rand()+1<<')';
		 if(i!=rows-1) buff<<',';
	   }
     break;

	 case 'i':
	   for(int i=0; i<rows; i++)
	    {
		  buff<<'(';
         	   for(int j=0; j<cols-1; j++)
                   buff<<(element.Rand()-(1<<14))<<',';
              
			   buff<<(element.Rand()-(1<<14))<<')';
		 if(i!=rows-1) buff<<',';
	   }
     break;

	 case 'b':
       	   for(int i=0; i<rows; i++)
	    {
		  buff<<'(';
         	   for(int j=0; j<cols-1; j++)
                   buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<',';
              
			   buff<<(element.Rand()-(1<<14))<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<abs(element.Rand())<<')';
		 if(i!=rows-1) buff<<',';
	   }
     break;		 
	 }
	 buff<<')';
	 buff<<'\x0';
     
	 matrix<T> A(buff.str());//matrix constructor from string
	 matrix<T> X=A;// copy of testing matrix
	     

	 for(int i=0;i<A.nrows();i++)
		 for(int j=i+1;j<A.nrows();j++)
		 {
			 A.swap_rows(i,j);
             
			 //my own algorithm of rows' swapping
             X.insert_row(i,X.copy_row(j));
             X.insert_row(j+1,X.copy_row(i+1));
			 X.erase_row(i+1);
			 X.erase_row(j+1);
           
			   if(A!=X)
			     {
			         tout<<"function failed with"<<buff.str();
			         return true;
			  
			     }

			  //A.swap_rows(i,j);

		 }

    return false;

}


TEST(matrix,swap_rows,"Test for function swap_rows")
{
  bool fail=false;

  for(int i=0;i<10;i++)
  {
    fail |=m_swap_row<rational<>,'r'>();
    fail |=m_swap_row<int,'i'>();
	fail |=m_swap_row<big_int,'b'>();
  
  }

  if(fail) return resFAIL;
  return resOK;

}

/* End file t_matrix_swap_row.cpp */