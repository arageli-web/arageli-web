// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Test of swap(...). 
//		Be used: t_rational_swap.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;

bool rational_swap_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int per1=gen.Rand(), per2=gen.Rand();
		big_int bper1=gen.Rand(), bper2=gen.Rand();

		while(!( per2=gen.Rand() ));
		while(!( bper2=gen.Rand() ));

		rational<int> ri1(per1,per2);
		rational<big_int> rbi1(bper1,bper2);

		per1=gen.Rand(), bper1=gen.Rand();

		while(per2==0)
			per2=gen.Rand();

		while(bper2==0)
			bper2=gen.Rand();

		rational<int> ri2(per1,per2);
		rational<big_int> rbi2(bper1,bper2);

		fail |=t_rational_swap<int>(ri1, ri2);
		fail |=t_rational_swap<big_int>(rbi1, rbi2);
	
		if(fail) 
		{
			tout<<"Function rational_swap_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,swap,"Test swap() function.")
{ 
	bool fail=rational_swap_test(997,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}