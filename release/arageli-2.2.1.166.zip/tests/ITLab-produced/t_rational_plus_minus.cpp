// Author : Sidnev Alexey
// Tester :
// Creation date : 20.01.2006
// Modification date: 01.02.2006
// Testing date: 
// Description : Test of +, - operations(unary and binary). 
//		Be used: t_rational_plus_minus, t_plus_minus.

#include "../ts_stdafx.hpp"

#include "rand.hpp"
#include "t_universal.hpp"
#include "t_rational.hpp"

using namespace Arageli;

bool rational_plus_minus_test(int param, int count)
{
	bool fail=false;
	RNG gen(param);

	for(int k=0;k<count;k++)
	{
		int iper1=gen.Rand(), iper2=gen.Rand();
		big_int biper1=gen.Rand(), biper2=gen.Rand();

		while(!( iper2=gen.Rand() ));
		while(!( biper2=gen.Rand() ));

		//rational<int> ri(iper1,iper2), ri_tem(gen.Rand());
		rational<big_int> rbi(biper1,biper2), rbi_tem(gen.Rand());

		//fail |=t_rational_plus_minus<int,int>(ri, ri_tem);
		fail |=t_rational_plus_minus<big_int,big_int>(rbi, rbi_tem);
		//fail |=t_rational_plus_minus<big_int,int>(rbi, ri);

		//fail |=t_plus_minus<rational<big_int>,rational<int> >(rbi, ri);
		//fail |=t_plus_minus<rational<int>,rational<int> >(ri, ri_tem);
		fail |=t_plus_minus<rational<big_int>,rational<big_int> >(rbi, rbi_tem);
	
		if(fail) 
		{
			tout<<"Function rational_plus_minus_test failed on "<<k+1<<" step.\n";
			return fail;
		}
	}
	return false;
}

TEST(rational,plus_minus,"Test +,- functions.")
{ 
	bool fail=rational_plus_minus_test(3457,1000);

	if(fail)
		return resFAIL;
	else
		return resOK;
}