/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       t_pollard_pm1.cpp
//  Created:    17.01.2006
//
//  Author: Aleksey Bader
*/


#include "ts_stdafx.hpp"


TEST_FUNCTION(pollard_pm1, "Test pollard_pm1 algorithm.")
{
    using namespace Arageli;
    srand( (unsigned)time( NULL ) );
    TestResult res = resOK;
    int i = 10;
    while(i)
    {
        big_int q1 = rand(INT_MAX);
        big_int q2 = rand(INT_MAX);
        big_int test = q1*q2;
        long inter_num = 1000;
        big_int result = pollard_pm1(test, inter_num);
        if(result == test || is_null(result))
        {
            res = resFAIL;
            tout << "Test fail: " << test << " = " << q1 << '*' << q2 << '\n';
            tout << "Result: " << result << '\n';
        }
        --i;
    }
    return res;
}


/* End of file t_pollard_pm1.cpp */
