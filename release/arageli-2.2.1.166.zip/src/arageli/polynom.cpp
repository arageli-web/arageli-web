/* /////////////////////////////////////////////////////////////////////////////
//
//  File:       polynom.cpp
//  Created:    2005/10/18    9:34
//
//  Author: Andrey Somsikov
*/



/* End of file polynom.cpp */
