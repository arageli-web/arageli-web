/*****************************************************************************
	
	cmp.hpp -- Comparisions.

	���� ���� �������� ������ ���������� Arageli.

	Copyright (C) Nikolai Yu. Zolotykh, 2005
	Copyright (C) Sergey S. Lyalin, 2005
	Copyright (C) University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

#ifndef _ARAGELI_cmp_hpp_
#define _ARAGELI_cmp_hpp_

#include "config.hpp"
#include "exception.hpp"
#include "factory.hpp"

#include "std_import.hpp"


namespace Arageli
{


/// Performs Arageli like comparision.
/** There is specialization of this function (or an overloaded version) for each
	main Arageli object.
	Returns
	-  0  if a == b,
	-  -1 if a < b,
	-  1  if a > b. */
template <typename T1, typename T2>
inline int cmp (const T1& a, const T2& b)
{
	if(a < b)return -1;
	else if(a > b)return +1;
	else
	{
		ARAGELI_ASSERT_0(a == b);
		return 0;
	}
}


/// Sign of element.
/** Returns +1, 0 or -1. */
template <typename T>
inline int sign (const T& x)
{ return cmp(x, null(x)); }


/// Returns true if x is even.
template <typename T>
inline bool is_even (const T& x)
{ return is_null(x & unit(x)); }


/// Returns true if x is odd.
template <typename T>
inline bool is_odd (const T& x)
{ return !is_null(x & unit(x)); }


/// Returns true if a is divisible by b.
template <typename T1, typename T2>
inline bool is_divisible (const T1& a, const T2& b)
{ return is_null(a%b); }


/// Returns true if x is greater then null.
template <typename T>
inline bool is_positive (const T& x)
{ return x > null(x); }

/// Returns true if x is less then null.
template <typename T>
inline bool is_negative (const T& x)
{ return x < null(x); }


/// Returns true if x is integer
template <typename T>
inline bool is_integer (const T& x)
{ return is_null(frac(x)); }


} // namespace Arageli


//#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
//	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_CMP
//	#include "cmp.cpp"
//	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_CMP
//#endif


#endif  //  #ifndef _ARAGELI_cmp_hpp_
