/*****************************************************************************
	
	exception.hpp -- basic exceptions of library and specific macro for
		asserts.

	This file is a part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2005
	Copyright (C) Sergey S. Lyalin, 2005
	Copyright (C) University of Nizhni Novgorod, Russia, 2005

*****************************************************************************/

/**
	\file
	This file contains basic exception classes definitions and some macros
	for assertions that controlled by debug level value (see config.hpp)
*/


#ifndef _ARAGELI_exception_hpp_
#define _ARAGELI_exception_hpp_

#include "config.hpp"

#include <cstddef>
#include <cassert>
#include <string>
#include <iostream>
#include <sstream>


//****************************************************************************

namespace Arageli
{


/// Base for all exception classes.
class exception
{
public:

	/// The message of exception.
	virtual std::string msg () const
	{ return std::string("Arageli exception \"") + typeid(*this).name() + "\""; }
	
	/// Outputs the message of exception to out stream.
	virtual void output (std::ostream& out) const { out << msg(); }

	virtual ~exception () {}

};


inline std::ostream& operator<< (std::ostream& out, const exception& e)
{ e.output(out); return out; }


/// Exception class that can be trhowed when failed the some assertion.
/**	Holds information about failed expression, line and sourse name where
	placed the activated assertion. */
class assert_failed : public virtual exception
{
public:

	assert_failed
	(
		const char* expr_a,
		const char* source_a,
		std::size_t line_a
	) throw()
	:	expr_m(expr_a),
		source_m(source_a),
		line_m(line_a)
	{}

	/// Returns string notation of an expression that has been failed.
	const char* expr () const throw() { return expr_m; }
	
	/// Returns name of source file in which failure has been occured.
	const char* source () const throw() { return source_m; }
	
	/// Returns a number of line in file source() with failure.
	std::size_t line () const throw() { return line_m; }

	/// Formats a human readable message with source, line and expression.
	virtual std::string msg () const
	{
		std::ostringstream buf;
		output(buf);
		return buf.str();
	}

	/// Formats and outputs a human readable message with source, line and expression.
	virtual void output (std::ostream& out) const
	{
		out
			<< "Arageli assertion failed."
			<< "\n\tSource: " << source()
			<< "\n\tLine: " << line ()
			<< "\n\tExpression: " << expr();
	}

private:

	const char* expr_m;
	const char* source_m;
	std::size_t line_m;

};


/// Exception situation: an index out of range while indexing the some structure.
class out_of_range : public virtual exception
{
public:

	virtual std::string msg () const
	{ return "Out of range at an index expression"; }
};


/// Exceprion situation: invalid argument in call of the some operation.
class invalid_argument : public virtual exception
{
public:

	virtual std::string msg () const
	{ return "Invalid argument for the operation"; }
};


/// Exception situation: division by zero.
class division_by_zero : public invalid_argument
{
public:

	virtual std::string msg () const
	{ return "Division by zero"; }
};


/// Exception situation: the some matrix is singular.
class matrix_is_singular : public invalid_argument
{
public:


	virtual std::string msg () const
	{ return "Matrix is singular"; }
};


/// Exception situation: the some object have failed initialization from a string.
class incorrect_string : public invalid_argument
{
	std::string str_m;

public:

	incorrect_string (const std::string& str_a) : str_m(str_a) {}

	virtual std::string msg () const
	{
		std::string res = "Incorrect string";
		if(!str_m.empty())
			res += " \"" + str_m + "\"";
		return res;
	}

	const std::string& str () const { return str_m; }

};


namespace ctrl
{

class abort : public virtual exception
{
public:

	virtual std::string msg () const
	{
		return std::string("Controller \"") +
			typeid(*this).name() +
			"\" breaks execution of the function.";
	}
};

}


/// Construct for throwing exception assert_failed or harder failure raising.
#ifdef ARAGELI_ASSERT_THROW_EXCEPTION
	#define ARAGELI_THROW_ASSERT_FAILED(EXPR)	\
	{ throw ::Arageli::assert_failed(#EXPR, __FILE__, __LINE__); }
#else
	#ifdef NDEBUG
		#define ARAGELI_THROW_ASSERT_FAILED(EXPR)								\
		{																		\
			::std::cerr << '\n' << ::Arageli::assert_failed(#EXPR, __FILE__, __LINE__);	\
			/*::std::abort();*/::std::cin.get();														\
		}
	#else
		#define ARAGELI_THROW_ASSERT_FAILED(EXPR)	\
		{ assert(!#EXPR); }
	#endif
#endif


/// Always check assertion with a particular exception object.
#define ARAGELI_ASSERT_ALWAYS_CUST(EXPR, EXCEPT_OBJ)	\
	{ if(!(EXPR))throw EXCEPT_OBJ; }


/// Always check assertion with standard reaction when assertion failed.
#define ARAGELI_ASSERT_ALWAYS(EXPR)	\
	{ if(!(EXPR))ARAGELI_THROW_ASSERT_FAILED(EXPR); }


#if ARAGELI_DEBUG_LEVEL > 0

	#define ARAGELI_ASSERT_0_CUST(EXPR, EXCEPT_OBJ)	\
		ARAGELI_ASSERT_ALWAYS_CUST(EXPR, EXCEPT_OBJ)
	
	#define ARAGELI_ASSERT_0(EXPR)	\
		ARAGELI_ASSERT_ALWAYS(EXPR)

	#define ARAGELI_DEBUG_EXEC_0(WHAT) WHAT

#else

	#define ARAGELI_ASSERT_0_CUST(EXPR, EXCEPT_OBJ)	/* nothing */
	#define ARAGELI_ASSERT_0(EXPR)	/* nothing */
	#define ARAGELI_DEBUG_EXEC_0(WHAT)	/* nothing */

#endif


#if ARAGELI_DEBUG_LEVEL > 1

	#define ARAGELI_ASSERT_1_CUST(EXPR, EXCEPT_OBJ)	\
		ARAGELI_ASSERT_ALWAYS_CUST(EXPR, EXCEPT_OBJ)
	
	#define ARAGELI_ASSERT_1(EXPR)	\
		ARAGELI_ASSERT_ALWAYS(EXPR)

	#define ARAGELI_DEBUG_EXEC_1(WHAT) WHAT

#else

	#define ARAGELI_ASSERT_1_CUST(EXPR, EXCEPT_OBJ) /* nothing */
	#define ARAGELI_ASSERT_1(EXPR) /* nothing */
	#define ARAGELI_DEBUG_EXEC_1(WHAT)	/* nothing */

#endif


#if ARAGELI_DEBUG_LEVEL > 2

	#define ARAGELI_ASSERT_2_CUST(EXPR, EXCEPT_OBJ)	\
		ARAGELI_ASSERT_ALWAYS_CUST(EXPR, EXCEPT_OBJ)
	
	#define ARAGELI_ASSERT_2(EXPR)	\
		ARAGELI_ASSERT_ALWAYS(EXPR)

	#define ARAGELI_DEBUG_EXEC_2(WHAT) WHAT

#else

	#define ARAGELI_ASSERT_2_CUST(EXPR, EXCEPT_OBJ) /* nothing */
	#define ARAGELI_ASSERT_2(EXPR) /* nothing */
	#define ARAGELI_DEBUG_EXEC_2(WHAT)	/* nothing */

#endif


} // namespace Arageli


#endif  //  #ifndef _ARAGELI_exception_hpp_
