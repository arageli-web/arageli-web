/*****************************************************************************
	
	type_opers.hpp -- Operation with types.

	This file is part of the Arageli library.

	Copyright (C) Nikolai Yu. Zolotykh, 2005--2006
	Copyright (C) Sergey S. Lyalin, 2005--2006
	Copyright (C) University of Nizhni Novgorod, Russia, 2005--2006

*****************************************************************************/

/** \file
	
	Some static mechanisms that deal with types: type comparision and
	type modification (result type is built by another type).

*/


#ifndef _ARAGELI_type_opers_hpp_
#define _ARAGELI_type_opers_hpp_


#include "config.hpp"

#include <iostream>


//****************************************************************************


namespace Arageli
{


/// @name Boolean as type.

//@{

struct true_type { static const bool value = true; };
struct false_type { static const bool value = false; };

template <bool V> struct bool_type;

template <> struct bool_type<false>
{
	typedef false_type type;
	typedef false_type value_type;
	static const false_type value;
};


template <> struct bool_type<true>
{
	typedef true_type type;
	typedef true_type value_type;
	static const true_type value;
};


inline std::ostream& operator<< (std::ostream& out, const true_type&)
{ return out << "true"; }

inline std::ostream& operator<< (std::ostream& out, const false_type&)
{ return out << "false"; }


//@}


/// @name Type comparision.
/** Make a comparision between two types (the same or not). */

//@{

/// General form for defferent types.
template <typename T1, typename T2>
struct equal_types
{
	static const bool bvalue = false;
	typedef false_type value_type;
	static const false_type value;
};

/// Specialized form for the same type.
template <typename T>
struct equal_types<T, T>
{
	static const bool bvalue = true;
	typedef true_type value_type;
	static const true_type value;
};

//@}


/// @name The 'const' modificator ommiting.
/** Make a type from the particular type with omitted
	const modificator (if present). */

//@{

/// General form (for types without exterior const).
template <typename T>
struct omit_const { typedef T type; };

/// Specialized form (for types with exterior const).
template <typename T>
struct omit_const<const T> { typedef T type; };

//@}


/// @name Omitting *.
/** Make a type from the particular type with omitted '*' (if present). */

//@{

/// General form (for types without exterior *).
template <typename T>
struct omit_asterisk { typedef T type; };

/// Specialized form (for types with exterior const).
template <typename T>
struct omit_asterisk<T*> { typedef T type; };

//@}



/// @name Omitting &.
/** Make a type from the particular type with omitted '&' (if present). */

//@{

/// General form (for types without exterior *).
template <typename T>
struct omit_ref { typedef T type; };

/// Specialized form (for types with exterior const).
template <typename T>
struct omit_ref<T&> { typedef T type; };

//@}


/// Omitting const &.
/** Make a type from the particular type with omitted 'const &' (if present). */
template <typename T>
struct omit_const_ref
{ typedef typename omit_const<typename omit_ref<T>::type>::type type; };


//namespace _Internal
//{
//
//template <typename T1, typename T2>
//struct is_subclass_of_helper;
//
//template <typename T1, typename T2>
//struct is_subclass_of_helper;
//
//}
//
//
///// Determines if T1 is subclass of T2.
///** If T1 is inherited from T2 then true, else false. */
//template <typename T1, typename T2>
//struct is_subclass_of :
//	public _Internal::is_subclass_of_helper<T1*, T2*> {};
//


///// Determines if T1 is subcategory of T2.
///** Meaning of term ``category'' may be different.
//	See function_traits and type_traits. */
//template <typename T1, typename T2>
//struct is_subcategory_of
//{
//	static const bool bvalue = false;
//	typedef false_type value_type;
//	static const false_type value;
//};



} // namespace Arageli



#ifdef ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE
	#define ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_TYPE_OPERS
	#include "type_opers.cpp"
	#undef  ARAGELI_INCLUDE_CPP_WITH_EXPORT_TEMPLATE_TYPE_OPERS
#endif


#endif  //  #ifndef _ARAGELI_type_opers_hpp_
